webpackHotUpdate_N_E("pages/order/[id]",{

/***/ "./pages/order/[id].js":
/*!*****************************!*\
  !*** ./pages/order/[id].js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CreateOrder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var notiflix__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! notiflix */ "./node_modules/notiflix/dist/notiflix-aio-2.7.0.min.js");
/* harmony import */ var notiflix__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(notiflix__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_next_server_server_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/dist/next-server/server/router */ "./node_modules/next/dist/next-server/server/router.js");
/* harmony import */ var next_dist_next_server_server_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_next_server_server_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _containers_Header_Toolbar_Toolbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../containers/Header/Toolbar/Toolbar */ "./containers/Header/Toolbar/Toolbar.js");
/* harmony import */ var _components_order_order__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/order/order */ "./components/order/order.js");
/* harmony import */ var _components_order_mapp__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/order/mapp */ "./components/order/mapp.js");
/* harmony import */ var _components_order_orderInfo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/order/orderInfo */ "./components/order/orderInfo.js");
/* harmony import */ var _components_Helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/Helpers */ "./components/Helpers.js");
/* harmony import */ var _assets_images_del_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../assets/images/del.svg */ "./assets/images/del.svg");
/* harmony import */ var _assets_images_del_svg__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_images_del_svg__WEBPACK_IMPORTED_MODULE_11__);


var _jsxFileName = "D:\\MyProjects\\TWash\\twash-app\\pages\\order\\[id].js",
    _s = $RefreshSig$();












function CreateOrder() {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      show = _useState[0],
      setShow = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showOrder = _useState2[0],
      setShowOrder = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showMap = _useState3[0],
      setShowMap = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showOrderInfo = _useState4[0],
      setShowOrderInfo = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      orderData = _useState5[0],
      setOrderData = _useState5[1];

  var _useState6 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      mapData = _useState6[0],
      setMapData = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      orderInfo = _useState7[0],
      setOrderInfo = _useState7[1];

  var url = "https://api.tsapp.ir/api";
  var token;
  if (true) token = JSON.parse(localStorage.getItem('accessToken'));
  var link, code;
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    if (token != null) setShow(true);else router.push('/');
    link = window.location.href.split('/');

    if (link[link.length - 2] == "order") {
      code = link[link.length - 1];
      fetchOrder(code);
    }
  }, []);
  var timesHolder = ["06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30", "24:00", "00:30", "01:00", "01:30", "02:00"];

  var fetchOrder = function fetchOrder(id) {
    notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Loading.Dots();
    var abortController = new AbortController();
    var promise = window.fetch(url + '/order/' + id, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'dataType': 'jsonp',
        //you may use jsonp for cross origin request
        'Access-Control-Allow-Origin': '*',
        'Authorization': "Bearer " + token
      },
      method: 'GET',
      mode: 'cors',
      signal: abortController.signal
    }).then(function (res) {
      return res.json();
    }).then(function (responseJson) {
      if (responseJson.message == "سفارش با موفقیت دریافت شد") {
        var services = [];

        for (var item in responseJson.order.items) {
          if (responseJson.order.items[item].carwash_service_id == "1") {
            services.push(1);
          } else if (responseJson.order.items[item].carwash_service_id == "2") {
            services.push(2);
          } else if (responseJson.order.items[item].carwash_service_id == "3") {
            services.push(1);
            services.push(2);
          } else if (responseJson.order.items[item].carwash_service_id == "4") {
            services.push(4);
          } else if (responseJson.order.items[item].carwash_service_id == "5") {
            services.push(5);
          }
        }

        var _orderData = {
          services: services,
          //servicesTitle: servicesTitle,
          absence: responseJson.order.absence,
          time: [responseJson.order.human_reserved_time.toString().slice(0, 2), ":", responseJson.order.human_reserved_time.toString().slice(2)].join(''),
          endTime: timesHolder[timesHolder.indexOf([responseJson.order.human_reserved_time.toString().slice(0, 2), ":", responseJson.order.human_reserved_time.toString().slice(2)].join('')) + 4],
          price: responseJson.order.total,
          carModel: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.id : 0 : 0,
          modelTitle: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.name : "" : "",
          carBrand: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.brand_id : 0 : 0,
          brandTitle: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.brand.name : "" : "",
          selectedCar: responseJson.order.user_car_id,
          date: responseJson.order.reserved_day,
          carTag: responseJson.order.user_car != undefined ? responseJson.order.user_car.plaque : "",
          cardFile: responseJson.order.user_car != undefined ? responseJson.order.user_car.card_image : ""
        };
        var _mapData = {
          description: responseJson.order.user_address.description,
          lat: responseJson.order.user_address.latitude,
          lng: responseJson.order.user_address.longitude,
          userAddress: responseJson.order.user_address.id
        };
        var _orderInfo = {
          orderDescription: responseJson.order.description,
          PaymentType: responseJson.order.payment.payment_method
        };
        setOrderData(_orderData);
        setMapData(_mapData);
        setOrderInfo(_orderInfo);
        setShowOrder(true);

        if (document.getElementById("NotiflixLoadingWrap") != undefined) {
          var myobj = document.getElementById("NotiflixLoadingWrap");
          myobj.remove();
        }
      }
    })["catch"](function (err) {
      console.log(err);
    }); // Cancel the request if it takes more than delayFetch seconds

    setTimeout(function () {
      return abortController.abort();
    }, 100000);
  };

  notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Notify.Init({
    width: '250px',
    useIcon: false,
    fontSize: '14px',
    fontFamily: "IRANSansWeb",
    position: "center-top",
    closeButton: true,
    rtl: true,
    cssAnimationStyle: 'from-top'
  });

  var createOrder = function createOrder(orderInfos) {
    notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Loading.Dots();
    var data = new FormData();
    data.append('car_model_id', orderData.carModel);
    if (orderData.selectedCar > 0) data.append('user_car_id', orderData.selectedCar);
    if (orderData.carTag != undefined) data.append('car_plaque', orderData.carTag);
    if (orderData.cardImg != undefined) data.append('car_card_image', orderData.cardImg);
    data.append('absence', orderData.absence);
    data.append('services', JSON.stringify(orderData.services));
    data.append('reserve_day', orderData.date / 1000);
    data.append('reserve_time', orderData.time);
    data.append('address_longitude', mapData.lng);
    data.append('address_latitude', mapData.lat);
    data.append('address_name', "");
    if (mapData.description != undefined) data.append('address_description', mapData.description);
    if (mapData.userAddress != undefined && mapData.userAddress != 0) data.append('user_address_id', mapData.userAddress);
    if (mapData.description != undefined) data.append('description', orderInfos.orderDescription);
    data.append('payment_method', orderInfos.PaymentType);
    axios__WEBPACK_IMPORTED_MODULE_3___default.a.post(url + '/order', data, {
      headers: {
        'Accept': 'application/json',
        'dataType': 'json',
        //you may use jsonp for cross origin request
        'Content-Type': "application/json",
        'Access-Control-Allow-Origin': '*',
        'Authorization': "Bearer " + token
      }
    }).then(function (responseJson) {
      if (responseJson.data.message == "درخواست با موفقیت ثبت شد.") {
        if (document.getElementById("NotiflixNotifyWrap") != undefined) {
          var myobj = document.getElementById("NotiflixNotifyWrap");
          myobj.remove();
        }

        if (document.getElementById("NotiflixLoadingWrap") != undefined) {
          var myobj = document.getElementById("NotiflixLoadingWrap");
          myobj.remove();
        }

        if (responseJson.data.payment_data != null) {
          notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Notify.Success('به درگاه پرداخت منتقل می شوید...');
          router.push(responseJson.data.payment_data.original.action);
        } else {
          notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Notify.Success('درخواست با موفقیت ثبت شد.');
          router.push("/payment/cash");
        }
      }
    })["catch"](function (error) {
      if (error.message == "Request failed with status code 401") Object(_components_Helpers__WEBPACK_IMPORTED_MODULE_10__["VerifyToken"])();
    });
  };

  var toggleForms = function toggleForms(form, Data) {
    switch (form) {
      case "order":
        setShowOrder(false);
        setShowMap(true);
        setShowOrderInfo(false);
        setOrderData(Data);
        console.log(Data);
        break;

      case "map":
        if (document.getElementById("NotiflixLoadingWrap") != undefined) {
          var myobj = document.getElementById("NotiflixLoadingWrap");
          myobj.remove();
        }

        setShowOrder(false);
        setShowMap(false);
        setShowOrderInfo(true);
        setMapData(Data);
        console.log(Data);
        /*if(Data.description!="" && Data.description!=undefined && Data.description!=null)
        {
            setShowOrder(false)
            setShowMap(false)
            setShowOrderInfo(true)
            setMapData(Data)
        }
        else Notiflix.Notify.Failure('لطفا آدرس خود را وارد کنید.');*/

        break;

      case "orderInfo":
        setOrderInfo(Data);
        createOrder(Data);
        break;

      case "editOrder":
        setOrderInfo(Data);
        setShowOrder(true);
        setShowMap(false);
        setShowOrderInfo(false);
        break;

      default:
        setShowOrder(true);
        setShowMap(false);
        setShowOrderInfo(false);
    }
  };

  return show && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_containers_Header_Toolbar_Toolbar__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 242,
      columnNumber: 13
    }, this), showOrder && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_order_order__WEBPACK_IMPORTED_MODULE_7__["default"], {
      show: showOrder,
      callback: toggleForms,
      orderData: orderData,
      mapData: mapData
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 243,
      columnNumber: 27
    }, this), showMap && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_order_mapp__WEBPACK_IMPORTED_MODULE_8__["default"], {
      show: showMap,
      callback: toggleForms,
      orderData: orderData,
      mapData: mapData
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 244,
      columnNumber: 25
    }, this), showOrderInfo && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_order_orderInfo__WEBPACK_IMPORTED_MODULE_9__["default"], {
      show: showOrderInfo,
      callback: toggleForms,
      orderData: orderData,
      mapData: mapData,
      orderInfo: orderInfo
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 246,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 241,
    columnNumber: 17
  }, this);
}

_s(CreateOrder, "17YadL1Wr9o/mcv4aA8Tyglp8Lo=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"]];
});

_c = CreateOrder;

var _c;

$RefreshReg$(_c, "CreateOrder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvb3JkZXIvLmpzIl0sIm5hbWVzIjpbIkNyZWF0ZU9yZGVyIiwicm91dGVyIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJzaG93Iiwic2V0U2hvdyIsInNob3dPcmRlciIsInNldFNob3dPcmRlciIsInNob3dNYXAiLCJzZXRTaG93TWFwIiwic2hvd09yZGVySW5mbyIsInNldFNob3dPcmRlckluZm8iLCJvcmRlckRhdGEiLCJzZXRPcmRlckRhdGEiLCJtYXBEYXRhIiwic2V0TWFwRGF0YSIsIm9yZGVySW5mbyIsInNldE9yZGVySW5mbyIsInVybCIsInByb2Nlc3MiLCJ0b2tlbiIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJsaW5rIiwiY29kZSIsInVzZUVmZmVjdCIsInB1c2giLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhyZWYiLCJzcGxpdCIsImxlbmd0aCIsImZldGNoT3JkZXIiLCJ0aW1lc0hvbGRlciIsImlkIiwiTm90aWZsaXgiLCJMb2FkaW5nIiwiRG90cyIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsInByb21pc2UiLCJmZXRjaCIsImhlYWRlcnMiLCJtZXRob2QiLCJtb2RlIiwic2lnbmFsIiwidGhlbiIsInJlcyIsImpzb24iLCJyZXNwb25zZUpzb24iLCJtZXNzYWdlIiwic2VydmljZXMiLCJpdGVtIiwib3JkZXIiLCJpdGVtcyIsImNhcndhc2hfc2VydmljZV9pZCIsIl9vcmRlckRhdGEiLCJhYnNlbmNlIiwidGltZSIsImh1bWFuX3Jlc2VydmVkX3RpbWUiLCJ0b1N0cmluZyIsInNsaWNlIiwiam9pbiIsImVuZFRpbWUiLCJpbmRleE9mIiwicHJpY2UiLCJ0b3RhbCIsImNhck1vZGVsIiwidXNlcl9jYXIiLCJ1bmRlZmluZWQiLCJtb2RlbCIsIm1vZGVsVGl0bGUiLCJuYW1lIiwiY2FyQnJhbmQiLCJicmFuZF9pZCIsImJyYW5kVGl0bGUiLCJicmFuZCIsInNlbGVjdGVkQ2FyIiwidXNlcl9jYXJfaWQiLCJkYXRlIiwicmVzZXJ2ZWRfZGF5IiwiY2FyVGFnIiwicGxhcXVlIiwiY2FyZEZpbGUiLCJjYXJkX2ltYWdlIiwiX21hcERhdGEiLCJkZXNjcmlwdGlvbiIsInVzZXJfYWRkcmVzcyIsImxhdCIsImxhdGl0dWRlIiwibG5nIiwibG9uZ2l0dWRlIiwidXNlckFkZHJlc3MiLCJfb3JkZXJJbmZvIiwib3JkZXJEZXNjcmlwdGlvbiIsIlBheW1lbnRUeXBlIiwicGF5bWVudCIsInBheW1lbnRfbWV0aG9kIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsIm15b2JqIiwicmVtb3ZlIiwiZXJyIiwiY29uc29sZSIsImxvZyIsInNldFRpbWVvdXQiLCJhYm9ydCIsIk5vdGlmeSIsIkluaXQiLCJ3aWR0aCIsInVzZUljb24iLCJmb250U2l6ZSIsImZvbnRGYW1pbHkiLCJwb3NpdGlvbiIsImNsb3NlQnV0dG9uIiwicnRsIiwiY3NzQW5pbWF0aW9uU3R5bGUiLCJjcmVhdGVPcmRlciIsIm9yZGVySW5mb3MiLCJkYXRhIiwiRm9ybURhdGEiLCJhcHBlbmQiLCJjYXJkSW1nIiwic3RyaW5naWZ5IiwiYXhpb3MiLCJwb3N0IiwicGF5bWVudF9kYXRhIiwiU3VjY2VzcyIsIm9yaWdpbmFsIiwiYWN0aW9uIiwiZXJyb3IiLCJWZXJpZnlUb2tlbiIsInRvZ2dsZUZvcm1zIiwiZm9ybSIsIkRhdGEiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFZSxTQUFTQSxXQUFULEdBQXVCO0FBQUE7O0FBQ2xDLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7O0FBRGtDLGtCQUVWQyxzREFBUSxDQUFDLEtBQUQsQ0FGRTtBQUFBLE1BRTNCQyxJQUYyQjtBQUFBLE1BRXJCQyxPQUZxQjs7QUFBQSxtQkFHQUYsc0RBQVEsQ0FBQyxLQUFELENBSFI7QUFBQSxNQUczQkcsU0FIMkI7QUFBQSxNQUdoQkMsWUFIZ0I7O0FBQUEsbUJBSUpKLHNEQUFRLENBQUMsS0FBRCxDQUpKO0FBQUEsTUFJM0JLLE9BSjJCO0FBQUEsTUFJbEJDLFVBSmtCOztBQUFBLG1CQUtRTixzREFBUSxDQUFDLEtBQUQsQ0FMaEI7QUFBQSxNQUszQk8sYUFMMkI7QUFBQSxNQUtaQyxnQkFMWTs7QUFBQSxtQkFNQVIsc0RBQVEsQ0FBQyxFQUFELENBTlI7QUFBQSxNQU0zQlMsU0FOMkI7QUFBQSxNQU1oQkMsWUFOZ0I7O0FBQUEsbUJBT0pWLHNEQUFRLENBQUMsRUFBRCxDQVBKO0FBQUEsTUFPM0JXLE9BUDJCO0FBQUEsTUFPbEJDLFVBUGtCOztBQUFBLG1CQVFBWixzREFBUSxDQUFDLEVBQUQsQ0FSUjtBQUFBLE1BUTNCYSxTQVIyQjtBQUFBLE1BUWhCQyxZQVJnQjs7QUFVbEMsTUFBSUMsR0FBRyxHQUFHQywwQkFBVjtBQUNBLE1BQUlDLEtBQUo7QUFDQSxZQUNJQSxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsYUFBckIsQ0FBWCxDQUFSO0FBQ0osTUFBSUMsSUFBSixFQUFVQyxJQUFWO0FBQ0FDLHlEQUFTLENBQUMsWUFBTTtBQUNaLFFBQUlQLEtBQUssSUFBSSxJQUFiLEVBQ0lmLE9BQU8sQ0FBQyxJQUFELENBQVAsQ0FESixLQUVLSixNQUFNLENBQUMyQixJQUFQLENBQVksR0FBWjtBQUNMSCxRQUFJLEdBQUdJLE1BQU0sQ0FBQ0MsUUFBUCxDQUFnQkMsSUFBaEIsQ0FBcUJDLEtBQXJCLENBQTJCLEdBQTNCLENBQVA7O0FBQ0EsUUFBSVAsSUFBSSxDQUFDQSxJQUFJLENBQUNRLE1BQUwsR0FBYyxDQUFmLENBQUosSUFBeUIsT0FBN0IsRUFBc0M7QUFDbENQLFVBQUksR0FBR0QsSUFBSSxDQUFDQSxJQUFJLENBQUNRLE1BQUwsR0FBYyxDQUFmLENBQVg7QUFDQUMsZ0JBQVUsQ0FBQ1IsSUFBRCxDQUFWO0FBQ0g7QUFDSixHQVRRLEVBU04sRUFUTSxDQUFUO0FBVUEsTUFBSVMsV0FBVyxHQUFHLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsT0FBbkIsRUFBNEIsT0FBNUIsRUFBcUMsT0FBckMsRUFBOEMsT0FBOUMsRUFBdUQsT0FBdkQsRUFBZ0UsT0FBaEUsRUFBeUUsT0FBekUsRUFBa0YsT0FBbEYsRUFBMkYsT0FBM0YsRUFBb0csT0FBcEcsRUFDZCxPQURjLEVBQ0wsT0FESyxFQUNJLE9BREosRUFDYSxPQURiLEVBQ3NCLE9BRHRCLEVBQytCLE9BRC9CLEVBQ3dDLE9BRHhDLEVBQ2lELE9BRGpELEVBRWQsT0FGYyxFQUVMLE9BRkssRUFFSSxPQUZKLEVBRWEsT0FGYixFQUVzQixPQUZ0QixFQUUrQixPQUYvQixFQUV3QyxPQUZ4QyxFQUVpRCxPQUZqRCxFQUdkLE9BSGMsRUFHTCxPQUhLLEVBR0ksT0FISixFQUdhLE9BSGIsRUFHc0IsT0FIdEIsRUFHK0IsT0FIL0IsRUFHd0MsT0FIeEMsRUFHaUQsT0FIakQsRUFHMEQsT0FIMUQsRUFHbUUsT0FIbkUsRUFHNEUsT0FINUUsRUFHcUYsT0FIckYsRUFHOEYsT0FIOUYsQ0FBbEI7O0FBS0EsTUFBTUQsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQ0UsRUFBRCxFQUFRO0FBQ3ZCQyxtREFBUSxDQUFDQyxPQUFULENBQWlCQyxJQUFqQjtBQUNBLFFBQU1DLGVBQWUsR0FBRyxJQUFJQyxlQUFKLEVBQXhCO0FBQ0EsUUFBTUMsT0FBTyxHQUFHYixNQUFNLENBQ2pCYyxLQURXLENBQ0x6QixHQUFHLEdBQUcsU0FBTixHQUFrQmtCLEVBRGIsRUFDaUI7QUFDekJRLGFBQU8sRUFBRTtBQUNMLGtCQUFVLGtCQURMO0FBRUwsd0JBQWdCLGtCQUZYO0FBR0wsb0JBQVksT0FIUDtBQUdrQjtBQUN2Qix1Q0FBK0IsR0FKMUI7QUFLTCx5QkFBaUIsWUFBWXhCO0FBTHhCLE9BRGdCO0FBUXpCeUIsWUFBTSxFQUFFLEtBUmlCO0FBU3pCQyxVQUFJLEVBQUUsTUFUbUI7QUFVekJDLFlBQU0sRUFBRVAsZUFBZSxDQUFDTztBQVZDLEtBRGpCLEVBYVhDLElBYlcsQ0FhTixVQUFBQyxHQUFHO0FBQUEsYUFBSUEsR0FBRyxDQUFDQyxJQUFKLEVBQUo7QUFBQSxLQWJHLEVBY1hGLElBZFcsQ0FjTixVQUFBRyxZQUFZLEVBQUk7QUFDbEIsVUFBSUEsWUFBWSxDQUFDQyxPQUFiLElBQXdCLDJCQUE1QixFQUF5RDtBQUNyRCxZQUFJQyxRQUFRLEdBQUMsRUFBYjs7QUFDQSxhQUFJLElBQUlDLElBQVIsSUFBZ0JILFlBQVksQ0FBQ0ksS0FBYixDQUFtQkMsS0FBbkMsRUFBeUM7QUFDckMsY0FBR0wsWUFBWSxDQUFDSSxLQUFiLENBQW1CQyxLQUFuQixDQUF5QkYsSUFBekIsRUFBK0JHLGtCQUEvQixJQUFtRCxHQUF0RCxFQUNBO0FBQ0lKLG9CQUFRLENBQUN6QixJQUFULENBQWMsQ0FBZDtBQUNILFdBSEQsTUFJSyxJQUFHdUIsWUFBWSxDQUFDSSxLQUFiLENBQW1CQyxLQUFuQixDQUF5QkYsSUFBekIsRUFBK0JHLGtCQUEvQixJQUFtRCxHQUF0RCxFQUNMO0FBQ0lKLG9CQUFRLENBQUN6QixJQUFULENBQWMsQ0FBZDtBQUNILFdBSEksTUFJQSxJQUFHdUIsWUFBWSxDQUFDSSxLQUFiLENBQW1CQyxLQUFuQixDQUF5QkYsSUFBekIsRUFBK0JHLGtCQUEvQixJQUFtRCxHQUF0RCxFQUNMO0FBQ0lKLG9CQUFRLENBQUN6QixJQUFULENBQWMsQ0FBZDtBQUNBeUIsb0JBQVEsQ0FBQ3pCLElBQVQsQ0FBYyxDQUFkO0FBQ0gsV0FKSSxNQUtBLElBQUd1QixZQUFZLENBQUNJLEtBQWIsQ0FBbUJDLEtBQW5CLENBQXlCRixJQUF6QixFQUErQkcsa0JBQS9CLElBQW1ELEdBQXRELEVBQ0w7QUFDSUosb0JBQVEsQ0FBQ3pCLElBQVQsQ0FBYyxDQUFkO0FBQ0gsV0FISSxNQUlBLElBQUd1QixZQUFZLENBQUNJLEtBQWIsQ0FBbUJDLEtBQW5CLENBQXlCRixJQUF6QixFQUErQkcsa0JBQS9CLElBQW1ELEdBQXRELEVBQ0w7QUFDSUosb0JBQVEsQ0FBQ3pCLElBQVQsQ0FBYyxDQUFkO0FBQ0g7QUFDSjs7QUFFRCxZQUFJOEIsVUFBVSxHQUFHO0FBQ2JMLGtCQUFRLEVBQUVBLFFBREc7QUFFYjtBQUNBTSxpQkFBTyxFQUFFUixZQUFZLENBQUNJLEtBQWIsQ0FBbUJJLE9BSGY7QUFJYkMsY0FBSSxFQUFFLENBQUNULFlBQVksQ0FBQ0ksS0FBYixDQUFtQk0sbUJBQW5CLENBQXVDQyxRQUF2QyxHQUFrREMsS0FBbEQsQ0FBd0QsQ0FBeEQsRUFBMkQsQ0FBM0QsQ0FBRCxFQUFnRSxHQUFoRSxFQUFxRVosWUFBWSxDQUFDSSxLQUFiLENBQW1CTSxtQkFBbkIsQ0FBdUNDLFFBQXZDLEdBQWtEQyxLQUFsRCxDQUF3RCxDQUF4RCxDQUFyRSxFQUFpSUMsSUFBakksQ0FBc0ksRUFBdEksQ0FKTztBQUtiQyxpQkFBTyxFQUFFOUIsV0FBVyxDQUFDQSxXQUFXLENBQUMrQixPQUFaLENBQW9CLENBQUNmLFlBQVksQ0FBQ0ksS0FBYixDQUFtQk0sbUJBQW5CLENBQXVDQyxRQUF2QyxHQUFrREMsS0FBbEQsQ0FBd0QsQ0FBeEQsRUFBMkQsQ0FBM0QsQ0FBRCxFQUFnRSxHQUFoRSxFQUFxRVosWUFBWSxDQUFDSSxLQUFiLENBQW1CTSxtQkFBbkIsQ0FBdUNDLFFBQXZDLEdBQWtEQyxLQUFsRCxDQUF3RCxDQUF4RCxDQUFyRSxFQUFpSUMsSUFBakksQ0FBc0ksRUFBdEksQ0FBcEIsSUFBaUssQ0FBbEssQ0FMUDtBQU1iRyxlQUFLLEVBQUVoQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJhLEtBTmI7QUFPYkMsa0JBQVEsRUFBRWxCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmUsUUFBbkIsSUFBK0JDLFNBQS9CLEdBQTJDcEIsWUFBWSxDQUFDSSxLQUFiLENBQW1CZSxRQUFuQixDQUE0QkUsS0FBNUIsSUFBcUNELFNBQXJDLEdBQWlEcEIsWUFBWSxDQUFDSSxLQUFiLENBQW1CZSxRQUFuQixDQUE0QkUsS0FBNUIsQ0FBa0NwQyxFQUFuRixHQUF3RixDQUFuSSxHQUF1SSxDQVBwSTtBQVFicUMsb0JBQVUsRUFBRXRCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmUsUUFBbkIsSUFBK0JDLFNBQS9CLEdBQTBDcEIsWUFBWSxDQUFDSSxLQUFiLENBQW1CZSxRQUFuQixDQUE0QkUsS0FBNUIsSUFBcUNELFNBQXJDLEdBQWdEcEIsWUFBWSxDQUFDSSxLQUFiLENBQW1CZSxRQUFuQixDQUE0QkUsS0FBNUIsQ0FBa0NFLElBQWxGLEdBQXlGLEVBQW5JLEdBQXVJLEVBUnRJO0FBU2JDLGtCQUFRLEVBQUV4QixZQUFZLENBQUNJLEtBQWIsQ0FBbUJlLFFBQW5CLElBQStCQyxTQUEvQixHQUEyQ3BCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmUsUUFBbkIsQ0FBNEJFLEtBQTVCLElBQXFDRCxTQUFyQyxHQUFnRHBCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmUsUUFBbkIsQ0FBNEJFLEtBQTVCLENBQWtDSSxRQUFsRixHQUE2RixDQUF4SSxHQUEySSxDQVR4STtBQVViQyxvQkFBVSxFQUFFMUIsWUFBWSxDQUFDSSxLQUFiLENBQW1CZSxRQUFuQixJQUErQkMsU0FBL0IsR0FBMkNwQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJlLFFBQW5CLENBQTRCRSxLQUE1QixJQUFxQ0QsU0FBckMsR0FBZ0RwQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJlLFFBQW5CLENBQTRCRSxLQUE1QixDQUFrQ00sS0FBbEMsQ0FBd0NKLElBQXhGLEdBQThGLEVBQXpJLEdBQTRJLEVBVjNJO0FBV2JLLHFCQUFXLEVBQUU1QixZQUFZLENBQUNJLEtBQWIsQ0FBbUJ5QixXQVhuQjtBQVliQyxjQUFJLEVBQUU5QixZQUFZLENBQUNJLEtBQWIsQ0FBbUIyQixZQVpaO0FBYWJDLGdCQUFNLEVBQUVoQyxZQUFZLENBQUNJLEtBQWIsQ0FBbUJlLFFBQW5CLElBQStCQyxTQUEvQixHQUEyQ3BCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmUsUUFBbkIsQ0FBNEJjLE1BQXZFLEdBQWdGLEVBYjNFO0FBY2JDLGtCQUFRLEVBQUNsQyxZQUFZLENBQUNJLEtBQWIsQ0FBbUJlLFFBQW5CLElBQStCQyxTQUEvQixHQUEyQ3BCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmUsUUFBbkIsQ0FBNEJnQixVQUF2RSxHQUFvRjtBQWRoRixTQUFqQjtBQWlCQSxZQUFJQyxRQUFRLEdBQUc7QUFDWEMscUJBQVcsRUFBRXJDLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmtDLFlBQW5CLENBQWdDRCxXQURsQztBQUVYRSxhQUFHLEVBQUV2QyxZQUFZLENBQUNJLEtBQWIsQ0FBbUJrQyxZQUFuQixDQUFnQ0UsUUFGMUI7QUFHWEMsYUFBRyxFQUFFekMsWUFBWSxDQUFDSSxLQUFiLENBQW1Ca0MsWUFBbkIsQ0FBZ0NJLFNBSDFCO0FBSVhDLHFCQUFXLEVBQUUzQyxZQUFZLENBQUNJLEtBQWIsQ0FBbUJrQyxZQUFuQixDQUFnQ3JEO0FBSmxDLFNBQWY7QUFNQSxZQUFJMkQsVUFBVSxHQUFHO0FBQ2JDLDBCQUFnQixFQUFFN0MsWUFBWSxDQUFDSSxLQUFiLENBQW1CaUMsV0FEeEI7QUFFYlMscUJBQVcsRUFBRTlDLFlBQVksQ0FBQ0ksS0FBYixDQUFtQjJDLE9BQW5CLENBQTJCQztBQUYzQixTQUFqQjtBQUtBdEYsb0JBQVksQ0FBQzZDLFVBQUQsQ0FBWjtBQUNBM0Msa0JBQVUsQ0FBQ3dFLFFBQUQsQ0FBVjtBQUNBdEUsb0JBQVksQ0FBQzhFLFVBQUQsQ0FBWjtBQUNBeEYsb0JBQVksQ0FBQyxJQUFELENBQVo7O0FBQ0EsWUFBSTZGLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixxQkFBeEIsS0FBa0Q5QixTQUF0RCxFQUFpRTtBQUM3RCxjQUFJK0IsS0FBSyxHQUFHRixRQUFRLENBQUNDLGNBQVQsQ0FBd0IscUJBQXhCLENBQVo7QUFDQUMsZUFBSyxDQUFDQyxNQUFOO0FBQ0g7QUFDSjtBQUNKLEtBOUVXLFdBK0VMLFVBQUFDLEdBQUcsRUFBSTtBQUNWQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsR0FBWjtBQUNILEtBakZXLENBQWhCLENBSHVCLENBcUZ2Qjs7QUFDQUcsY0FBVSxDQUFDO0FBQUEsYUFBTW5FLGVBQWUsQ0FBQ29FLEtBQWhCLEVBQU47QUFBQSxLQUFELEVBQWdDekYsTUFBaEMsQ0FBVjtBQUNILEdBdkZEOztBQXdGQWtCLGlEQUFRLENBQUN3RSxNQUFULENBQWdCQyxJQUFoQixDQUFxQjtBQUNqQkMsU0FBSyxFQUFFLE9BRFU7QUFFakJDLFdBQU8sRUFBRSxLQUZRO0FBR2pCQyxZQUFRLEVBQUUsTUFITztBQUlqQkMsY0FBVSxFQUFFLGFBSks7QUFLakJDLFlBQVEsRUFBRSxZQUxPO0FBTWpCQyxlQUFXLEVBQUUsSUFOSTtBQU9qQkMsT0FBRyxFQUFFLElBUFk7QUFRakJDLHFCQUFpQixFQUFFO0FBUkYsR0FBckI7O0FBVUEsTUFBTUMsV0FBVyxHQUFHLFNBQWRBLFdBQWMsQ0FBQ0MsVUFBRCxFQUFnQjtBQUNoQ25GLG1EQUFRLENBQUNDLE9BQVQsQ0FBaUJDLElBQWpCO0FBQ0EsUUFBSWtGLElBQUksR0FBRyxJQUFJQyxRQUFKLEVBQVg7QUFDQUQsUUFBSSxDQUFDRSxNQUFMLENBQVksY0FBWixFQUE0Qi9HLFNBQVMsQ0FBQ3lELFFBQXRDO0FBQ0EsUUFBSXpELFNBQVMsQ0FBQ21FLFdBQVYsR0FBd0IsQ0FBNUIsRUFBK0IwQyxJQUFJLENBQUNFLE1BQUwsQ0FBWSxhQUFaLEVBQTJCL0csU0FBUyxDQUFDbUUsV0FBckM7QUFDL0IsUUFBSW5FLFNBQVMsQ0FBQ3VFLE1BQVYsSUFBb0JaLFNBQXhCLEVBQW1Da0QsSUFBSSxDQUFDRSxNQUFMLENBQVksWUFBWixFQUEwQi9HLFNBQVMsQ0FBQ3VFLE1BQXBDO0FBQ25DLFFBQUl2RSxTQUFTLENBQUNnSCxPQUFWLElBQXFCckQsU0FBekIsRUFBb0NrRCxJQUFJLENBQUNFLE1BQUwsQ0FBWSxnQkFBWixFQUE4Qi9HLFNBQVMsQ0FBQ2dILE9BQXhDO0FBQ3BDSCxRQUFJLENBQUNFLE1BQUwsQ0FBWSxTQUFaLEVBQXVCL0csU0FBUyxDQUFDK0MsT0FBakM7QUFDQThELFFBQUksQ0FBQ0UsTUFBTCxDQUFZLFVBQVosRUFBd0J0RyxJQUFJLENBQUN3RyxTQUFMLENBQWVqSCxTQUFTLENBQUN5QyxRQUF6QixDQUF4QjtBQUNBb0UsUUFBSSxDQUFDRSxNQUFMLENBQVksYUFBWixFQUEyQi9HLFNBQVMsQ0FBQ3FFLElBQVYsR0FBaUIsSUFBNUM7QUFDQXdDLFFBQUksQ0FBQ0UsTUFBTCxDQUFZLGNBQVosRUFBNEIvRyxTQUFTLENBQUNnRCxJQUF0QztBQUNBNkQsUUFBSSxDQUFDRSxNQUFMLENBQVksbUJBQVosRUFBaUM3RyxPQUFPLENBQUM4RSxHQUF6QztBQUNBNkIsUUFBSSxDQUFDRSxNQUFMLENBQVksa0JBQVosRUFBZ0M3RyxPQUFPLENBQUM0RSxHQUF4QztBQUNBK0IsUUFBSSxDQUFDRSxNQUFMLENBQVksY0FBWixFQUE0QixFQUE1QjtBQUNBLFFBQUk3RyxPQUFPLENBQUMwRSxXQUFSLElBQXVCakIsU0FBM0IsRUFBc0NrRCxJQUFJLENBQUNFLE1BQUwsQ0FBWSxxQkFBWixFQUFtQzdHLE9BQU8sQ0FBQzBFLFdBQTNDO0FBQ3RDLFFBQUkxRSxPQUFPLENBQUNnRixXQUFSLElBQXVCdkIsU0FBdkIsSUFBb0N6RCxPQUFPLENBQUNnRixXQUFSLElBQXVCLENBQS9ELEVBQWtFMkIsSUFBSSxDQUFDRSxNQUFMLENBQVksaUJBQVosRUFBK0I3RyxPQUFPLENBQUNnRixXQUF2QztBQUNsRSxRQUFJaEYsT0FBTyxDQUFDMEUsV0FBUixJQUF1QmpCLFNBQTNCLEVBQXNDa0QsSUFBSSxDQUFDRSxNQUFMLENBQVksYUFBWixFQUEyQkgsVUFBVSxDQUFDeEIsZ0JBQXRDO0FBQ3RDeUIsUUFBSSxDQUFDRSxNQUFMLENBQVksZ0JBQVosRUFBOEJILFVBQVUsQ0FBQ3ZCLFdBQXpDO0FBRUE2QixnREFBSyxDQUFDQyxJQUFOLENBQVc3RyxHQUFHLEdBQUcsUUFBakIsRUFBMkJ1RyxJQUEzQixFQUFpQztBQUM3QjdFLGFBQU8sRUFBRTtBQUNMLGtCQUFVLGtCQURMO0FBRUwsb0JBQVksTUFGUDtBQUVpQjtBQUN0Qix3QkFBZ0Isa0JBSFg7QUFJTCx1Q0FBK0IsR0FKMUI7QUFLTCx5QkFBaUIsWUFBWXhCO0FBTHhCO0FBRG9CLEtBQWpDLEVBU0s0QixJQVRMLENBU1UsVUFBQ0csWUFBRCxFQUFrQjtBQUNwQixVQUFJQSxZQUFZLENBQUNzRSxJQUFiLENBQWtCckUsT0FBbEIsSUFBNkIsMkJBQWpDLEVBQThEO0FBQzFELFlBQUlnRCxRQUFRLENBQUNDLGNBQVQsQ0FBd0Isb0JBQXhCLEtBQWlEOUIsU0FBckQsRUFBZ0U7QUFDNUQsY0FBSStCLEtBQUssR0FBR0YsUUFBUSxDQUFDQyxjQUFULENBQXdCLG9CQUF4QixDQUFaO0FBQ0FDLGVBQUssQ0FBQ0MsTUFBTjtBQUNIOztBQUNELFlBQUlILFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixxQkFBeEIsS0FBa0Q5QixTQUF0RCxFQUFpRTtBQUM3RCxjQUFJK0IsS0FBSyxHQUFHRixRQUFRLENBQUNDLGNBQVQsQ0FBd0IscUJBQXhCLENBQVo7QUFDQUMsZUFBSyxDQUFDQyxNQUFOO0FBQ0g7O0FBRUQsWUFBSXBELFlBQVksQ0FBQ3NFLElBQWIsQ0FBa0JPLFlBQWxCLElBQWtDLElBQXRDLEVBQTRDO0FBQ3hDM0YseURBQVEsQ0FBQ3dFLE1BQVQsQ0FBZ0JvQixPQUFoQixDQUF3QixrQ0FBeEI7QUFDQWhJLGdCQUFNLENBQUMyQixJQUFQLENBQVl1QixZQUFZLENBQUNzRSxJQUFiLENBQWtCTyxZQUFsQixDQUErQkUsUUFBL0IsQ0FBd0NDLE1BQXBEO0FBQ0gsU0FIRCxNQUdPO0FBQ0g5Rix5REFBUSxDQUFDd0UsTUFBVCxDQUFnQm9CLE9BQWhCLENBQXdCLDJCQUF4QjtBQUNBaEksZ0JBQU0sQ0FBQzJCLElBQVAsQ0FBWSxlQUFaO0FBQ0g7QUFFSjtBQUNKLEtBN0JMLFdBOEJXLFVBQUN3RyxLQUFELEVBQVc7QUFDZCxVQUFJQSxLQUFLLENBQUNoRixPQUFOLElBQWlCLHFDQUFyQixFQUNJaUYsd0VBQVc7QUFDbEIsS0FqQ0w7QUFrQ0gsR0FyREQ7O0FBdURBLE1BQU1DLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUNDLElBQUQsRUFBT0MsSUFBUCxFQUFnQjtBQUNoQyxZQUFRRCxJQUFSO0FBQ0ksV0FBSyxPQUFMO0FBQ0loSSxvQkFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNBRSxrQkFBVSxDQUFDLElBQUQsQ0FBVjtBQUNBRSx3QkFBZ0IsQ0FBQyxLQUFELENBQWhCO0FBQ0FFLG9CQUFZLENBQUMySCxJQUFELENBQVo7QUFDQS9CLGVBQU8sQ0FBQ0MsR0FBUixDQUFZOEIsSUFBWjtBQUNBOztBQUNKLFdBQUssS0FBTDtBQUNJLFlBQUlwQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IscUJBQXhCLEtBQWtEOUIsU0FBdEQsRUFBaUU7QUFDN0QsY0FBSStCLEtBQUssR0FBR0YsUUFBUSxDQUFDQyxjQUFULENBQXdCLHFCQUF4QixDQUFaO0FBQ0FDLGVBQUssQ0FBQ0MsTUFBTjtBQUNIOztBQUNEaEcsb0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQUUsa0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDQUUsd0JBQWdCLENBQUMsSUFBRCxDQUFoQjtBQUNBSSxrQkFBVSxDQUFDeUgsSUFBRCxDQUFWO0FBQ0EvQixlQUFPLENBQUNDLEdBQVIsQ0FBWThCLElBQVo7QUFDQTtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDZ0I7O0FBQ0osV0FBSyxXQUFMO0FBQ0l2SCxvQkFBWSxDQUFDdUgsSUFBRCxDQUFaO0FBQ0FqQixtQkFBVyxDQUFDaUIsSUFBRCxDQUFYO0FBQ0E7O0FBQ0osV0FBSyxXQUFMO0FBQ0l2SCxvQkFBWSxDQUFDdUgsSUFBRCxDQUFaO0FBQ0FqSSxvQkFBWSxDQUFDLElBQUQsQ0FBWjtBQUNBRSxrQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNBRSx3QkFBZ0IsQ0FBQyxLQUFELENBQWhCO0FBQ0E7O0FBQ0o7QUFDSUosb0JBQVksQ0FBQyxJQUFELENBQVo7QUFDQUUsa0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDQUUsd0JBQWdCLENBQUMsS0FBRCxDQUFoQjtBQXhDUjtBQTBDSCxHQTNDRDs7QUE0Q0EsU0FDSVAsSUFBSSxpQkFBSSxxRUFBQyw0Q0FBRCxDQUFPLFFBQVA7QUFBQSw0QkFDSixxRUFBQywwRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREksRUFFSEUsU0FBUyxpQkFBSSxxRUFBQywrREFBRDtBQUFPLFVBQUksRUFBRUEsU0FBYjtBQUF3QixjQUFRLEVBQUVnSSxXQUFsQztBQUErQyxlQUFTLEVBQUUxSCxTQUExRDtBQUFxRSxhQUFPLEVBQUVFO0FBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGVixFQUdITixPQUFPLGlCQUFJLHFFQUFDLDhEQUFEO0FBQUssVUFBSSxFQUFFQSxPQUFYO0FBQW9CLGNBQVEsRUFBRThILFdBQTlCO0FBQTJDLGVBQVMsRUFBRTFILFNBQXREO0FBQWlFLGFBQU8sRUFBRUU7QUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUhSLEVBSUhKLGFBQWEsaUJBQ2QscUVBQUMsbUVBQUQ7QUFBVyxVQUFJLEVBQUVBLGFBQWpCO0FBQWdDLGNBQVEsRUFBRTRILFdBQTFDO0FBQXVELGVBQVMsRUFBRTFILFNBQWxFO0FBQTZFLGFBQU8sRUFBRUUsT0FBdEY7QUFDVyxlQUFTLEVBQUVFO0FBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFEWjtBQVVIOztHQTdPdUJoQixXO1VBQ0xFLHFEOzs7S0FES0YsVyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9vcmRlci9baWRdLjczNDYxYjQyMTY1Y2UxMjZjMTdiLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHt1c2VFZmZlY3QsIHVzZVN0YXRlfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHt1c2VSb3V0ZXJ9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBOb3RpZmxpeCBmcm9tIFwibm90aWZsaXhcIjtcclxuaW1wb3J0IHtyb3V0ZX0gZnJvbSBcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9zZXJ2ZXIvcm91dGVyXCI7XHJcbmltcG9ydCBUb29sYmFyIGZyb20gXCIuLi8uLi9jb250YWluZXJzL0hlYWRlci9Ub29sYmFyL1Rvb2xiYXJcIjtcclxuaW1wb3J0IE9yZGVyIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL29yZGVyL29yZGVyXCJcclxuaW1wb3J0IE1hcCBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9vcmRlci9tYXBwXCJcclxuaW1wb3J0IE9yZGVySW5mbyBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9vcmRlci9vcmRlckluZm9cIlxyXG5pbXBvcnQge1ZlcmlmeVRva2VufSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9IZWxwZXJzXCJcclxuaW1wb3J0IGRlbEJ0biBmcm9tIFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9kZWwuc3ZnXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDcmVhdGVPcmRlcigpIHtcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXHJcbiAgICBjb25zdCBbc2hvdywgc2V0U2hvd10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc2hvd09yZGVyLCBzZXRTaG93T3JkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Nob3dNYXAsIHNldFNob3dNYXBdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Nob3dPcmRlckluZm8sIHNldFNob3dPcmRlckluZm9dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW29yZGVyRGF0YSwgc2V0T3JkZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICAgIGNvbnN0IFttYXBEYXRhLCBzZXRNYXBEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICAgIGNvbnN0IFtvcmRlckluZm8sIHNldE9yZGVySW5mb10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gICAgbGV0IHVybCA9IHByb2Nlc3MuZW52LnVybDtcclxuICAgIGxldCB0b2tlbjtcclxuICAgIGlmIChwcm9jZXNzLmJyb3dzZXIpXHJcbiAgICAgICAgdG9rZW4gPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhY2Nlc3NUb2tlbicpKTtcclxuICAgIGxldCBsaW5rLCBjb2RlO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAodG9rZW4gIT0gbnVsbClcclxuICAgICAgICAgICAgc2V0U2hvdyh0cnVlKVxyXG4gICAgICAgIGVsc2Ugcm91dGVyLnB1c2goJy8nKVxyXG4gICAgICAgIGxpbmsgPSB3aW5kb3cubG9jYXRpb24uaHJlZi5zcGxpdCgnLycpO1xyXG4gICAgICAgIGlmIChsaW5rW2xpbmsubGVuZ3RoIC0gMl0gPT0gXCJvcmRlclwiKSB7XHJcbiAgICAgICAgICAgIGNvZGUgPSBsaW5rW2xpbmsubGVuZ3RoIC0gMV07XHJcbiAgICAgICAgICAgIGZldGNoT3JkZXIoY29kZSlcclxuICAgICAgICB9XHJcbiAgICB9LCBbXSk7XHJcbiAgICBsZXQgdGltZXNIb2xkZXIgPSBbXCIwNjowMFwiLCBcIjA2OjMwXCIsIFwiMDc6MDBcIiwgXCIwNzozMFwiLCBcIjA4OjAwXCIsIFwiMDg6MzBcIiwgXCIwOTowMFwiLCBcIjA5OjMwXCIsIFwiMTA6MDBcIiwgXCIxMDozMFwiLCBcIjExOjAwXCIsIFwiMTE6MzBcIixcclxuICAgICAgICBcIjEyOjAwXCIsIFwiMTI6MzBcIiwgXCIxMzowMFwiLCBcIjEzOjMwXCIsIFwiMTQ6MDBcIiwgXCIxNDozMFwiLCBcIjE1OjAwXCIsIFwiMTU6MzBcIixcclxuICAgICAgICBcIjE2OjAwXCIsIFwiMTY6MzBcIiwgXCIxNzowMFwiLCBcIjE3OjMwXCIsIFwiMTg6MDBcIiwgXCIxODozMFwiLCBcIjE5OjAwXCIsIFwiMTk6MzBcIixcclxuICAgICAgICBcIjIwOjAwXCIsIFwiMjA6MzBcIiwgXCIyMTowMFwiLCBcIjIxOjMwXCIsIFwiMjI6MDBcIiwgXCIyMjozMFwiLCBcIjIzOjAwXCIsIFwiMjM6MzBcIiwgXCIyNDowMFwiLCBcIjAwOjMwXCIsIFwiMDE6MDBcIiwgXCIwMTozMFwiLCBcIjAyOjAwXCJcclxuICAgIF07XHJcbiAgICBjb25zdCBmZXRjaE9yZGVyID0gKGlkKSA9PiB7XHJcbiAgICAgICAgTm90aWZsaXguTG9hZGluZy5Eb3RzKCk7XHJcbiAgICAgICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXHJcbiAgICAgICAgY29uc3QgcHJvbWlzZSA9IHdpbmRvd1xyXG4gICAgICAgICAgICAuZmV0Y2godXJsICsgJy9vcmRlci8nICsgaWQsIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQWNjZXB0JzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ2RhdGFUeXBlJzogJ2pzb25wJywgICAvL3lvdSBtYXkgdXNlIGpzb25wIGZvciBjcm9zcyBvcmlnaW4gcmVxdWVzdFxyXG4gICAgICAgICAgICAgICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBcIkJlYXJlciBcIiArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcclxuICAgICAgICAgICAgICAgIG1vZGU6ICdjb3JzJyxcclxuICAgICAgICAgICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcclxuICAgICAgICAgICAgLnRoZW4ocmVzcG9uc2VKc29uID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZUpzb24ubWVzc2FnZSA9PSBcItiz2YHYp9ix2LQg2KjYpyDZhdmI2YHZgtuM2Kog2K/YsduM2KfZgdiqINi02K9cIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBzZXJ2aWNlcz1bXVxyXG4gICAgICAgICAgICAgICAgICAgIGZvcihsZXQgaXRlbSBpbiByZXNwb25zZUpzb24ub3JkZXIuaXRlbXMpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZihyZXNwb25zZUpzb24ub3JkZXIuaXRlbXNbaXRlbV0uY2Fyd2FzaF9zZXJ2aWNlX2lkPT1cIjFcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VydmljZXMucHVzaCgxKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYocmVzcG9uc2VKc29uLm9yZGVyLml0ZW1zW2l0ZW1dLmNhcndhc2hfc2VydmljZV9pZD09XCIyXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2VzLnB1c2goMilcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmKHJlc3BvbnNlSnNvbi5vcmRlci5pdGVtc1tpdGVtXS5jYXJ3YXNoX3NlcnZpY2VfaWQ9PVwiM1wiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJ2aWNlcy5wdXNoKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJ2aWNlcy5wdXNoKDIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZihyZXNwb25zZUpzb24ub3JkZXIuaXRlbXNbaXRlbV0uY2Fyd2FzaF9zZXJ2aWNlX2lkPT1cIjRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VydmljZXMucHVzaCg0KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYocmVzcG9uc2VKc29uLm9yZGVyLml0ZW1zW2l0ZW1dLmNhcndhc2hfc2VydmljZV9pZD09XCI1XCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2VzLnB1c2goNSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IF9vcmRlckRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2VzOiBzZXJ2aWNlcyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9zZXJ2aWNlc1RpdGxlOiBzZXJ2aWNlc1RpdGxlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhYnNlbmNlOiByZXNwb25zZUpzb24ub3JkZXIuYWJzZW5jZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogW3Jlc3BvbnNlSnNvbi5vcmRlci5odW1hbl9yZXNlcnZlZF90aW1lLnRvU3RyaW5nKCkuc2xpY2UoMCwgMiksIFwiOlwiLCByZXNwb25zZUpzb24ub3JkZXIuaHVtYW5fcmVzZXJ2ZWRfdGltZS50b1N0cmluZygpLnNsaWNlKDIpXS5qb2luKCcnKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW5kVGltZTogdGltZXNIb2xkZXJbdGltZXNIb2xkZXIuaW5kZXhPZihbcmVzcG9uc2VKc29uLm9yZGVyLmh1bWFuX3Jlc2VydmVkX3RpbWUudG9TdHJpbmcoKS5zbGljZSgwLCAyKSwgXCI6XCIsIHJlc3BvbnNlSnNvbi5vcmRlci5odW1hbl9yZXNlcnZlZF90aW1lLnRvU3RyaW5nKCkuc2xpY2UoMildLmpvaW4oJycpKSArIDRdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmljZTogcmVzcG9uc2VKc29uLm9yZGVyLnRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJNb2RlbDogcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyICE9IHVuZGVmaW5lZCA/IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2Nhci5tb2RlbCAhPSB1bmRlZmluZWQgPyByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIubW9kZWwuaWQgOiAwIDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWxUaXRsZTogcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyICE9IHVuZGVmaW5lZCA/cmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyLm1vZGVsICE9IHVuZGVmaW5lZCA/cmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyLm1vZGVsLm5hbWUgOiBcIlwiOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJCcmFuZDogcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyICE9IHVuZGVmaW5lZCA/IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2Nhci5tb2RlbCAhPSB1bmRlZmluZWQgP3Jlc3BvbnNlSnNvbi5vcmRlci51c2VyX2Nhci5tb2RlbC5icmFuZF9pZCA6IDA6IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyYW5kVGl0bGU6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2NhciAhPSB1bmRlZmluZWQgPyByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIubW9kZWwgIT0gdW5kZWZpbmVkID9yZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIubW9kZWwuYnJhbmQubmFtZSA6XCJcIjpcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZENhcjogcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRlOiByZXNwb25zZUpzb24ub3JkZXIucmVzZXJ2ZWRfZGF5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJUYWc6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2NhciAhPSB1bmRlZmluZWQgPyByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIucGxhcXVlIDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FyZEZpbGU6cmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyICE9IHVuZGVmaW5lZCA/IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2Nhci5jYXJkX2ltYWdlIDogXCJcIlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IF9tYXBEYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfYWRkcmVzcy5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGF0OiByZXNwb25zZUpzb24ub3JkZXIudXNlcl9hZGRyZXNzLmxhdGl0dWRlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsbmc6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2FkZHJlc3MubG9uZ2l0dWRlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyQWRkcmVzczogcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfYWRkcmVzcy5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBsZXQgX29yZGVySW5mbyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3JkZXJEZXNjcmlwdGlvbjogcmVzcG9uc2VKc29uLm9yZGVyLmRlc2NyaXB0aW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50VHlwZTogcmVzcG9uc2VKc29uLm9yZGVyLnBheW1lbnQucGF5bWVudF9tZXRob2QsXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBzZXRPcmRlckRhdGEoX29yZGVyRGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TWFwRGF0YShfbWFwRGF0YSlcclxuICAgICAgICAgICAgICAgICAgICBzZXRPcmRlckluZm8oX29yZGVySW5mbylcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93T3JkZXIodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJOb3RpZmxpeExvYWRpbmdXcmFwXCIpICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbXlvYmogPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIk5vdGlmbGl4TG9hZGluZ1dyYXBcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG15b2JqLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgLy8gQ2FuY2VsIHRoZSByZXF1ZXN0IGlmIGl0IHRha2VzIG1vcmUgdGhhbiBkZWxheUZldGNoIHNlY29uZHNcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGFib3J0Q29udHJvbGxlci5hYm9ydCgpLCBwcm9jZXNzLmVudi5kZWxheUZldGNoKVxyXG4gICAgfTtcclxuICAgIE5vdGlmbGl4Lk5vdGlmeS5Jbml0KHtcclxuICAgICAgICB3aWR0aDogJzI1MHB4JyxcclxuICAgICAgICB1c2VJY29uOiBmYWxzZSxcclxuICAgICAgICBmb250U2l6ZTogJzE0cHgnLFxyXG4gICAgICAgIGZvbnRGYW1pbHk6IFwiSVJBTlNhbnNXZWJcIixcclxuICAgICAgICBwb3NpdGlvbjogXCJjZW50ZXItdG9wXCIsXHJcbiAgICAgICAgY2xvc2VCdXR0b246IHRydWUsXHJcbiAgICAgICAgcnRsOiB0cnVlLFxyXG4gICAgICAgIGNzc0FuaW1hdGlvblN0eWxlOiAnZnJvbS10b3AnXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGNyZWF0ZU9yZGVyID0gKG9yZGVySW5mb3MpID0+IHtcclxuICAgICAgICBOb3RpZmxpeC5Mb2FkaW5nLkRvdHMoKTtcclxuICAgICAgICBsZXQgZGF0YSA9IG5ldyBGb3JtRGF0YSgpXHJcbiAgICAgICAgZGF0YS5hcHBlbmQoJ2Nhcl9tb2RlbF9pZCcsIG9yZGVyRGF0YS5jYXJNb2RlbClcclxuICAgICAgICBpZiAob3JkZXJEYXRhLnNlbGVjdGVkQ2FyID4gMCkgZGF0YS5hcHBlbmQoJ3VzZXJfY2FyX2lkJywgb3JkZXJEYXRhLnNlbGVjdGVkQ2FyKVxyXG4gICAgICAgIGlmIChvcmRlckRhdGEuY2FyVGFnICE9IHVuZGVmaW5lZCkgZGF0YS5hcHBlbmQoJ2Nhcl9wbGFxdWUnLCBvcmRlckRhdGEuY2FyVGFnKVxyXG4gICAgICAgIGlmIChvcmRlckRhdGEuY2FyZEltZyAhPSB1bmRlZmluZWQpIGRhdGEuYXBwZW5kKCdjYXJfY2FyZF9pbWFnZScsIG9yZGVyRGF0YS5jYXJkSW1nKVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdhYnNlbmNlJywgb3JkZXJEYXRhLmFic2VuY2UpXHJcbiAgICAgICAgZGF0YS5hcHBlbmQoJ3NlcnZpY2VzJywgSlNPTi5zdHJpbmdpZnkob3JkZXJEYXRhLnNlcnZpY2VzKSlcclxuICAgICAgICBkYXRhLmFwcGVuZCgncmVzZXJ2ZV9kYXknLCBvcmRlckRhdGEuZGF0ZSAvIDEwMDApXHJcbiAgICAgICAgZGF0YS5hcHBlbmQoJ3Jlc2VydmVfdGltZScsIG9yZGVyRGF0YS50aW1lKVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdhZGRyZXNzX2xvbmdpdHVkZScsIG1hcERhdGEubG5nKVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdhZGRyZXNzX2xhdGl0dWRlJywgbWFwRGF0YS5sYXQpXHJcbiAgICAgICAgZGF0YS5hcHBlbmQoJ2FkZHJlc3NfbmFtZScsIFwiXCIpXHJcbiAgICAgICAgaWYgKG1hcERhdGEuZGVzY3JpcHRpb24gIT0gdW5kZWZpbmVkKSBkYXRhLmFwcGVuZCgnYWRkcmVzc19kZXNjcmlwdGlvbicsIG1hcERhdGEuZGVzY3JpcHRpb24pXHJcbiAgICAgICAgaWYgKG1hcERhdGEudXNlckFkZHJlc3MgIT0gdW5kZWZpbmVkICYmIG1hcERhdGEudXNlckFkZHJlc3MgIT0gMCkgZGF0YS5hcHBlbmQoJ3VzZXJfYWRkcmVzc19pZCcsIG1hcERhdGEudXNlckFkZHJlc3MpXHJcbiAgICAgICAgaWYgKG1hcERhdGEuZGVzY3JpcHRpb24gIT0gdW5kZWZpbmVkKSBkYXRhLmFwcGVuZCgnZGVzY3JpcHRpb24nLCBvcmRlckluZm9zLm9yZGVyRGVzY3JpcHRpb24pXHJcbiAgICAgICAgZGF0YS5hcHBlbmQoJ3BheW1lbnRfbWV0aG9kJywgb3JkZXJJbmZvcy5QYXltZW50VHlwZSlcclxuXHJcbiAgICAgICAgYXhpb3MucG9zdCh1cmwgKyAnL29yZGVyJywgZGF0YSwge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQWNjZXB0JzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgJ2RhdGFUeXBlJzogJ2pzb24nLCAgIC8veW91IG1heSB1c2UganNvbnAgZm9yIGNyb3NzIG9yaWdpbiByZXF1ZXN0XHJcbiAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBcIkJlYXJlciBcIiArIHRva2VuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgICAgICAudGhlbigocmVzcG9uc2VKc29uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2VKc29uLmRhdGEubWVzc2FnZSA9PSBcItiv2LHYrtmI2KfYs9iqINio2Kcg2YXZiNmB2YLbjNiqINir2KjYqiDYtNivLlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiTm90aWZsaXhOb3RpZnlXcmFwXCIpICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbXlvYmogPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIk5vdGlmbGl4Tm90aWZ5V3JhcFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbXlvYmoucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIk5vdGlmbGl4TG9hZGluZ1dyYXBcIikgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBteW9iaiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiTm90aWZsaXhMb2FkaW5nV3JhcFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbXlvYmoucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2VKc29uLmRhdGEucGF5bWVudF9kYXRhICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgTm90aWZsaXguTm90aWZ5LlN1Y2Nlc3MoJ9io2Ycg2K/Ysdqv2KfZhyDZvtix2K/Yp9iu2Kog2YXZhtiq2YLZhCDZhduMINi02YjbjNivLi4uJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlci5wdXNoKHJlc3BvbnNlSnNvbi5kYXRhLnBheW1lbnRfZGF0YS5vcmlnaW5hbC5hY3Rpb24pXHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgTm90aWZsaXguTm90aWZ5LlN1Y2Nlc3MoJ9iv2LHYrtmI2KfYs9iqINio2Kcg2YXZiNmB2YLbjNiqINir2KjYqiDYtNivLicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByb3V0ZXIucHVzaChcIi9wYXltZW50L2Nhc2hcIilcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3IubWVzc2FnZSA9PSBcIlJlcXVlc3QgZmFpbGVkIHdpdGggc3RhdHVzIGNvZGUgNDAxXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgVmVyaWZ5VG9rZW4oKTtcclxuICAgICAgICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0b2dnbGVGb3JtcyA9IChmb3JtLCBEYXRhKSA9PiB7XHJcbiAgICAgICAgc3dpdGNoIChmb3JtKSB7XHJcbiAgICAgICAgICAgIGNhc2UgXCJvcmRlclwiIDpcclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlcihmYWxzZSlcclxuICAgICAgICAgICAgICAgIHNldFNob3dNYXAodHJ1ZSlcclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlckluZm8oZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBzZXRPcmRlckRhdGEoRGF0YSlcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKERhdGEpXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcIm1hcFwiIDpcclxuICAgICAgICAgICAgICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIk5vdGlmbGl4TG9hZGluZ1dyYXBcIikgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIG15b2JqID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJOb3RpZmxpeExvYWRpbmdXcmFwXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIG15b2JqLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd09yZGVyKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd01hcChmYWxzZSlcclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlckluZm8odHJ1ZSlcclxuICAgICAgICAgICAgICAgIHNldE1hcERhdGEoRGF0YSlcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKERhdGEpXHJcbiAgICAgICAgICAgICAgICAvKmlmKERhdGEuZGVzY3JpcHRpb24hPVwiXCIgJiYgRGF0YS5kZXNjcmlwdGlvbiE9dW5kZWZpbmVkICYmIERhdGEuZGVzY3JpcHRpb24hPW51bGwpXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd09yZGVyKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dNYXAoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd09yZGVySW5mbyh0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldE1hcERhdGEoRGF0YSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgTm90aWZsaXguTm90aWZ5LkZhaWx1cmUoJ9mE2LfZgdinINii2K/YsdizINiu2YjYryDYsdinINmI2KfYsdivINqp2YbbjNivLicpOyovXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcIm9yZGVySW5mb1wiIDpcclxuICAgICAgICAgICAgICAgIHNldE9yZGVySW5mbyhEYXRhKVxyXG4gICAgICAgICAgICAgICAgY3JlYXRlT3JkZXIoRGF0YSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcImVkaXRPcmRlclwiIDpcclxuICAgICAgICAgICAgICAgIHNldE9yZGVySW5mbyhEYXRhKVxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd09yZGVyKHRydWUpXHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TWFwKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd09yZGVySW5mbyhmYWxzZSlcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd09yZGVyKHRydWUpXHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TWFwKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd09yZGVySW5mbyhmYWxzZSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIHNob3cgJiYgPFJlYWN0LkZyYWdtZW50PlxyXG4gICAgICAgICAgICA8VG9vbGJhci8+XHJcbiAgICAgICAgICAgIHtzaG93T3JkZXIgJiYgPE9yZGVyIHNob3c9e3Nob3dPcmRlcn0gY2FsbGJhY2s9e3RvZ2dsZUZvcm1zfSBvcmRlckRhdGE9e29yZGVyRGF0YX0gbWFwRGF0YT17bWFwRGF0YX0vPn1cclxuICAgICAgICAgICAge3Nob3dNYXAgJiYgPE1hcCBzaG93PXtzaG93TWFwfSBjYWxsYmFjaz17dG9nZ2xlRm9ybXN9IG9yZGVyRGF0YT17b3JkZXJEYXRhfSBtYXBEYXRhPXttYXBEYXRhfS8+fVxyXG4gICAgICAgICAgICB7c2hvd09yZGVySW5mbyAmJlxyXG4gICAgICAgICAgICA8T3JkZXJJbmZvIHNob3c9e3Nob3dPcmRlckluZm99IGNhbGxiYWNrPXt0b2dnbGVGb3Jtc30gb3JkZXJEYXRhPXtvcmRlckRhdGF9IG1hcERhdGE9e21hcERhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgb3JkZXJJbmZvPXtvcmRlckluZm99Lz59XHJcbiAgICAgICAgPC9SZWFjdC5GcmFnbWVudD5cclxuICAgIClcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9