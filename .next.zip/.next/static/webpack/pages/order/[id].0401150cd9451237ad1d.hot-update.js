webpackHotUpdate_N_E("pages/order/[id]",{

/***/ "./pages/order/[id].js":
/*!*****************************!*\
  !*** ./pages/order/[id].js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CreateOrder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var notiflix__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! notiflix */ "./node_modules/notiflix/dist/notiflix-aio-2.7.0.min.js");
/* harmony import */ var notiflix__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(notiflix__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_next_server_server_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/dist/next-server/server/router */ "./node_modules/next/dist/next-server/server/router.js");
/* harmony import */ var next_dist_next_server_server_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_next_server_server_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _containers_Header_Toolbar_Toolbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../containers/Header/Toolbar/Toolbar */ "./containers/Header/Toolbar/Toolbar.js");
/* harmony import */ var _components_order_order__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/order/order */ "./components/order/order.js");
/* harmony import */ var _components_order_mapp__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/order/mapp */ "./components/order/mapp.js");
/* harmony import */ var _components_order_orderInfo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/order/orderInfo */ "./components/order/orderInfo.js");
/* harmony import */ var _components_Helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/Helpers */ "./components/Helpers.js");
/* harmony import */ var _assets_images_del_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../assets/images/del.svg */ "./assets/images/del.svg");
/* harmony import */ var _assets_images_del_svg__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_images_del_svg__WEBPACK_IMPORTED_MODULE_11__);


var _jsxFileName = "D:\\MyProjects\\TWash\\twash-app\\pages\\order\\[id].js",
    _s = $RefreshSig$();












function CreateOrder() {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      show = _useState[0],
      setShow = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showOrder = _useState2[0],
      setShowOrder = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showMap = _useState3[0],
      setShowMap = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showOrderInfo = _useState4[0],
      setShowOrderInfo = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      orderData = _useState5[0],
      setOrderData = _useState5[1];

  var _useState6 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      mapData = _useState6[0],
      setMapData = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      orderInfo = _useState7[0],
      setOrderInfo = _useState7[1];

  var url = "https://api.tsapp.ir/api";
  var token;
  if (true) token = JSON.parse(localStorage.getItem('accessToken'));
  var link, code;
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    if (token != null) setShow(true);else router.push('/');
    link = window.location.href.split('/');

    if (link[link.length - 2] == "order") {
      code = link[link.length - 1];
      fetchOrder(code);
    }
  }, []);
  var timesHolder = ["06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30", "24:00", "00:30", "01:00", "01:30", "02:00"];

  var fetchOrder = function fetchOrder(id) {
    notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Loading.Dots();
    var abortController = new AbortController();
    var promise = window.fetch(url + '/order/' + id, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'dataType': 'jsonp',
        //you may use jsonp for cross origin request
        'Access-Control-Allow-Origin': '*',
        'Authorization': "Bearer " + token
      },
      method: 'GET',
      mode: 'cors',
      signal: abortController.signal
    }).then(function (res) {
      return res.json();
    }).then(function (responseJson) {
      if (responseJson.message == "سفارش با موفقیت دریافت شد") {
        var services = [];

        for (var item in responseJson.order.items) {
          if (responseJson.order.items[item].id == "56") {
            services.push(1);
          } else if (responseJson.order.items[item].id == "66") {
            services.push(2);
          } else if (responseJson.order.items[item].id == "67") {
            services.push(1);
            services.push(2);
          } else if (responseJson.order.items[item].id == "68") {
            services.push(4);
          } else if (responseJson.order.items[item].id == "69") {
            services.push(5);
          }
        }

        var _orderData = {
          services: services,
          //servicesTitle: servicesTitle,
          absence: responseJson.order.absence,
          time: [responseJson.order.human_reserved_time.toString().slice(0, 2), ":", responseJson.order.human_reserved_time.toString().slice(2)].join(''),
          endTime: timesHolder[timesHolder.indexOf([responseJson.order.human_reserved_time.toString().slice(0, 2), ":", responseJson.order.human_reserved_time.toString().slice(2)].join('')) + 4],
          price: responseJson.order.total,
          carModel: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.id : 0 : 0,
          modelTitle: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.name : "" : "",
          carBrand: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.brand_id : 0 : 0,
          brandTitle: responseJson.order.user_car != undefined ? responseJson.order.user_car.model != undefined ? responseJson.order.user_car.model.brand.name : "" : "",
          selectedCar: responseJson.order.user_car_id,
          date: responseJson.order.reserved_day,
          carTag: responseJson.order.user_car != undefined ? responseJson.order.user_car.plaque : "",
          cardFile: responseJson.order.user_car != undefined ? responseJson.order.user_car.card_image : ""
        };
        var _mapData = {
          description: responseJson.order.user_address.description,
          lat: responseJson.order.user_address.latitude,
          lng: responseJson.order.user_address.longitude,
          userAddress: responseJson.order.user_address.id
        };
        var _orderInfo = {
          orderDescription: responseJson.order.description,
          PaymentType: responseJson.order.payment.payment_method
        };
        setOrderData(_orderData);
        setMapData(_mapData);
        setOrderInfo(_orderInfo);
        setShowOrder(true);

        if (document.getElementById("NotiflixLoadingWrap") != undefined) {
          var myobj = document.getElementById("NotiflixLoadingWrap");
          myobj.remove();
        }
      }
    })["catch"](function (err) {
      console.log(err);
    }); // Cancel the request if it takes more than delayFetch seconds

    setTimeout(function () {
      return abortController.abort();
    }, 100000);
  };

  notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Notify.Init({
    width: '250px',
    useIcon: false,
    fontSize: '14px',
    fontFamily: "IRANSansWeb",
    position: "center-top",
    closeButton: true,
    rtl: true,
    cssAnimationStyle: 'from-top'
  });

  var createOrder = function createOrder(orderInfos) {
    notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Loading.Dots();
    var data = new FormData();
    data.append('car_model_id', orderData.carModel);
    if (orderData.selectedCar > 0) data.append('user_car_id', orderData.selectedCar);
    if (orderData.carTag != undefined) data.append('car_plaque', orderData.carTag);
    if (orderData.cardImg != undefined) data.append('car_card_image', orderData.cardImg);
    data.append('absence', orderData.absence);
    data.append('services', JSON.stringify(orderData.services));
    data.append('reserve_day', orderData.date / 1000);
    data.append('reserve_time', orderData.time);
    data.append('address_longitude', mapData.lng);
    data.append('address_latitude', mapData.lat);
    data.append('address_name', "");
    if (mapData.description != undefined) data.append('address_description', mapData.description);
    if (mapData.userAddress != undefined && mapData.userAddress != 0) data.append('user_address_id', mapData.userAddress);
    if (mapData.description != undefined) data.append('description', orderInfos.orderDescription);
    data.append('payment_method', orderInfos.PaymentType);
    axios__WEBPACK_IMPORTED_MODULE_3___default.a.post(url + '/order', data, {
      headers: {
        'Accept': 'application/json',
        'dataType': 'json',
        //you may use jsonp for cross origin request
        'Content-Type': "application/json",
        'Access-Control-Allow-Origin': '*',
        'Authorization': "Bearer " + token
      }
    }).then(function (responseJson) {
      if (responseJson.data.message == "درخواست با موفقیت ثبت شد.") {
        if (document.getElementById("NotiflixNotifyWrap") != undefined) {
          var myobj = document.getElementById("NotiflixNotifyWrap");
          myobj.remove();
        }

        if (document.getElementById("NotiflixLoadingWrap") != undefined) {
          var myobj = document.getElementById("NotiflixLoadingWrap");
          myobj.remove();
        }

        if (responseJson.data.payment_data != null) {
          notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Notify.Success('به درگاه پرداخت منتقل می شوید...');
          router.push(responseJson.data.payment_data.original.action);
        } else {
          notiflix__WEBPACK_IMPORTED_MODULE_4___default.a.Notify.Success('درخواست با موفقیت ثبت شد.');
          router.push("/payment/cash");
        }
      }
    })["catch"](function (error) {
      if (error.message == "Request failed with status code 401") Object(_components_Helpers__WEBPACK_IMPORTED_MODULE_10__["VerifyToken"])();
    });
  };

  var toggleForms = function toggleForms(form, Data) {
    switch (form) {
      case "order":
        setShowOrder(false);
        setShowMap(true);
        setShowOrderInfo(false);
        setOrderData(Data);
        console.log(Data);
        break;

      case "map":
        if (document.getElementById("NotiflixLoadingWrap") != undefined) {
          var myobj = document.getElementById("NotiflixLoadingWrap");
          myobj.remove();
        }

        setShowOrder(false);
        setShowMap(false);
        setShowOrderInfo(true);
        setMapData(Data);
        console.log(Data);
        /*if(Data.description!="" && Data.description!=undefined && Data.description!=null)
        {
            setShowOrder(false)
            setShowMap(false)
            setShowOrderInfo(true)
            setMapData(Data)
        }
        else Notiflix.Notify.Failure('لطفا آدرس خود را وارد کنید.');*/

        break;

      case "orderInfo":
        setOrderInfo(Data);
        createOrder(Data);
        break;

      case "editOrder":
        setOrderInfo(Data);
        setShowOrder(true);
        setShowMap(false);
        setShowOrderInfo(false);
        break;

      default:
        setShowOrder(true);
        setShowMap(false);
        setShowOrderInfo(false);
    }
  };

  return show && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_containers_Header_Toolbar_Toolbar__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 242,
      columnNumber: 13
    }, this), showOrder && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_order_order__WEBPACK_IMPORTED_MODULE_7__["default"], {
      show: showOrder,
      callback: toggleForms,
      orderData: orderData,
      mapData: mapData
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 243,
      columnNumber: 27
    }, this), showMap && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_order_mapp__WEBPACK_IMPORTED_MODULE_8__["default"], {
      show: showMap,
      callback: toggleForms,
      orderData: orderData,
      mapData: mapData
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 244,
      columnNumber: 25
    }, this), showOrderInfo && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_order_orderInfo__WEBPACK_IMPORTED_MODULE_9__["default"], {
      show: showOrderInfo,
      callback: toggleForms,
      orderData: orderData,
      mapData: mapData,
      orderInfo: orderInfo
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 246,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 241,
    columnNumber: 17
  }, this);
}

_s(CreateOrder, "17YadL1Wr9o/mcv4aA8Tyglp8Lo=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"]];
});

_c = CreateOrder;

var _c;

$RefreshReg$(_c, "CreateOrder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvb3JkZXIvLmpzIl0sIm5hbWVzIjpbIkNyZWF0ZU9yZGVyIiwicm91dGVyIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJzaG93Iiwic2V0U2hvdyIsInNob3dPcmRlciIsInNldFNob3dPcmRlciIsInNob3dNYXAiLCJzZXRTaG93TWFwIiwic2hvd09yZGVySW5mbyIsInNldFNob3dPcmRlckluZm8iLCJvcmRlckRhdGEiLCJzZXRPcmRlckRhdGEiLCJtYXBEYXRhIiwic2V0TWFwRGF0YSIsIm9yZGVySW5mbyIsInNldE9yZGVySW5mbyIsInVybCIsInByb2Nlc3MiLCJ0b2tlbiIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJsaW5rIiwiY29kZSIsInVzZUVmZmVjdCIsInB1c2giLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhyZWYiLCJzcGxpdCIsImxlbmd0aCIsImZldGNoT3JkZXIiLCJ0aW1lc0hvbGRlciIsImlkIiwiTm90aWZsaXgiLCJMb2FkaW5nIiwiRG90cyIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsInByb21pc2UiLCJmZXRjaCIsImhlYWRlcnMiLCJtZXRob2QiLCJtb2RlIiwic2lnbmFsIiwidGhlbiIsInJlcyIsImpzb24iLCJyZXNwb25zZUpzb24iLCJtZXNzYWdlIiwic2VydmljZXMiLCJpdGVtIiwib3JkZXIiLCJpdGVtcyIsIl9vcmRlckRhdGEiLCJhYnNlbmNlIiwidGltZSIsImh1bWFuX3Jlc2VydmVkX3RpbWUiLCJ0b1N0cmluZyIsInNsaWNlIiwiam9pbiIsImVuZFRpbWUiLCJpbmRleE9mIiwicHJpY2UiLCJ0b3RhbCIsImNhck1vZGVsIiwidXNlcl9jYXIiLCJ1bmRlZmluZWQiLCJtb2RlbCIsIm1vZGVsVGl0bGUiLCJuYW1lIiwiY2FyQnJhbmQiLCJicmFuZF9pZCIsImJyYW5kVGl0bGUiLCJicmFuZCIsInNlbGVjdGVkQ2FyIiwidXNlcl9jYXJfaWQiLCJkYXRlIiwicmVzZXJ2ZWRfZGF5IiwiY2FyVGFnIiwicGxhcXVlIiwiY2FyZEZpbGUiLCJjYXJkX2ltYWdlIiwiX21hcERhdGEiLCJkZXNjcmlwdGlvbiIsInVzZXJfYWRkcmVzcyIsImxhdCIsImxhdGl0dWRlIiwibG5nIiwibG9uZ2l0dWRlIiwidXNlckFkZHJlc3MiLCJfb3JkZXJJbmZvIiwib3JkZXJEZXNjcmlwdGlvbiIsIlBheW1lbnRUeXBlIiwicGF5bWVudCIsInBheW1lbnRfbWV0aG9kIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsIm15b2JqIiwicmVtb3ZlIiwiZXJyIiwiY29uc29sZSIsImxvZyIsInNldFRpbWVvdXQiLCJhYm9ydCIsIk5vdGlmeSIsIkluaXQiLCJ3aWR0aCIsInVzZUljb24iLCJmb250U2l6ZSIsImZvbnRGYW1pbHkiLCJwb3NpdGlvbiIsImNsb3NlQnV0dG9uIiwicnRsIiwiY3NzQW5pbWF0aW9uU3R5bGUiLCJjcmVhdGVPcmRlciIsIm9yZGVySW5mb3MiLCJkYXRhIiwiRm9ybURhdGEiLCJhcHBlbmQiLCJjYXJkSW1nIiwic3RyaW5naWZ5IiwiYXhpb3MiLCJwb3N0IiwicGF5bWVudF9kYXRhIiwiU3VjY2VzcyIsIm9yaWdpbmFsIiwiYWN0aW9uIiwiZXJyb3IiLCJWZXJpZnlUb2tlbiIsInRvZ2dsZUZvcm1zIiwiZm9ybSIsIkRhdGEiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFZSxTQUFTQSxXQUFULEdBQXVCO0FBQUE7O0FBQ2xDLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7O0FBRGtDLGtCQUVWQyxzREFBUSxDQUFDLEtBQUQsQ0FGRTtBQUFBLE1BRTNCQyxJQUYyQjtBQUFBLE1BRXJCQyxPQUZxQjs7QUFBQSxtQkFHQUYsc0RBQVEsQ0FBQyxLQUFELENBSFI7QUFBQSxNQUczQkcsU0FIMkI7QUFBQSxNQUdoQkMsWUFIZ0I7O0FBQUEsbUJBSUpKLHNEQUFRLENBQUMsS0FBRCxDQUpKO0FBQUEsTUFJM0JLLE9BSjJCO0FBQUEsTUFJbEJDLFVBSmtCOztBQUFBLG1CQUtRTixzREFBUSxDQUFDLEtBQUQsQ0FMaEI7QUFBQSxNQUszQk8sYUFMMkI7QUFBQSxNQUtaQyxnQkFMWTs7QUFBQSxtQkFNQVIsc0RBQVEsQ0FBQyxFQUFELENBTlI7QUFBQSxNQU0zQlMsU0FOMkI7QUFBQSxNQU1oQkMsWUFOZ0I7O0FBQUEsbUJBT0pWLHNEQUFRLENBQUMsRUFBRCxDQVBKO0FBQUEsTUFPM0JXLE9BUDJCO0FBQUEsTUFPbEJDLFVBUGtCOztBQUFBLG1CQVFBWixzREFBUSxDQUFDLEVBQUQsQ0FSUjtBQUFBLE1BUTNCYSxTQVIyQjtBQUFBLE1BUWhCQyxZQVJnQjs7QUFVbEMsTUFBSUMsR0FBRyxHQUFHQywwQkFBVjtBQUNBLE1BQUlDLEtBQUo7QUFDQSxZQUNJQSxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsYUFBckIsQ0FBWCxDQUFSO0FBQ0osTUFBSUMsSUFBSixFQUFVQyxJQUFWO0FBQ0FDLHlEQUFTLENBQUMsWUFBTTtBQUNaLFFBQUlQLEtBQUssSUFBSSxJQUFiLEVBQ0lmLE9BQU8sQ0FBQyxJQUFELENBQVAsQ0FESixLQUVLSixNQUFNLENBQUMyQixJQUFQLENBQVksR0FBWjtBQUNMSCxRQUFJLEdBQUdJLE1BQU0sQ0FBQ0MsUUFBUCxDQUFnQkMsSUFBaEIsQ0FBcUJDLEtBQXJCLENBQTJCLEdBQTNCLENBQVA7O0FBQ0EsUUFBSVAsSUFBSSxDQUFDQSxJQUFJLENBQUNRLE1BQUwsR0FBYyxDQUFmLENBQUosSUFBeUIsT0FBN0IsRUFBc0M7QUFDbENQLFVBQUksR0FBR0QsSUFBSSxDQUFDQSxJQUFJLENBQUNRLE1BQUwsR0FBYyxDQUFmLENBQVg7QUFDQUMsZ0JBQVUsQ0FBQ1IsSUFBRCxDQUFWO0FBQ0g7QUFDSixHQVRRLEVBU04sRUFUTSxDQUFUO0FBVUEsTUFBSVMsV0FBVyxHQUFHLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsT0FBbkIsRUFBNEIsT0FBNUIsRUFBcUMsT0FBckMsRUFBOEMsT0FBOUMsRUFBdUQsT0FBdkQsRUFBZ0UsT0FBaEUsRUFBeUUsT0FBekUsRUFBa0YsT0FBbEYsRUFBMkYsT0FBM0YsRUFBb0csT0FBcEcsRUFDZCxPQURjLEVBQ0wsT0FESyxFQUNJLE9BREosRUFDYSxPQURiLEVBQ3NCLE9BRHRCLEVBQytCLE9BRC9CLEVBQ3dDLE9BRHhDLEVBQ2lELE9BRGpELEVBRWQsT0FGYyxFQUVMLE9BRkssRUFFSSxPQUZKLEVBRWEsT0FGYixFQUVzQixPQUZ0QixFQUUrQixPQUYvQixFQUV3QyxPQUZ4QyxFQUVpRCxPQUZqRCxFQUdkLE9BSGMsRUFHTCxPQUhLLEVBR0ksT0FISixFQUdhLE9BSGIsRUFHc0IsT0FIdEIsRUFHK0IsT0FIL0IsRUFHd0MsT0FIeEMsRUFHaUQsT0FIakQsRUFHMEQsT0FIMUQsRUFHbUUsT0FIbkUsRUFHNEUsT0FINUUsRUFHcUYsT0FIckYsRUFHOEYsT0FIOUYsQ0FBbEI7O0FBS0EsTUFBTUQsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQ0UsRUFBRCxFQUFRO0FBQ3ZCQyxtREFBUSxDQUFDQyxPQUFULENBQWlCQyxJQUFqQjtBQUNBLFFBQU1DLGVBQWUsR0FBRyxJQUFJQyxlQUFKLEVBQXhCO0FBQ0EsUUFBTUMsT0FBTyxHQUFHYixNQUFNLENBQ2pCYyxLQURXLENBQ0x6QixHQUFHLEdBQUcsU0FBTixHQUFrQmtCLEVBRGIsRUFDaUI7QUFDekJRLGFBQU8sRUFBRTtBQUNMLGtCQUFVLGtCQURMO0FBRUwsd0JBQWdCLGtCQUZYO0FBR0wsb0JBQVksT0FIUDtBQUdrQjtBQUN2Qix1Q0FBK0IsR0FKMUI7QUFLTCx5QkFBaUIsWUFBWXhCO0FBTHhCLE9BRGdCO0FBUXpCeUIsWUFBTSxFQUFFLEtBUmlCO0FBU3pCQyxVQUFJLEVBQUUsTUFUbUI7QUFVekJDLFlBQU0sRUFBRVAsZUFBZSxDQUFDTztBQVZDLEtBRGpCLEVBYVhDLElBYlcsQ0FhTixVQUFBQyxHQUFHO0FBQUEsYUFBSUEsR0FBRyxDQUFDQyxJQUFKLEVBQUo7QUFBQSxLQWJHLEVBY1hGLElBZFcsQ0FjTixVQUFBRyxZQUFZLEVBQUk7QUFDbEIsVUFBSUEsWUFBWSxDQUFDQyxPQUFiLElBQXdCLDJCQUE1QixFQUF5RDtBQUNyRCxZQUFJQyxRQUFRLEdBQUMsRUFBYjs7QUFDQSxhQUFJLElBQUlDLElBQVIsSUFBZ0JILFlBQVksQ0FBQ0ksS0FBYixDQUFtQkMsS0FBbkMsRUFBeUM7QUFDckMsY0FBR0wsWUFBWSxDQUFDSSxLQUFiLENBQW1CQyxLQUFuQixDQUF5QkYsSUFBekIsRUFBK0JsQixFQUEvQixJQUFtQyxJQUF0QyxFQUNBO0FBQ0lpQixvQkFBUSxDQUFDekIsSUFBVCxDQUFjLENBQWQ7QUFDSCxXQUhELE1BSUssSUFBR3VCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQkMsS0FBbkIsQ0FBeUJGLElBQXpCLEVBQStCbEIsRUFBL0IsSUFBbUMsSUFBdEMsRUFDTDtBQUNJaUIsb0JBQVEsQ0FBQ3pCLElBQVQsQ0FBYyxDQUFkO0FBQ0gsV0FISSxNQUlBLElBQUd1QixZQUFZLENBQUNJLEtBQWIsQ0FBbUJDLEtBQW5CLENBQXlCRixJQUF6QixFQUErQmxCLEVBQS9CLElBQW1DLElBQXRDLEVBQ0w7QUFDSWlCLG9CQUFRLENBQUN6QixJQUFULENBQWMsQ0FBZDtBQUNBeUIsb0JBQVEsQ0FBQ3pCLElBQVQsQ0FBYyxDQUFkO0FBQ0gsV0FKSSxNQUtBLElBQUd1QixZQUFZLENBQUNJLEtBQWIsQ0FBbUJDLEtBQW5CLENBQXlCRixJQUF6QixFQUErQmxCLEVBQS9CLElBQW1DLElBQXRDLEVBQ0w7QUFDSWlCLG9CQUFRLENBQUN6QixJQUFULENBQWMsQ0FBZDtBQUNILFdBSEksTUFJQSxJQUFHdUIsWUFBWSxDQUFDSSxLQUFiLENBQW1CQyxLQUFuQixDQUF5QkYsSUFBekIsRUFBK0JsQixFQUEvQixJQUFtQyxJQUF0QyxFQUNMO0FBQ0lpQixvQkFBUSxDQUFDekIsSUFBVCxDQUFjLENBQWQ7QUFDSDtBQUNKOztBQUVELFlBQUk2QixVQUFVLEdBQUc7QUFDYkosa0JBQVEsRUFBRUEsUUFERztBQUViO0FBQ0FLLGlCQUFPLEVBQUVQLFlBQVksQ0FBQ0ksS0FBYixDQUFtQkcsT0FIZjtBQUliQyxjQUFJLEVBQUUsQ0FBQ1IsWUFBWSxDQUFDSSxLQUFiLENBQW1CSyxtQkFBbkIsQ0FBdUNDLFFBQXZDLEdBQWtEQyxLQUFsRCxDQUF3RCxDQUF4RCxFQUEyRCxDQUEzRCxDQUFELEVBQWdFLEdBQWhFLEVBQXFFWCxZQUFZLENBQUNJLEtBQWIsQ0FBbUJLLG1CQUFuQixDQUF1Q0MsUUFBdkMsR0FBa0RDLEtBQWxELENBQXdELENBQXhELENBQXJFLEVBQWlJQyxJQUFqSSxDQUFzSSxFQUF0SSxDQUpPO0FBS2JDLGlCQUFPLEVBQUU3QixXQUFXLENBQUNBLFdBQVcsQ0FBQzhCLE9BQVosQ0FBb0IsQ0FBQ2QsWUFBWSxDQUFDSSxLQUFiLENBQW1CSyxtQkFBbkIsQ0FBdUNDLFFBQXZDLEdBQWtEQyxLQUFsRCxDQUF3RCxDQUF4RCxFQUEyRCxDQUEzRCxDQUFELEVBQWdFLEdBQWhFLEVBQXFFWCxZQUFZLENBQUNJLEtBQWIsQ0FBbUJLLG1CQUFuQixDQUF1Q0MsUUFBdkMsR0FBa0RDLEtBQWxELENBQXdELENBQXhELENBQXJFLEVBQWlJQyxJQUFqSSxDQUFzSSxFQUF0SSxDQUFwQixJQUFpSyxDQUFsSyxDQUxQO0FBTWJHLGVBQUssRUFBRWYsWUFBWSxDQUFDSSxLQUFiLENBQW1CWSxLQU5iO0FBT2JDLGtCQUFRLEVBQUVqQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJjLFFBQW5CLElBQStCQyxTQUEvQixHQUEyQ25CLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmMsUUFBbkIsQ0FBNEJFLEtBQTVCLElBQXFDRCxTQUFyQyxHQUFpRG5CLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmMsUUFBbkIsQ0FBNEJFLEtBQTVCLENBQWtDbkMsRUFBbkYsR0FBd0YsQ0FBbkksR0FBdUksQ0FQcEk7QUFRYm9DLG9CQUFVLEVBQUVyQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJjLFFBQW5CLElBQStCQyxTQUEvQixHQUEwQ25CLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmMsUUFBbkIsQ0FBNEJFLEtBQTVCLElBQXFDRCxTQUFyQyxHQUFnRG5CLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmMsUUFBbkIsQ0FBNEJFLEtBQTVCLENBQWtDRSxJQUFsRixHQUF5RixFQUFuSSxHQUF1SSxFQVJ0STtBQVNiQyxrQkFBUSxFQUFFdkIsWUFBWSxDQUFDSSxLQUFiLENBQW1CYyxRQUFuQixJQUErQkMsU0FBL0IsR0FBMkNuQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJjLFFBQW5CLENBQTRCRSxLQUE1QixJQUFxQ0QsU0FBckMsR0FBZ0RuQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJjLFFBQW5CLENBQTRCRSxLQUE1QixDQUFrQ0ksUUFBbEYsR0FBNkYsQ0FBeEksR0FBMkksQ0FUeEk7QUFVYkMsb0JBQVUsRUFBRXpCLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmMsUUFBbkIsSUFBK0JDLFNBQS9CLEdBQTJDbkIsWUFBWSxDQUFDSSxLQUFiLENBQW1CYyxRQUFuQixDQUE0QkUsS0FBNUIsSUFBcUNELFNBQXJDLEdBQWdEbkIsWUFBWSxDQUFDSSxLQUFiLENBQW1CYyxRQUFuQixDQUE0QkUsS0FBNUIsQ0FBa0NNLEtBQWxDLENBQXdDSixJQUF4RixHQUE4RixFQUF6SSxHQUE0SSxFQVYzSTtBQVdiSyxxQkFBVyxFQUFFM0IsWUFBWSxDQUFDSSxLQUFiLENBQW1Cd0IsV0FYbkI7QUFZYkMsY0FBSSxFQUFFN0IsWUFBWSxDQUFDSSxLQUFiLENBQW1CMEIsWUFaWjtBQWFiQyxnQkFBTSxFQUFFL0IsWUFBWSxDQUFDSSxLQUFiLENBQW1CYyxRQUFuQixJQUErQkMsU0FBL0IsR0FBMkNuQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJjLFFBQW5CLENBQTRCYyxNQUF2RSxHQUFnRixFQWIzRTtBQWNiQyxrQkFBUSxFQUFDakMsWUFBWSxDQUFDSSxLQUFiLENBQW1CYyxRQUFuQixJQUErQkMsU0FBL0IsR0FBMkNuQixZQUFZLENBQUNJLEtBQWIsQ0FBbUJjLFFBQW5CLENBQTRCZ0IsVUFBdkUsR0FBb0Y7QUFkaEYsU0FBakI7QUFpQkEsWUFBSUMsUUFBUSxHQUFHO0FBQ1hDLHFCQUFXLEVBQUVwQyxZQUFZLENBQUNJLEtBQWIsQ0FBbUJpQyxZQUFuQixDQUFnQ0QsV0FEbEM7QUFFWEUsYUFBRyxFQUFFdEMsWUFBWSxDQUFDSSxLQUFiLENBQW1CaUMsWUFBbkIsQ0FBZ0NFLFFBRjFCO0FBR1hDLGFBQUcsRUFBRXhDLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmlDLFlBQW5CLENBQWdDSSxTQUgxQjtBQUlYQyxxQkFBVyxFQUFFMUMsWUFBWSxDQUFDSSxLQUFiLENBQW1CaUMsWUFBbkIsQ0FBZ0NwRDtBQUpsQyxTQUFmO0FBTUEsWUFBSTBELFVBQVUsR0FBRztBQUNiQywwQkFBZ0IsRUFBRTVDLFlBQVksQ0FBQ0ksS0FBYixDQUFtQmdDLFdBRHhCO0FBRWJTLHFCQUFXLEVBQUU3QyxZQUFZLENBQUNJLEtBQWIsQ0FBbUIwQyxPQUFuQixDQUEyQkM7QUFGM0IsU0FBakI7QUFLQXJGLG9CQUFZLENBQUM0QyxVQUFELENBQVo7QUFDQTFDLGtCQUFVLENBQUN1RSxRQUFELENBQVY7QUFDQXJFLG9CQUFZLENBQUM2RSxVQUFELENBQVo7QUFDQXZGLG9CQUFZLENBQUMsSUFBRCxDQUFaOztBQUNBLFlBQUk0RixRQUFRLENBQUNDLGNBQVQsQ0FBd0IscUJBQXhCLEtBQWtEOUIsU0FBdEQsRUFBaUU7QUFDN0QsY0FBSStCLEtBQUssR0FBR0YsUUFBUSxDQUFDQyxjQUFULENBQXdCLHFCQUF4QixDQUFaO0FBQ0FDLGVBQUssQ0FBQ0MsTUFBTjtBQUNIO0FBQ0o7QUFDSixLQTlFVyxXQStFTCxVQUFBQyxHQUFHLEVBQUk7QUFDVkMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLEdBQVo7QUFDSCxLQWpGVyxDQUFoQixDQUh1QixDQXFGdkI7O0FBQ0FHLGNBQVUsQ0FBQztBQUFBLGFBQU1sRSxlQUFlLENBQUNtRSxLQUFoQixFQUFOO0FBQUEsS0FBRCxFQUFnQ3hGLE1BQWhDLENBQVY7QUFDSCxHQXZGRDs7QUF3RkFrQixpREFBUSxDQUFDdUUsTUFBVCxDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDakJDLFNBQUssRUFBRSxPQURVO0FBRWpCQyxXQUFPLEVBQUUsS0FGUTtBQUdqQkMsWUFBUSxFQUFFLE1BSE87QUFJakJDLGNBQVUsRUFBRSxhQUpLO0FBS2pCQyxZQUFRLEVBQUUsWUFMTztBQU1qQkMsZUFBVyxFQUFFLElBTkk7QUFPakJDLE9BQUcsRUFBRSxJQVBZO0FBUWpCQyxxQkFBaUIsRUFBRTtBQVJGLEdBQXJCOztBQVVBLE1BQU1DLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUNDLFVBQUQsRUFBZ0I7QUFDaENsRixtREFBUSxDQUFDQyxPQUFULENBQWlCQyxJQUFqQjtBQUNBLFFBQUlpRixJQUFJLEdBQUcsSUFBSUMsUUFBSixFQUFYO0FBQ0FELFFBQUksQ0FBQ0UsTUFBTCxDQUFZLGNBQVosRUFBNEI5RyxTQUFTLENBQUN3RCxRQUF0QztBQUNBLFFBQUl4RCxTQUFTLENBQUNrRSxXQUFWLEdBQXdCLENBQTVCLEVBQStCMEMsSUFBSSxDQUFDRSxNQUFMLENBQVksYUFBWixFQUEyQjlHLFNBQVMsQ0FBQ2tFLFdBQXJDO0FBQy9CLFFBQUlsRSxTQUFTLENBQUNzRSxNQUFWLElBQW9CWixTQUF4QixFQUFtQ2tELElBQUksQ0FBQ0UsTUFBTCxDQUFZLFlBQVosRUFBMEI5RyxTQUFTLENBQUNzRSxNQUFwQztBQUNuQyxRQUFJdEUsU0FBUyxDQUFDK0csT0FBVixJQUFxQnJELFNBQXpCLEVBQW9Da0QsSUFBSSxDQUFDRSxNQUFMLENBQVksZ0JBQVosRUFBOEI5RyxTQUFTLENBQUMrRyxPQUF4QztBQUNwQ0gsUUFBSSxDQUFDRSxNQUFMLENBQVksU0FBWixFQUF1QjlHLFNBQVMsQ0FBQzhDLE9BQWpDO0FBQ0E4RCxRQUFJLENBQUNFLE1BQUwsQ0FBWSxVQUFaLEVBQXdCckcsSUFBSSxDQUFDdUcsU0FBTCxDQUFlaEgsU0FBUyxDQUFDeUMsUUFBekIsQ0FBeEI7QUFDQW1FLFFBQUksQ0FBQ0UsTUFBTCxDQUFZLGFBQVosRUFBMkI5RyxTQUFTLENBQUNvRSxJQUFWLEdBQWlCLElBQTVDO0FBQ0F3QyxRQUFJLENBQUNFLE1BQUwsQ0FBWSxjQUFaLEVBQTRCOUcsU0FBUyxDQUFDK0MsSUFBdEM7QUFDQTZELFFBQUksQ0FBQ0UsTUFBTCxDQUFZLG1CQUFaLEVBQWlDNUcsT0FBTyxDQUFDNkUsR0FBekM7QUFDQTZCLFFBQUksQ0FBQ0UsTUFBTCxDQUFZLGtCQUFaLEVBQWdDNUcsT0FBTyxDQUFDMkUsR0FBeEM7QUFDQStCLFFBQUksQ0FBQ0UsTUFBTCxDQUFZLGNBQVosRUFBNEIsRUFBNUI7QUFDQSxRQUFJNUcsT0FBTyxDQUFDeUUsV0FBUixJQUF1QmpCLFNBQTNCLEVBQXNDa0QsSUFBSSxDQUFDRSxNQUFMLENBQVkscUJBQVosRUFBbUM1RyxPQUFPLENBQUN5RSxXQUEzQztBQUN0QyxRQUFJekUsT0FBTyxDQUFDK0UsV0FBUixJQUF1QnZCLFNBQXZCLElBQW9DeEQsT0FBTyxDQUFDK0UsV0FBUixJQUF1QixDQUEvRCxFQUFrRTJCLElBQUksQ0FBQ0UsTUFBTCxDQUFZLGlCQUFaLEVBQStCNUcsT0FBTyxDQUFDK0UsV0FBdkM7QUFDbEUsUUFBSS9FLE9BQU8sQ0FBQ3lFLFdBQVIsSUFBdUJqQixTQUEzQixFQUFzQ2tELElBQUksQ0FBQ0UsTUFBTCxDQUFZLGFBQVosRUFBMkJILFVBQVUsQ0FBQ3hCLGdCQUF0QztBQUN0Q3lCLFFBQUksQ0FBQ0UsTUFBTCxDQUFZLGdCQUFaLEVBQThCSCxVQUFVLENBQUN2QixXQUF6QztBQUVBNkIsZ0RBQUssQ0FBQ0MsSUFBTixDQUFXNUcsR0FBRyxHQUFHLFFBQWpCLEVBQTJCc0csSUFBM0IsRUFBaUM7QUFDN0I1RSxhQUFPLEVBQUU7QUFDTCxrQkFBVSxrQkFETDtBQUVMLG9CQUFZLE1BRlA7QUFFaUI7QUFDdEIsd0JBQWdCLGtCQUhYO0FBSUwsdUNBQStCLEdBSjFCO0FBS0wseUJBQWlCLFlBQVl4QjtBQUx4QjtBQURvQixLQUFqQyxFQVNLNEIsSUFUTCxDQVNVLFVBQUNHLFlBQUQsRUFBa0I7QUFDcEIsVUFBSUEsWUFBWSxDQUFDcUUsSUFBYixDQUFrQnBFLE9BQWxCLElBQTZCLDJCQUFqQyxFQUE4RDtBQUMxRCxZQUFJK0MsUUFBUSxDQUFDQyxjQUFULENBQXdCLG9CQUF4QixLQUFpRDlCLFNBQXJELEVBQWdFO0FBQzVELGNBQUkrQixLQUFLLEdBQUdGLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixvQkFBeEIsQ0FBWjtBQUNBQyxlQUFLLENBQUNDLE1BQU47QUFDSDs7QUFDRCxZQUFJSCxRQUFRLENBQUNDLGNBQVQsQ0FBd0IscUJBQXhCLEtBQWtEOUIsU0FBdEQsRUFBaUU7QUFDN0QsY0FBSStCLEtBQUssR0FBR0YsUUFBUSxDQUFDQyxjQUFULENBQXdCLHFCQUF4QixDQUFaO0FBQ0FDLGVBQUssQ0FBQ0MsTUFBTjtBQUNIOztBQUVELFlBQUluRCxZQUFZLENBQUNxRSxJQUFiLENBQWtCTyxZQUFsQixJQUFrQyxJQUF0QyxFQUE0QztBQUN4QzFGLHlEQUFRLENBQUN1RSxNQUFULENBQWdCb0IsT0FBaEIsQ0FBd0Isa0NBQXhCO0FBQ0EvSCxnQkFBTSxDQUFDMkIsSUFBUCxDQUFZdUIsWUFBWSxDQUFDcUUsSUFBYixDQUFrQk8sWUFBbEIsQ0FBK0JFLFFBQS9CLENBQXdDQyxNQUFwRDtBQUNILFNBSEQsTUFHTztBQUNIN0YseURBQVEsQ0FBQ3VFLE1BQVQsQ0FBZ0JvQixPQUFoQixDQUF3QiwyQkFBeEI7QUFDQS9ILGdCQUFNLENBQUMyQixJQUFQLENBQVksZUFBWjtBQUNIO0FBRUo7QUFDSixLQTdCTCxXQThCVyxVQUFDdUcsS0FBRCxFQUFXO0FBQ2QsVUFBSUEsS0FBSyxDQUFDL0UsT0FBTixJQUFpQixxQ0FBckIsRUFDSWdGLHdFQUFXO0FBQ2xCLEtBakNMO0FBa0NILEdBckREOztBQXVEQSxNQUFNQyxXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFDQyxJQUFELEVBQU9DLElBQVAsRUFBZ0I7QUFDaEMsWUFBUUQsSUFBUjtBQUNJLFdBQUssT0FBTDtBQUNJL0gsb0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQUUsa0JBQVUsQ0FBQyxJQUFELENBQVY7QUFDQUUsd0JBQWdCLENBQUMsS0FBRCxDQUFoQjtBQUNBRSxvQkFBWSxDQUFDMEgsSUFBRCxDQUFaO0FBQ0EvQixlQUFPLENBQUNDLEdBQVIsQ0FBWThCLElBQVo7QUFDQTs7QUFDSixXQUFLLEtBQUw7QUFDSSxZQUFJcEMsUUFBUSxDQUFDQyxjQUFULENBQXdCLHFCQUF4QixLQUFrRDlCLFNBQXRELEVBQWlFO0FBQzdELGNBQUkrQixLQUFLLEdBQUdGLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixxQkFBeEIsQ0FBWjtBQUNBQyxlQUFLLENBQUNDLE1BQU47QUFDSDs7QUFDRC9GLG9CQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0FFLGtCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0FFLHdCQUFnQixDQUFDLElBQUQsQ0FBaEI7QUFDQUksa0JBQVUsQ0FBQ3dILElBQUQsQ0FBVjtBQUNBL0IsZUFBTyxDQUFDQyxHQUFSLENBQVk4QixJQUFaO0FBQ0E7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ2dCOztBQUNKLFdBQUssV0FBTDtBQUNJdEgsb0JBQVksQ0FBQ3NILElBQUQsQ0FBWjtBQUNBakIsbUJBQVcsQ0FBQ2lCLElBQUQsQ0FBWDtBQUNBOztBQUNKLFdBQUssV0FBTDtBQUNJdEgsb0JBQVksQ0FBQ3NILElBQUQsQ0FBWjtBQUNBaEksb0JBQVksQ0FBQyxJQUFELENBQVo7QUFDQUUsa0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDQUUsd0JBQWdCLENBQUMsS0FBRCxDQUFoQjtBQUNBOztBQUNKO0FBQ0lKLG9CQUFZLENBQUMsSUFBRCxDQUFaO0FBQ0FFLGtCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0FFLHdCQUFnQixDQUFDLEtBQUQsQ0FBaEI7QUF4Q1I7QUEwQ0gsR0EzQ0Q7O0FBNENBLFNBQ0lQLElBQUksaUJBQUkscUVBQUMsNENBQUQsQ0FBTyxRQUFQO0FBQUEsNEJBQ0oscUVBQUMsMEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURJLEVBRUhFLFNBQVMsaUJBQUkscUVBQUMsK0RBQUQ7QUFBTyxVQUFJLEVBQUVBLFNBQWI7QUFBd0IsY0FBUSxFQUFFK0gsV0FBbEM7QUFBK0MsZUFBUyxFQUFFekgsU0FBMUQ7QUFBcUUsYUFBTyxFQUFFRTtBQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRlYsRUFHSE4sT0FBTyxpQkFBSSxxRUFBQyw4REFBRDtBQUFLLFVBQUksRUFBRUEsT0FBWDtBQUFvQixjQUFRLEVBQUU2SCxXQUE5QjtBQUEyQyxlQUFTLEVBQUV6SCxTQUF0RDtBQUFpRSxhQUFPLEVBQUVFO0FBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFIUixFQUlISixhQUFhLGlCQUNkLHFFQUFDLG1FQUFEO0FBQVcsVUFBSSxFQUFFQSxhQUFqQjtBQUFnQyxjQUFRLEVBQUUySCxXQUExQztBQUF1RCxlQUFTLEVBQUV6SCxTQUFsRTtBQUE2RSxhQUFPLEVBQUVFLE9BQXRGO0FBQ1csZUFBUyxFQUFFRTtBQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRFo7QUFVSDs7R0E3T3VCaEIsVztVQUNMRSxxRDs7O0tBREtGLFciLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvb3JkZXIvW2lkXS4wNDAxMTUwY2Q5NDUxMjM3YWQxZC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7dXNlRWZmZWN0LCB1c2VTdGF0ZX0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7dXNlUm91dGVyfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgTm90aWZsaXggZnJvbSBcIm5vdGlmbGl4XCI7XHJcbmltcG9ydCB7cm91dGV9IGZyb20gXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvc2VydmVyL3JvdXRlclwiO1xyXG5pbXBvcnQgVG9vbGJhciBmcm9tIFwiLi4vLi4vY29udGFpbmVycy9IZWFkZXIvVG9vbGJhci9Ub29sYmFyXCI7XHJcbmltcG9ydCBPcmRlciBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9vcmRlci9vcmRlclwiXHJcbmltcG9ydCBNYXAgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvb3JkZXIvbWFwcFwiXHJcbmltcG9ydCBPcmRlckluZm8gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvb3JkZXIvb3JkZXJJbmZvXCJcclxuaW1wb3J0IHtWZXJpZnlUb2tlbn0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvSGVscGVyc1wiXHJcbmltcG9ydCBkZWxCdG4gZnJvbSBcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvZGVsLnN2Z1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ3JlYXRlT3JkZXIoKSB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG4gICAgY29uc3QgW3Nob3csIHNldFNob3ddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Nob3dPcmRlciwgc2V0U2hvd09yZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtzaG93TWFwLCBzZXRTaG93TWFwXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtzaG93T3JkZXJJbmZvLCBzZXRTaG93T3JkZXJJbmZvXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtvcmRlckRhdGEsIHNldE9yZGVyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbbWFwRGF0YSwgc2V0TWFwRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbb3JkZXJJbmZvLCBzZXRPcmRlckluZm9dID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICAgIGxldCB1cmwgPSBwcm9jZXNzLmVudi51cmw7XHJcbiAgICBsZXQgdG9rZW47XHJcbiAgICBpZiAocHJvY2Vzcy5icm93c2VyKVxyXG4gICAgICAgIHRva2VuID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYWNjZXNzVG9rZW4nKSk7XHJcbiAgICBsZXQgbGluaywgY29kZTtcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKHRva2VuICE9IG51bGwpXHJcbiAgICAgICAgICAgIHNldFNob3codHJ1ZSlcclxuICAgICAgICBlbHNlIHJvdXRlci5wdXNoKCcvJylcclxuICAgICAgICBsaW5rID0gd2luZG93LmxvY2F0aW9uLmhyZWYuc3BsaXQoJy8nKTtcclxuICAgICAgICBpZiAobGlua1tsaW5rLmxlbmd0aCAtIDJdID09IFwib3JkZXJcIikge1xyXG4gICAgICAgICAgICBjb2RlID0gbGlua1tsaW5rLmxlbmd0aCAtIDFdO1xyXG4gICAgICAgICAgICBmZXRjaE9yZGVyKGNvZGUpXHJcbiAgICAgICAgfVxyXG4gICAgfSwgW10pO1xyXG4gICAgbGV0IHRpbWVzSG9sZGVyID0gW1wiMDY6MDBcIiwgXCIwNjozMFwiLCBcIjA3OjAwXCIsIFwiMDc6MzBcIiwgXCIwODowMFwiLCBcIjA4OjMwXCIsIFwiMDk6MDBcIiwgXCIwOTozMFwiLCBcIjEwOjAwXCIsIFwiMTA6MzBcIiwgXCIxMTowMFwiLCBcIjExOjMwXCIsXHJcbiAgICAgICAgXCIxMjowMFwiLCBcIjEyOjMwXCIsIFwiMTM6MDBcIiwgXCIxMzozMFwiLCBcIjE0OjAwXCIsIFwiMTQ6MzBcIiwgXCIxNTowMFwiLCBcIjE1OjMwXCIsXHJcbiAgICAgICAgXCIxNjowMFwiLCBcIjE2OjMwXCIsIFwiMTc6MDBcIiwgXCIxNzozMFwiLCBcIjE4OjAwXCIsIFwiMTg6MzBcIiwgXCIxOTowMFwiLCBcIjE5OjMwXCIsXHJcbiAgICAgICAgXCIyMDowMFwiLCBcIjIwOjMwXCIsIFwiMjE6MDBcIiwgXCIyMTozMFwiLCBcIjIyOjAwXCIsIFwiMjI6MzBcIiwgXCIyMzowMFwiLCBcIjIzOjMwXCIsIFwiMjQ6MDBcIiwgXCIwMDozMFwiLCBcIjAxOjAwXCIsIFwiMDE6MzBcIiwgXCIwMjowMFwiXHJcbiAgICBdO1xyXG4gICAgY29uc3QgZmV0Y2hPcmRlciA9IChpZCkgPT4ge1xyXG4gICAgICAgIE5vdGlmbGl4LkxvYWRpbmcuRG90cygpO1xyXG4gICAgICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxyXG4gICAgICAgIGNvbnN0IHByb21pc2UgPSB3aW5kb3dcclxuICAgICAgICAgICAgLmZldGNoKHVybCArICcvb3JkZXIvJyArIGlkLCB7XHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2VwdCc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdkYXRhVHlwZSc6ICdqc29ucCcsICAgLy95b3UgbWF5IHVzZSBqc29ucCBmb3IgY3Jvc3Mgb3JpZ2luIHJlcXVlc3RcclxuICAgICAgICAgICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIgKyB0b2tlblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgICAgICAgICAgICBtb2RlOiAnY29ycycsXHJcbiAgICAgICAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpXHJcbiAgICAgICAgICAgIC50aGVuKHJlc3BvbnNlSnNvbiA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2VKc29uLm1lc3NhZ2UgPT0gXCLYs9mB2KfYsdi0INio2Kcg2YXZiNmB2YLbjNiqINiv2LHbjNin2YHYqiDYtNivXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2VydmljZXM9W11cclxuICAgICAgICAgICAgICAgICAgICBmb3IobGV0IGl0ZW0gaW4gcmVzcG9uc2VKc29uLm9yZGVyLml0ZW1zKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYocmVzcG9uc2VKc29uLm9yZGVyLml0ZW1zW2l0ZW1dLmlkPT1cIjU2XCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2VzLnB1c2goMSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmKHJlc3BvbnNlSnNvbi5vcmRlci5pdGVtc1tpdGVtXS5pZD09XCI2NlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJ2aWNlcy5wdXNoKDIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZihyZXNwb25zZUpzb24ub3JkZXIuaXRlbXNbaXRlbV0uaWQ9PVwiNjdcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VydmljZXMucHVzaCgxKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VydmljZXMucHVzaCgyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYocmVzcG9uc2VKc29uLm9yZGVyLml0ZW1zW2l0ZW1dLmlkPT1cIjY4XCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2VzLnB1c2goNClcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmKHJlc3BvbnNlSnNvbi5vcmRlci5pdGVtc1tpdGVtXS5pZD09XCI2OVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJ2aWNlcy5wdXNoKDUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfb3JkZXJEYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXJ2aWNlczogc2VydmljZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vc2VydmljZXNUaXRsZTogc2VydmljZXNUaXRsZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWJzZW5jZTogcmVzcG9uc2VKc29uLm9yZGVyLmFic2VuY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpbWU6IFtyZXNwb25zZUpzb24ub3JkZXIuaHVtYW5fcmVzZXJ2ZWRfdGltZS50b1N0cmluZygpLnNsaWNlKDAsIDIpLCBcIjpcIiwgcmVzcG9uc2VKc29uLm9yZGVyLmh1bWFuX3Jlc2VydmVkX3RpbWUudG9TdHJpbmcoKS5zbGljZSgyKV0uam9pbignJyksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVuZFRpbWU6IHRpbWVzSG9sZGVyW3RpbWVzSG9sZGVyLmluZGV4T2YoW3Jlc3BvbnNlSnNvbi5vcmRlci5odW1hbl9yZXNlcnZlZF90aW1lLnRvU3RyaW5nKCkuc2xpY2UoMCwgMiksIFwiOlwiLCByZXNwb25zZUpzb24ub3JkZXIuaHVtYW5fcmVzZXJ2ZWRfdGltZS50b1N0cmluZygpLnNsaWNlKDIpXS5qb2luKCcnKSkgKyA0XSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJpY2U6IHJlc3BvbnNlSnNvbi5vcmRlci50b3RhbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FyTW9kZWw6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2NhciAhPSB1bmRlZmluZWQgPyByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIubW9kZWwgIT0gdW5kZWZpbmVkID8gcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyLm1vZGVsLmlkIDogMCA6IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1vZGVsVGl0bGU6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2NhciAhPSB1bmRlZmluZWQgP3Jlc3BvbnNlSnNvbi5vcmRlci51c2VyX2Nhci5tb2RlbCAhPSB1bmRlZmluZWQgP3Jlc3BvbnNlSnNvbi5vcmRlci51c2VyX2Nhci5tb2RlbC5uYW1lIDogXCJcIjogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FyQnJhbmQ6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2NhciAhPSB1bmRlZmluZWQgPyByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIubW9kZWwgIT0gdW5kZWZpbmVkID9yZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIubW9kZWwuYnJhbmRfaWQgOiAwOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmFuZFRpdGxlOiByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIgIT0gdW5kZWZpbmVkID8gcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyLm1vZGVsICE9IHVuZGVmaW5lZCA/cmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyLm1vZGVsLmJyYW5kLm5hbWUgOlwiXCI6XCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRDYXI6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2Nhcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZTogcmVzcG9uc2VKc29uLm9yZGVyLnJlc2VydmVkX2RheSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FyVGFnOiByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIgIT0gdW5kZWZpbmVkID8gcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfY2FyLnBsYXF1ZSA6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhcmRGaWxlOnJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2NhciAhPSB1bmRlZmluZWQgPyByZXNwb25zZUpzb24ub3JkZXIudXNlcl9jYXIuY2FyZF9pbWFnZSA6IFwiXCJcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfbWFwRGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2FkZHJlc3MuZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhdDogcmVzcG9uc2VKc29uLm9yZGVyLnVzZXJfYWRkcmVzcy5sYXRpdHVkZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG5nOiByZXNwb25zZUpzb24ub3JkZXIudXNlcl9hZGRyZXNzLmxvbmdpdHVkZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXNlckFkZHJlc3M6IHJlc3BvbnNlSnNvbi5vcmRlci51c2VyX2FkZHJlc3MuaWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IF9vcmRlckluZm8gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZGVyRGVzY3JpcHRpb246IHJlc3BvbnNlSnNvbi5vcmRlci5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudFR5cGU6IHJlc3BvbnNlSnNvbi5vcmRlci5wYXltZW50LnBheW1lbnRfbWV0aG9kLFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0T3JkZXJEYXRhKF9vcmRlckRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldE1hcERhdGEoX21hcERhdGEpXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0T3JkZXJJbmZvKF9vcmRlckluZm8pXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd09yZGVyKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiTm90aWZsaXhMb2FkaW5nV3JhcFwiKSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG15b2JqID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJOb3RpZmxpeExvYWRpbmdXcmFwXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBteW9iai5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5jYXRjaChlcnIgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIC8vIENhbmNlbCB0aGUgcmVxdWVzdCBpZiBpdCB0YWtlcyBtb3JlIHRoYW4gZGVsYXlGZXRjaCBzZWNvbmRzXHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBhYm9ydENvbnRyb2xsZXIuYWJvcnQoKSwgcHJvY2Vzcy5lbnYuZGVsYXlGZXRjaClcclxuICAgIH07XHJcbiAgICBOb3RpZmxpeC5Ob3RpZnkuSW5pdCh7XHJcbiAgICAgICAgd2lkdGg6ICcyNTBweCcsXHJcbiAgICAgICAgdXNlSWNvbjogZmFsc2UsXHJcbiAgICAgICAgZm9udFNpemU6ICcxNHB4JyxcclxuICAgICAgICBmb250RmFtaWx5OiBcIklSQU5TYW5zV2ViXCIsXHJcbiAgICAgICAgcG9zaXRpb246IFwiY2VudGVyLXRvcFwiLFxyXG4gICAgICAgIGNsb3NlQnV0dG9uOiB0cnVlLFxyXG4gICAgICAgIHJ0bDogdHJ1ZSxcclxuICAgICAgICBjc3NBbmltYXRpb25TdHlsZTogJ2Zyb20tdG9wJ1xyXG4gICAgfSk7XHJcbiAgICBjb25zdCBjcmVhdGVPcmRlciA9IChvcmRlckluZm9zKSA9PiB7XHJcbiAgICAgICAgTm90aWZsaXguTG9hZGluZy5Eb3RzKCk7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBuZXcgRm9ybURhdGEoKVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdjYXJfbW9kZWxfaWQnLCBvcmRlckRhdGEuY2FyTW9kZWwpXHJcbiAgICAgICAgaWYgKG9yZGVyRGF0YS5zZWxlY3RlZENhciA+IDApIGRhdGEuYXBwZW5kKCd1c2VyX2Nhcl9pZCcsIG9yZGVyRGF0YS5zZWxlY3RlZENhcilcclxuICAgICAgICBpZiAob3JkZXJEYXRhLmNhclRhZyAhPSB1bmRlZmluZWQpIGRhdGEuYXBwZW5kKCdjYXJfcGxhcXVlJywgb3JkZXJEYXRhLmNhclRhZylcclxuICAgICAgICBpZiAob3JkZXJEYXRhLmNhcmRJbWcgIT0gdW5kZWZpbmVkKSBkYXRhLmFwcGVuZCgnY2FyX2NhcmRfaW1hZ2UnLCBvcmRlckRhdGEuY2FyZEltZylcclxuICAgICAgICBkYXRhLmFwcGVuZCgnYWJzZW5jZScsIG9yZGVyRGF0YS5hYnNlbmNlKVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdzZXJ2aWNlcycsIEpTT04uc3RyaW5naWZ5KG9yZGVyRGF0YS5zZXJ2aWNlcykpXHJcbiAgICAgICAgZGF0YS5hcHBlbmQoJ3Jlc2VydmVfZGF5Jywgb3JkZXJEYXRhLmRhdGUgLyAxMDAwKVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdyZXNlcnZlX3RpbWUnLCBvcmRlckRhdGEudGltZSlcclxuICAgICAgICBkYXRhLmFwcGVuZCgnYWRkcmVzc19sb25naXR1ZGUnLCBtYXBEYXRhLmxuZylcclxuICAgICAgICBkYXRhLmFwcGVuZCgnYWRkcmVzc19sYXRpdHVkZScsIG1hcERhdGEubGF0KVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdhZGRyZXNzX25hbWUnLCBcIlwiKVxyXG4gICAgICAgIGlmIChtYXBEYXRhLmRlc2NyaXB0aW9uICE9IHVuZGVmaW5lZCkgZGF0YS5hcHBlbmQoJ2FkZHJlc3NfZGVzY3JpcHRpb24nLCBtYXBEYXRhLmRlc2NyaXB0aW9uKVxyXG4gICAgICAgIGlmIChtYXBEYXRhLnVzZXJBZGRyZXNzICE9IHVuZGVmaW5lZCAmJiBtYXBEYXRhLnVzZXJBZGRyZXNzICE9IDApIGRhdGEuYXBwZW5kKCd1c2VyX2FkZHJlc3NfaWQnLCBtYXBEYXRhLnVzZXJBZGRyZXNzKVxyXG4gICAgICAgIGlmIChtYXBEYXRhLmRlc2NyaXB0aW9uICE9IHVuZGVmaW5lZCkgZGF0YS5hcHBlbmQoJ2Rlc2NyaXB0aW9uJywgb3JkZXJJbmZvcy5vcmRlckRlc2NyaXB0aW9uKVxyXG4gICAgICAgIGRhdGEuYXBwZW5kKCdwYXltZW50X21ldGhvZCcsIG9yZGVySW5mb3MuUGF5bWVudFR5cGUpXHJcblxyXG4gICAgICAgIGF4aW9zLnBvc3QodXJsICsgJy9vcmRlcicsIGRhdGEsIHtcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgJ0FjY2VwdCc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICdkYXRhVHlwZSc6ICdqc29uJywgICAvL3lvdSBtYXkgdXNlIGpzb25wIGZvciBjcm9zcyBvcmlnaW4gcmVxdWVzdFxyXG4gICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIgKyB0b2tlblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICAgICAgLnRoZW4oKHJlc3BvbnNlSnNvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlSnNvbi5kYXRhLm1lc3NhZ2UgPT0gXCLYr9ix2K7ZiNin2LPYqiDYqNinINmF2YjZgdmC24zYqiDYq9io2Kog2LTYry5cIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIk5vdGlmbGl4Tm90aWZ5V3JhcFwiKSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG15b2JqID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJOb3RpZmxpeE5vdGlmeVdyYXBcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG15b2JqLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJOb3RpZmxpeExvYWRpbmdXcmFwXCIpICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbXlvYmogPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIk5vdGlmbGl4TG9hZGluZ1dyYXBcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG15b2JqLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlSnNvbi5kYXRhLnBheW1lbnRfZGF0YSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5vdGlmbGl4Lk5vdGlmeS5TdWNjZXNzKCfYqNmHINiv2LHar9in2Ycg2b7Ysdiv2KfYrtiqINmF2YbYqtmC2YQg2YXbjCDYtNmI24zYry4uLicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByb3V0ZXIucHVzaChyZXNwb25zZUpzb24uZGF0YS5wYXltZW50X2RhdGEub3JpZ2luYWwuYWN0aW9uKVxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5vdGlmbGl4Lk5vdGlmeS5TdWNjZXNzKCfYr9ix2K7ZiNin2LPYqiDYqNinINmF2YjZgdmC24zYqiDYq9io2Kog2LTYry4nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm91dGVyLnB1c2goXCIvcGF5bWVudC9jYXNoXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKGVycm9yLm1lc3NhZ2UgPT0gXCJSZXF1ZXN0IGZhaWxlZCB3aXRoIHN0YXR1cyBjb2RlIDQwMVwiKVxyXG4gICAgICAgICAgICAgICAgICAgIFZlcmlmeVRva2VuKCk7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdG9nZ2xlRm9ybXMgPSAoZm9ybSwgRGF0YSkgPT4ge1xyXG4gICAgICAgIHN3aXRjaCAoZm9ybSkge1xyXG4gICAgICAgICAgICBjYXNlIFwib3JkZXJcIiA6XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93T3JkZXIoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TWFwKHRydWUpXHJcbiAgICAgICAgICAgICAgICBzZXRTaG93T3JkZXJJbmZvKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgc2V0T3JkZXJEYXRhKERhdGEpXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhEYXRhKVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJtYXBcIiA6XHJcbiAgICAgICAgICAgICAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJOb3RpZmxpeExvYWRpbmdXcmFwXCIpICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBteW9iaiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiTm90aWZsaXhMb2FkaW5nV3JhcFwiKTtcclxuICAgICAgICAgICAgICAgICAgICBteW9iai5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlcihmYWxzZSlcclxuICAgICAgICAgICAgICAgIHNldFNob3dNYXAoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBzZXRTaG93T3JkZXJJbmZvKHRydWUpXHJcbiAgICAgICAgICAgICAgICBzZXRNYXBEYXRhKERhdGEpXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhEYXRhKVxyXG4gICAgICAgICAgICAgICAgLyppZihEYXRhLmRlc2NyaXB0aW9uIT1cIlwiICYmIERhdGEuZGVzY3JpcHRpb24hPXVuZGVmaW5lZCAmJiBEYXRhLmRlc2NyaXB0aW9uIT1udWxsKVxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dPcmRlcihmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TWFwKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dPcmRlckluZm8odHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICBzZXRNYXBEYXRhKERhdGEpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIE5vdGlmbGl4Lk5vdGlmeS5GYWlsdXJlKCfZhNi32YHYpyDYotiv2LHYsyDYrtmI2K8g2LHYpyDZiNin2LHYryDaqdmG24zYry4nKTsqL1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJvcmRlckluZm9cIiA6XHJcbiAgICAgICAgICAgICAgICBzZXRPcmRlckluZm8oRGF0YSlcclxuICAgICAgICAgICAgICAgIGNyZWF0ZU9yZGVyKERhdGEpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJlZGl0T3JkZXJcIiA6XHJcbiAgICAgICAgICAgICAgICBzZXRPcmRlckluZm8oRGF0YSlcclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlcih0cnVlKVxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd01hcChmYWxzZSlcclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlckluZm8oZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlcih0cnVlKVxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd01hcChmYWxzZSlcclxuICAgICAgICAgICAgICAgIHNldFNob3dPcmRlckluZm8oZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICBzaG93ICYmIDxSZWFjdC5GcmFnbWVudD5cclxuICAgICAgICAgICAgPFRvb2xiYXIvPlxyXG4gICAgICAgICAgICB7c2hvd09yZGVyICYmIDxPcmRlciBzaG93PXtzaG93T3JkZXJ9IGNhbGxiYWNrPXt0b2dnbGVGb3Jtc30gb3JkZXJEYXRhPXtvcmRlckRhdGF9IG1hcERhdGE9e21hcERhdGF9Lz59XHJcbiAgICAgICAgICAgIHtzaG93TWFwICYmIDxNYXAgc2hvdz17c2hvd01hcH0gY2FsbGJhY2s9e3RvZ2dsZUZvcm1zfSBvcmRlckRhdGE9e29yZGVyRGF0YX0gbWFwRGF0YT17bWFwRGF0YX0vPn1cclxuICAgICAgICAgICAge3Nob3dPcmRlckluZm8gJiZcclxuICAgICAgICAgICAgPE9yZGVySW5mbyBzaG93PXtzaG93T3JkZXJJbmZvfSBjYWxsYmFjaz17dG9nZ2xlRm9ybXN9IG9yZGVyRGF0YT17b3JkZXJEYXRhfSBtYXBEYXRhPXttYXBEYXRhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgIG9yZGVySW5mbz17b3JkZXJJbmZvfS8+fVxyXG4gICAgICAgIDwvUmVhY3QuRnJhZ21lbnQ+XHJcbiAgICApXHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==