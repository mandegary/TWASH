webpackHotUpdate_N_E("pages/order",{

/***/ "./components/order/order.js":
/*!***********************************!*\
  !*** ./components/order/order.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var D_MyProjects_TWash_twash_app_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var D_MyProjects_TWash_twash_app_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(D_MyProjects_TWash_twash_app_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _order_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./order.css */ "./components/order/order.css");
/* harmony import */ var _order_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_order_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/Dialog */ "./node_modules/@material-ui/core/esm/Dialog/index.js");
/* harmony import */ var _material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/DialogActions */ "./node_modules/@material-ui/core/esm/DialogActions/index.js");
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/DialogContent */ "./node_modules/@material-ui/core/esm/DialogContent/index.js");
/* harmony import */ var _material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/core/DialogContentText */ "./node_modules/@material-ui/core/esm/DialogContentText/index.js");
/* harmony import */ var _material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core/DialogTitle */ "./node_modules/@material-ui/core/esm/DialogTitle/index.js");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
/* harmony import */ var _material_ui_lab_Autocomplete__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @material-ui/lab/Autocomplete */ "./node_modules/@material-ui/lab/esm/Autocomplete/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/index.js");
/* harmony import */ var react_datepicker2__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-datepicker2 */ "./node_modules/react-datepicker2/dist/umd/index.js");
/* harmony import */ var react_datepicker2__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_datepicker2__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var moment_jalaali__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! moment-jalaali */ "./node_modules/moment-jalaali/index.js");
/* harmony import */ var moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(moment_jalaali__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _assets_images_down_png__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../assets/images/down.png */ "./assets/images/down.png");
/* harmony import */ var _assets_images_down_png__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_assets_images_down_png__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _assets_images_cloud_computing_png__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../assets/images/cloud-computing.png */ "./assets/images/cloud-computing.png");
/* harmony import */ var _assets_images_cloud_computing_png__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_assets_images_cloud_computing_png__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var persian_tools2__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! persian-tools2 */ "./node_modules/persian-tools2/dist/index.bowser.js");
/* harmony import */ var persian_tools2__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(persian_tools2__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var notiflix__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! notiflix */ "./node_modules/notiflix/dist/notiflix-aio-2.7.0.min.js");
/* harmony import */ var notiflix__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(notiflix__WEBPACK_IMPORTED_MODULE_23__);






var _jsxFileName = "D:\\MyProjects\\TWash\\twash-app\\components\\order\\order.js",
    _this = undefined,
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





















var theme = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_13__["createMuiTheme"])({
  direction: 'rtl'
});

function rand() {
  return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
  var top = 50 + rand();
  var left = 50 + rand();
  return {
    top: "".concat(top, "%"),
    left: "".concat(left, "%"),
    transform: "translate(-".concat(top, "%, -").concat(left, "%)")
  };
}

var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_13__["makeStyles"])(function (theme) {
  return {
    paper: {
      position: 'absolute',
      width: 400,
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3)
    }
  };
});

var Order = function Order(props) {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_18__["useRouter"])();
  var classes = useStyles();

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_5___default.a.useState(getModalStyle),
      _React$useState2 = Object(D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_4__["default"])(_React$useState, 1),
      modalStyle = _React$useState2[0];

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      errorMessage = _useState[0],
      setErrorMessage = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(true),
      btnDisabled = _useState2[0],
      setBtnDisabled = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      carBrandTitle = _useState3[0],
      setCarBrandTitle = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      carModelTitle = _useState4[0],
      setCarModelTitle = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      carBrands = _useState5[0],
      setCarBrands = _useState5[1];

  var _useState6 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      carModels = _useState6[0],
      setCarModels = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(0),
      carBrand = _useState7[0],
      setCarBrand = _useState7[1];

  var _useState8 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(0),
      carModel = _useState8[0],
      setCarModel = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(0),
      selectedCar = _useState9[0],
      setSelectedCar = _useState9[1];

  var _useState10 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      selectedCarTitle = _useState10[0],
      setSelectedCarTitle = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      selectedCarModelTitle = _useState11[0],
      setSelectedCarModelTitle = _useState11[1];

  var _useState12 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      selectedCarBrandTitle = _useState12[0],
      setSelectedCarBrandTitle = _useState12[1];

  var _useState13 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      selectedCarIsSelected = _useState13[0],
      setSelectedCarIsSelected = _useState13[1];

  var _useState14 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      toggle = _useState14[0],
      setToggle = _useState14[1];

  var _useState15 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      time = _useState15[0],
      setTime = _useState15[1];

  var _useState16 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      timeEnd = _useState16[0],
      setTimeEnd = _useState16[1];

  var _useState17 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      date = _useState17[0],
      setDate = _useState17[1];

  var _useState18 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      timestamp = _useState18[0],
      setTimestamp = _useState18[1];

  var _useState19 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      times = _useState19[0],
      setTimes = _useState19[1];

  var _useState20 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      carTag = _useState20[0],
      setCarTag = _useState20[1];

  var _React$useState3 = react__WEBPACK_IMPORTED_MODULE_5___default.a.useState(false),
      _React$useState4 = Object(D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_4__["default"])(_React$useState3, 2),
      showModal = _React$useState4[0],
      setShowModal = _React$useState4[1];

  var _useState21 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      orderData = _useState21[0],
      setOrderData = _useState21[1];

  var _useState22 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      services = _useState22[0],
      setServices = _useState22[1];

  var _useState23 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      servicesTitle = _useState23[0],
      setServicesTitle = _useState23[1];

  var _useState24 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])("..."),
      price = _useState24[0],
      setPrice = _useState24[1];

  var _useState25 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      cars = _useState25[0],
      setCars = _useState25[1];

  var _useState26 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])([]),
      carsHolder = _useState26[0],
      setCarsHolder = _useState26[1];

  var _useState27 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      rooShoyi = _useState27[0],
      setRooShoyi = _useState27[1];

  var _useState28 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])("false"),
      rooShoyiClass = _useState28[0],
      setRooShoyiClass = _useState28[1];

  var _useState29 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      rooShoyiTooShooyi = _useState29[0],
      setRooShoyiTooShooyi = _useState29[1];

  var _useState30 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])("false"),
      rooShoyiTooShooyiClass = _useState30[0],
      setRooShoyiTooShooyiClass = _useState30[1];

  var _useState31 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      tooShooyi = _useState31[0],
      setTooShooyi = _useState31[1];

  var _useState32 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])("false"),
      tooShooyiClass = _useState32[0],
      setTooShooyiClass = _useState32[1];

  var _useState33 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      dashboardWax = _useState33[0],
      setDashboardWax = _useState33[1];

  var _useState34 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])("false"),
      dashboardWaxClass = _useState34[0],
      setDashboardWaxClass = _useState34[1];

  var _useState35 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      lastikWax = _useState35[0],
      setLastikWax = _useState35[1];

  var _useState36 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])("false"),
      lastikWaxClass = _useState36[0],
      setLastikWaxClass = _useState36[1];

  var _useState37 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      file = _useState37[0],
      setFile = _useState37[1];

  var _useState38 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      loadingPrice = _useState38[0],
      setLoadingPrice = _useState38[1];

  var _useState39 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      showFile = _useState39[0],
      setshowFile = _useState39[1];

  var _useState40 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      showCarItems = _useState40[0],
      setShowCarItems = _useState40[1];

  var _useState41 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      editCar = _useState41[0],
      setEditCar = _useState41[1];

  var _useState42 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      isTooOrRooSelected = _useState42[0],
      setIsTooOrRooSelected = _useState42[1];

  var _useState43 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num0 = _useState43[0],
      setNum0 = _useState43[1];

  var _useState44 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num1 = _useState44[0],
      setNum1 = _useState44[1];

  var _useState45 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num2 = _useState45[0],
      setNum2 = _useState45[1];

  var _useState46 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num3 = _useState46[0],
      setNum3 = _useState46[1];

  var _useState47 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num4 = _useState47[0],
      setNum4 = _useState47[1];

  var _useState48 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num5 = _useState48[0],
      setNum5 = _useState48[1];

  var _useState49 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num6 = _useState49[0],
      setNum6 = _useState49[1];

  var _useState50 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(""),
      num7 = _useState50[0],
      setNum7 = _useState50[1];

  var _useState51 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])({
    min: moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()().add(-1, 'days'),
    max: moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()().add(14, 'days')
  }),
      enabledRange = _useState51[0],
      setEnabledRange = _useState51[1];

  notiflix__WEBPACK_IMPORTED_MODULE_23___default.a.Notify.Init({
    width: '250px',
    useIcon: false,
    fontSize: '14px',
    fontFamily: "IRANSansWeb",
    position: "center-top",
    closeButton: true,
    rtl: true,
    cssAnimationStyle: 'from-top'
  });
  notiflix__WEBPACK_IMPORTED_MODULE_23___default.a.Loading.Init({
    svgColor: "rgba(240,70,65,1)"
  });
  var url = "https://api.tsapp.ir/api";

  var _useState52 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])({
    rooShoyi: rooShoyi,
    tooShooyi: tooShooyi,
    rooShoyiTooShooyi: rooShoyiTooShooyi,
    lastikWax: lastikWax,
    dashboardWax: dashboardWax
  }),
      state = _useState52[0],
      setState = _useState52[1];

  var KEY_CODE = {
    backspace: 8,
    left: 37,
    up: 38,
    right: 39,
    down: 40
  };

  var numHandler = function numHandler(event) {
    var id = parseInt(event.target.id);
    /*if(((event.keyCode<47&&event.keyCode>58)||(event.keyCode<95&&event.keyCode>106)))
        event.preventDefault();
    else*/

    if (!event.target.validity.valid) {
      return;
    } else if (event.keyCode === KEY_CODE.backspace) {
      switch (id) {
        case 0:
          setNum0("");
          break;

        case 1:
          setNum1("");
          break;

        case 2:
          setNum2("");
          break;

        case 3:
          setNum3("");
          break;

        case 4:
          setNum4("");
          break;

        case 5:
          setNum5("");
          break;

        case 6:
          setNum6("");
          break;

        case 7:
          setNum7("");
          break;
      }

      if (document.getElementById((id - 1).toString()) != null) document.getElementById((id - 1).toString()).focus();else document.getElementById(id.toString()).focus();
    } else if (event.keyCode === KEY_CODE.left) {
      if (document.getElementById((id - 1).toString()) != null) document.getElementById((id - 1).toString()).focus();else document.getElementById(id.toString()).focus();
    } else if (event.keyCode === KEY_CODE.right) {
      if (document.getElementById((id + 1).toString()) != null) document.getElementById((id + 1).toString()).focus();else document.getElementById(id.toString()).focus();
    } else if (event.keyCode === KEY_CODE.up || event.keyCode === KEY_CODE.down) {//event.preventDefault();
    } else if (event.target.value != "") {
      switch (id) {
        case 0:
          setNum0(event.target.value);
          break;

        case 1:
          setNum1(event.target.value);
          break;

        case 2:
          setNum2(event.target.value);
          break;

        case 3:
          setNum3(event.target.value);
          break;

        case 4:
          setNum4(event.target.value);
          break;

        case 5:
          setNum5(event.target.value);
          break;

        case 6:
          setNum6(event.target.value);
          break;

        case 7:
          setNum7(event.target.value);
          setCarTag(num0 + num1 + num2 + num3 + num4 + num5 + num6 + event.target.value); //alert(num0 + num1 + num2 + num3 + num4 + num5 + num6 + event.target.value)

          setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
            carTag: num0 + num1 + num2 + num3 + num4 + num5 + num6 + event.target.value
          }));
          break;
      } //n[id]=event.target.value


      if (document.getElementById((id + 1).toString()) != null) document.getElementById((id + 1).toString()).focus();else document.getElementById(id.toString()).focus();
    }
  };
  /*let enabledRange = {
      min: momentJalaali().add(-1, 'days'),
      max: momentJalaali().add(14, 'days')
  };*/


  var timesHolder = ["06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30", "24:00"];

  var timesHandler = function timesHandler(newDate) {
    var today = new Date();
    var currentH = (today.getHours() + 1).toString();
    if (currentH.length == 1) currentH = "0" + currentH;
    var currentM = today.getMinutes().toString();
    if (currentM.length == 1) currentM = "0" + currentM;
    var current = currentH + ":" + currentM;
    if (moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()(today).jDate() == moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()(newDate).jDate() && moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()(today).jMonth() == moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()(newDate).jMonth() && moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()(today).jYear() == moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()(newDate).jYear()) setTimes(timesHolder.map(function (time, index) {
      return current < time ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
        value: time,
        children: time
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 256,
        columnNumber: 21
      }, _this) : null;
    }));else setTimes(timesHolder.map(function (time, index) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
        value: time,
        children: time
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 261,
        columnNumber: 17
      }, _this);
    }));
    /*if(today.getHours()==23)
    {
        setEnabledRange({...enabledRange,min:momentJalaali().add(1, 'days')})
    }*/

    setTime("");
    setTimeEnd("");
  };

  Object(react__WEBPACK_IMPORTED_MODULE_5__["useEffect"])(function () {
    fetchCarModels("");
    fetchCars();
    var abortController = new AbortController();
    var promise = window.fetch(url + '/cars/brands', {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'dataType': 'jsonp',
        //you may use jsonp for cross origin request
        'Access-Control-Allow-Origin': '*'
      },
      method: 'GET',
      mode: 'cors',
      signal: abortController.signal
    }).then(function (res) {
      return res.json();
    }).then(function (responseJson) {
      if (responseJson.message == "برند‌ها با موفقیت دریافت شد.") {
        setCarBrands(responseJson.brands);

        if (!isEmpty(props.orderData)) {
          if (props.orderData.selectedCar > 0) {
            setCarBrand(0);
            setCarModel(0);
            setCarBrandTitle("");
            setCarModelTitle("");
            setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
              selectedCar: props.orderData.selectedCar,
              carModel: 0,
              modelTitle: "",
              carBrand: 0,
              brandTitle: ""
            }));
            setSelectedCarIsSelected(true);
          } else {
            setCarBrandTitle(props.orderData.brandTitle);
            setCarBrand(props.orderData.carBrand);
            setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
              carBrand: props.orderData.carBrand,
              brandTitle: props.orderData.brandTitle
            }));
          }

          validate(true);
        }
      }
    })["catch"](function (err) {
      console.log(err);
    }); // Cancel the request if it takes more than delayFetch seconds

    setTimeout(function () {
      return abortController.abort();
    }, 100000);

    if (!isEmpty(props.orderData)) {
      console.log(props.orderData);
      setOrderData(props.orderData);

      if (props.orderData.services.includes(1)) {
        setRooShoyi(true);
        setRooShoyiClass("true");
      }

      if (props.orderData.services.includes(2)) {
        setTooShooyi(true);
        setTooShooyiClass("true");
      }

      if (props.orderData.services.includes(4)) {
        setLastikWax(true);
        setLastikWaxClass("true");
      }

      if (props.orderData.services.includes(5)) {
        setDashboardWax(true);
        setDashboardWaxClass("true");
      }

      setServicesTitle(props.orderData.servicesTitle);
      setServices(props.orderData.services);
      setState(_objectSpread(_objectSpread({}, state), {}, {
        rooShoyi: props.orderData.services.includes(1) ? true : false,
        tooShooyi: props.orderData.services.includes(2) ? true : false,
        dashboardWax: props.orderData.services.includes(4) ? true : false,
        lastikWax: props.orderData.services.includes(5) ? true : false
      })); //calculatePrice(props.orderData.services, props.orderData.carModel)

      setDate(moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()(props.orderData.date), 'jYYYY/jM/jD');
      setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
        date: props.orderData.date
      }));
      setTimes(timesHolder.map(function (time, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
          value: time,
          children: time
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 358,
          columnNumber: 17
        }, _this);
      }));
      validate(true);
      setTime(props.orderData.time);
      setTimeEnd(props.orderData.endTime);
      calculatePrice(props.orderData.services, props.orderData.carModel);
      setPrice(props.orderData.price);
      setToggle(props.orderData.absence);

      if (props.orderData.carTag != undefined) {
        var tag = props.orderData.carTag.split("");
        setCarTag(props.orderData.carTag);
        setNum0(tag[0]);
        setNum1(tag[1]);
        setNum2(props.orderData.carTag[2]);
        setNum3(props.orderData.carTag[3]);
        setNum4(props.orderData.carTag[4]);
        setNum5(props.orderData.carTag[5]);
        setNum6(props.orderData.carTag[6]);
        setNum7(props.orderData.carTag[7]);
      }

      if (props.orderData.cardImg != undefined) {
        setFile(props.orderData.cardFile);
      }

      if (props.orderData.absence && props.orderData.carTag != undefined && props.orderData.cardImg != undefined) {
        setShowCarItems(true);
        setTooShooyi(false);
        setTooShooyiClass("false disabled");
        setDashboardWax(false);
        setDashboardWaxClass("false disabled");
      }
    } else {
      var t = moment_jalaali__WEBPACK_IMPORTED_MODULE_17___default()().add(0, 'days');
      setDate(t, 'jYYYY/jM/jD');
      if (document.getElementsByClassName("datepicker-input")[0] != undefined) document.getElementsByClassName("datepicker-input")[0].setAttribute("readonly", "readonly");
      timesHandler(t);
    }
  }, []);

  function isEmpty(obj) {
    return Object.keys(obj).length === 0;
  }

  var token = null;
  var ordersCount = 0;

  if (true) {
    token = JSON.parse(localStorage.getItem('accessToken'));
    ordersCount = JSON.parse(localStorage.getItem('orders'));
  }

  var fetchCars = function fetchCars() {
    var abortController = new AbortController();
    var promise = window.fetch(url + '/user_car', {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'dataType': 'jsonp',
        //you may use jsonp for cross origin request
        'Access-Control-Allow-Origin': '*',
        'Authorization': "Bearer " + token
      },
      method: 'GET',
      mode: 'cors',
      signal: abortController.signal
    }).then(function (res) {
      return res.json();
    }).then(function (responseJson) {
      if (responseJson.message == "ماشین‌ها با موفقیت دریافت شد.") {
        setCarsHolder(responseJson.user_cars);
        var x = [];
        responseJson.user_cars.map(function (car, index) {
          return car.name != "" ? x.push({
            title: car.model.name,
            id: car.id
          }) : null;
        });
        setCars(x);

        if (!isEmpty(props.orderData)) {
          if (props.orderData.selectedCar > 0) {
            setSelectedCar(props.orderData.selectedCar);
            setCarModel(props.orderData.selectedCar);

            for (var i = 0; i < responseJson.user_cars.length; i++) {
              if (responseJson.user_cars[i].id == props.orderData.selectedCar) {
                setSelectedCarTitle(responseJson.user_cars[i].model.name);
                setSelectedCarIsSelected(true);

                if (props.orderData.carTag == undefined) {
                  setCarTag(responseJson.user_cars[i].plaque);
                  setNum0(responseJson.user_cars[i].plaque[0]);
                  setNum1(responseJson.user_cars[i].plaque[1]);
                  setNum2(responseJson.user_cars[i].plaque[2]);
                  setNum3(responseJson.user_cars[i].plaque[3]);
                  setNum4(responseJson.user_cars[i].plaque[4]);
                  setNum5(responseJson.user_cars[i].plaque[5]);
                  setNum6(responseJson.user_cars[i].plaque[6]);
                  setNum7(responseJson.user_cars[i].plaque[7]);
                }

                if (props.orderData.cardImg == undefined) setFile(responseJson.user_cars[i].card_image);
                setShowCarItems(true);
                setCarBrandTitle(responseJson.user_cars[i].model.brand.name);
                setCarModelTitle(responseJson.user_cars[i].model.name);
                setSelectedCarBrandTitle(responseJson.user_cars[i].model.brand.name);
                setSelectedCarModelTitle(responseJson.user_cars[i].model.name);
              }
            }

            validate(true);
          }
        }
      }
    })["catch"](function (err) {
      console.log(err);
    }); // Cancel the request if it takes more than delayFetch seconds

    setTimeout(function () {
      return abortController.abort();
    }, 100000);
  };

  var validate = function validate(result) {
    if (result) {
      setBtnDisabled(false);
    } else setBtnDisabled(true);
  };

  var fetchCarModels = function fetchCarModels(id) {
    var q = "";
    if (id == "") q = "";else q = '?brand_id=' + id;
    var abortController = new AbortController();
    var promise = window.fetch(url + '/cars/models' + q, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'dataType': 'jsonp',
        //you may use jsonp for cross origin request
        'Access-Control-Allow-Origin': '*'
      },
      method: 'GET',
      mode: 'cors',
      signal: abortController.signal
    }).then(function (res) {
      return res.json();
    }).then(function (responseJson) {
      if (responseJson.message == "مدل‌ها با موفقیت دریافت شد.") {
        setCarModels(responseJson.models);

        if (!isEmpty(props.orderData)) {
          if (props.orderData.selectedCar > 0) {
            setCarBrand(0);
            setCarModel(props.orderData.selectedCar);
            setCarBrandTitle("");
            setCarModelTitle("");
            setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
              selectedCar: props.orderData.selectedCar,
              carModel: 0,
              modelTitle: "",
              carBrand: 0,
              brandTitle: ""
            }));
            setSelectedCarIsSelected(true);
          } else {
            setCarModel(props.orderData.carModel);
            setCarModelTitle(props.orderData.modelTitle);
            setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
              selectedCar: 0,
              carModel: props.orderData.carModel,
              modelTitle: props.orderData.modelTitle,
              carBrand: props.orderData.carBrand,
              brandTitle: props.orderData.brandTitle
            }));
          }

          validate(true);
        }
      }
    })["catch"](function (err) {
      console.log(err);
    }); // Cancel the request if it takes more than delayFetch seconds

    setTimeout(function () {
      return abortController.abort();
    }, 100000);
  };

  var reset = function reset() {
    setServicesTitle([]);
    setServices([]);
    setPrice("...");
    setShowCarItems(false);
    setFile("");
    setCarTag("");
    setShowCarItems(false);
    setToggle(false);
    setRooShoyi(false);
    setRooShoyiClass("false");
    setTooShooyi(false);
    setTooShooyiClass("false");
    setRooShoyiTooShooyi(false);
    setRooShoyiTooShooyiClass("false");
    setDashboardWax(false);
    setDashboardWaxClass("false");
    setLastikWax(false);
    setLastikWaxClass("false");
    setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      absence: 0
    }));
    setState(_objectSpread(_objectSpread({}, state), {}, {
      rooShoyi: false,
      tooShooyi: false,
      rooShoyiTooShooyi: false,
      dashboardWax: false,
      lastikWax: false
    }));
    /*resetToggleState()*/
  };

  var carBrandHandler = function carBrandHandler(e, value) {
    if (value == null) {
      setFile("");
      setCarTag("");
      setCarModel(0);
      setCarModelTitle("");
      setCarBrand(0);
      setCarBrandTitle("");
      fetchCarModels("");
      reset();
    } else {
      var cBrand = 0;

      for (var i = 0; i < carBrands.length; i++) {
        if (carBrands[i].name == value) {
          cBrand = carBrands[i].id;
          setCarBrandTitle(carBrands[i].name);
          fetchCarModels(cBrand);
          setCarBrand(cBrand);
          setCarModelTitle("");
          setCarModel(0);
          setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
            carBrand: cBrand,
            brandTitle: carBrands[i].name
          }));
          /*if (services.length > 0)
              calculatePrice(services)*/

          var result = (cBrand != 0 && carModel != 0 || selectedCar != 0) && date != "" && time != "" && services.length > 0 && isTooOrRooSelected;
          validate(result);
        }
      }
    }
  };

  var carModelHandler = function carModelHandler(e, value) {
    var cModel = 0;
    var cTitle = "";
    var cBrand = 0;
    var cBrandTitle = "";

    if (value == null) {
      setFile("");
      setCarTag("");
      setCarModel(0);
      setCarModelTitle("");
      /*setCarBrand(0)
      setCarBrandTitle("")*/

      reset();
    } else {
      for (var i = 0; i < carModels.length; i++) {
        if (carModels[i].name == value) {
          cModel = carModels[i].id;
          setCarModelTitle(carModels[i].name);
          setCarModel(cModel);
          cTitle = carModels[i].name;
          cBrand = carModels[i].brand_id;
          setCarBrand(carModels[i].brand_id);

          for (var j = 0; j < carBrands.length; j++) {
            if (carModels[i].brand_id == carBrands[j].id) {
              setCarBrandTitle(carBrands[j].name);
              cBrandTitle = carBrands[j].name;
            }
          } //setOrderData({...orderData, carModel: cModel, modelTitle: carModels[i].name})


          if (services.length > 0) calculatePrice(services, cModel);
        }
      }
    }

    if (cBrandTitle == "") setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      selectedCar: 0,
      carModel: cModel,
      modelTitle: cTitle
    }));else setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      selectedCar: 0,
      carModel: cModel,
      modelTitle: cTitle,
      carBrand: cBrand,
      brandTitle: cBrandTitle
    }));
    var result = (carBrand != 0 && cModel != 0 || selectedCar != 0) && date != "" && time != "" && services.length > 0 && isTooOrRooSelected;
    validate(result);
  };

  var selectedCarHandler = function selectedCarHandler(e, value) {
    var cSelected = 0;
    var cSelectedTitle = "";
    var cPlaque = "";
    var cFile = "";
    var cModel = "";
    setFile("");
    setCarTag("");
    setSelectedCar(0);
    setSelectedCarTitle("");

    if (value == null) {
      setFile("");
      setCarTag("");
      setSelectedCar(0);
      reset();
    } else {
      for (var i = 0; i < carsHolder.length; i++) {
        if (value != null && carsHolder[i].model.name == value) {
          cSelected = carsHolder[i].id;
          cPlaque = carsHolder[i].plaque;
          cModel = carsHolder[i].car_model_id;
          cFile = carsHolder[i].card_image;
          setFile(carsHolder[i].card_image);
          setSelectedCarTitle(carsHolder[i].model.name);
          setSelectedCarBrandTitle(carsHolder[i].model["brand"].name);
          setSelectedCarModelTitle(carsHolder[i].model.name);
          setCarTag(cPlaque);
          console.log(cPlaque);
          if (cPlaque != "") setNum0(cPlaque[0]);
          setNum1(cPlaque[1]);
          setNum2(cPlaque[2]);
          setNum3(cPlaque[3]);
          setNum4(cPlaque[4]);
          setNum5(cPlaque[5]);
          setNum6(cPlaque[6]);
          setNum7(cPlaque[7]);
          setShowCarItems(true);
          setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
            selectedCar: 0,
            carModel: cModel
          }));
          if (services.length > 0) calculatePrice(services, cModel);
        }
      }
    }

    if (cSelected != 0) {
      setCarBrand(0);
      setCarModel(0);
      setCarBrandTitle("");
      setCarModelTitle("");
      setSelectedCarIsSelected(true);
    } else setSelectedCarIsSelected(false);

    setSelectedCar(cSelected);
    setCarModel(cModel);
    setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      selectedCar: cSelected,
      carModel: cModel
    }));
    var result = (carBrand != 0 && carModel != 0 || cSelected != 0) && date != "" && time != "" && services.length > 0 && isTooOrRooSelected;
    validate(result);
  };

  var toggleState = function toggleState(e) {
    setServices([]);
    setServicesTitle([]);
    setPrice("...");
    console.log(e.target.value);

    if (e.target.value == "بله") {
      setToggle(true);
      setRooShoyi(false);
      setRooShoyiClass("false");
      setTooShooyi(false);
      setTooShooyiClass("false disabled");
      setRooShoyiTooShooyi(false);
      setRooShoyiTooShooyiClass("false disabled");
      setDashboardWax(false);
      setDashboardWaxClass("false disabled");
      setLastikWax(false);
      setLastikWaxClass("false");
      setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
        absence: 1
      }));
      setState(_objectSpread(_objectSpread({}, state), {}, {
        rooShoyi: false,
        tooShooyi: false,
        rooShoyiTooShooyi: false,
        dashboardWax: false,
        lastikWax: false
      })); //if(selectedCar==0)

      setShowModal(true);
    } else if (e.target.value == "خیر") {
      setShowCarItems(false);
      setToggle(false);
      setRooShoyi(false);
      setRooShoyiClass("false");
      setTooShooyi(false);
      setTooShooyiClass("false");
      setRooShoyiTooShooyi(false);
      setRooShoyiTooShooyiClass("false");
      setDashboardWax(false);
      setDashboardWaxClass("false");
      setLastikWax(false);
      setLastikWaxClass("false");
      setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
        absence: 0
      }));
      setState(_objectSpread(_objectSpread({}, state), {}, {
        rooShoyi: false,
        tooShooyi: false,
        rooShoyiTooShooyi: false,
        dashboardWax: false,
        lastikWax: false
      }));
    }
  };

  var resetToggleState = function resetToggleState(value) {
    setServices([]);
    setServicesTitle([]);
    setPrice("...");
    setShowCarItems(false);
    setToggle(false);
    setRooShoyi(false);
    setRooShoyiClass("false");
    setTooShooyi(false);
    setTooShooyiClass("false");
    setRooShoyiTooShooyi(false);
    setRooShoyiTooShooyiClass("false");
    setDashboardWax(false);
    setDashboardWaxClass("false");
    setLastikWax(false);
    setLastikWaxClass("false");
    setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      absence: 0
    }));
    setState(_objectSpread(_objectSpread({}, state), {}, {
      rooShoyi: false,
      tooShooyi: false,
      rooShoyiTooShooyi: false,
      dashboardWax: false,
      lastikWax: false
    }));
  };

  function removeItemOnce(arr, value) {
    var index = arr.indexOf(value);

    if (index > -1) {
      arr.splice(index, 1);
    }

    return arr;
  }

  var servicesHandler = function servicesHandler(event) {
    var _services = _objectSpread(_objectSpread({}, state), {}, Object(D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])({}, event.target.name, event.target.checked));

    var _selectedServices = [];
    var _selectedServicesTitle = [];

    var _rooShoyi, _tooShooyi, _rooShoyiTooShooyi, _lastikWax, _dashboardWax;

    if (_services["rooShoyi"]) {
      setRooShoyi(true);
      setRooShoyiClass("true");

      _selectedServices.push(1);

      _selectedServicesTitle.push("روشویی");

      _rooShoyi = true;
      _rooShoyiTooShooyi = false;
      setRooShoyiTooShooyi(false);
      if (toggle) setRooShoyiTooShooyiClass("false disabled");else setRooShoyiTooShooyiClass("false");
    } else {
      removeItemOnce(_selectedServices, 1);
      removeItemOnce(_selectedServicesTitle, "روشویی");
      setRooShoyi(false);
      setRooShoyiClass("false");
      setRooShoyiTooShooyi(false);
      if (toggle) setRooShoyiTooShooyiClass("false disabled");else {
        setRooShoyiTooShooyiClass("false");
      }
      _rooShoyi = false;
    }

    if (_services["tooShooyi"]) {
      setTooShooyi(true);
      setTooShooyiClass("true");

      _selectedServices.push(2);

      _selectedServicesTitle.push("توشویی");

      _tooShooyi = true;
      _rooShoyiTooShooyi = false;
      setRooShoyiTooShooyi(false);
      setRooShoyiTooShooyiClass("false disabled");
    } else {
      removeItemOnce(_selectedServices, 2);
      removeItemOnce(_selectedServicesTitle, "توشویی");

      if (!toggle) {
        setTooShooyi(false);
        setTooShooyiClass("false");
        setRooShoyiTooShooyi(false);
        if (toggle) setRooShoyiTooShooyiClass("false disabled");else setRooShoyiTooShooyiClass("false");
        _tooShooyi = false;
      } else {
        setTooShooyi(false);
        setTooShooyiClass("false disabled");
        setRooShoyiTooShooyi(false);
        if (toggle) setRooShoyiTooShooyiClass("false disabled");else setRooShoyiTooShooyiClass("false");
        _tooShooyi = false;
      }
    }

    if (_services["rooShoyiTooShooyi"]) {
      _selectedServices.push(3);

      _selectedServicesTitle.push("روشویی-توشویی");

      setRooShoyiTooShooyi(true);
      setRooShoyiTooShooyiClass("true");
      setRooShoyi(false);
      setRooShoyiClass("false disabled");
      setTooShooyi(false);
      setTooShooyiClass("false disabled");
      _rooShoyiTooShooyi = true;
      _rooShoyi = false;
      _tooShooyi = false;
      removeItemOnce(_selectedServices, 1);
      removeItemOnce(_selectedServices, 2);
      removeItemOnce(_selectedServicesTitle, "روشویی");
      removeItemOnce(_selectedServicesTitle, "توشویی");
    } else {
      setRooShoyiTooShooyi(false);
      if (_services["rooShoyi"] || _services["tooShooyi"]) setRooShoyiTooShooyiClass("false disabled");else if (toggle) setRooShoyiTooShooyiClass("false disabled");else setRooShoyiTooShooyiClass("false");

      if (!_services["rooShoyi"]) {
        setRooShoyi(false);
        if (toggle) setRooShoyiClass("false");
        _rooShoyi = false;
        removeItemOnce(_selectedServices, 1);
        removeItemOnce(_selectedServicesTitle, "روشویی");
      }

      if (!_services["tooShooyi"]) {
        if (toggle) setTooShooyiClass("false disabled");else setTooShooyiClass("false");
        setTooShooyi(false);
        _tooShooyi = false;
        removeItemOnce(_selectedServices, 2);
        removeItemOnce(_selectedServicesTitle, "توشویی");
      }

      removeItemOnce(_selectedServices, 3);
      removeItemOnce(_selectedServicesTitle, "روشویی-توشویی");
      _rooShoyiTooShooyi = false;
    }

    if (_services["lastikWax"]) {
      setLastikWax(true);
      setLastikWaxClass("true");

      _selectedServices.push(4);

      _selectedServicesTitle.push("واکس لاستیک");

      _lastikWax = true;
    } else {
      removeItemOnce(_selectedServices, 4);
      removeItemOnce(_selectedServicesTitle, "واکس لاستیک");
      setLastikWax(false);
      setLastikWaxClass("false");
      _lastikWax = false;
    }

    if (_services["dashboardWax"]) {
      setDashboardWax(true);
      setDashboardWaxClass("true");

      _selectedServices.push(5);

      _selectedServicesTitle.push("واکس داشبورد");

      _dashboardWax = true;
    } else {
      removeItemOnce(_selectedServices, 5);
      removeItemOnce(_selectedServicesTitle, "واکس داشبورد");
      setDashboardWax(false);
      if (toggle) setDashboardWaxClass("false disabled");else setDashboardWaxClass("false");
      _dashboardWax = false;
    }

    setServicesTitle(_selectedServicesTitle);
    setServices(_selectedServices);
    setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      services: _selectedServices,
      servicesTitle: _selectedServicesTitle
    }));
    setState(_objectSpread(_objectSpread({}, state), {}, {
      rooShoyi: _rooShoyi,
      tooShooyi: _tooShooyi,
      rooShoyiTooShooyi: _rooShoyiTooShooyi,
      dashboardWax: _dashboardWax,
      lastikWax: _lastikWax
    }));
    calculatePrice(_selectedServices, carModel);
    setIsTooOrRooSelected(_rooShoyi || _tooShooyi);
    var result = (carBrand != 0 && carModel != 0 || selectedCar != 0) && date != "" && time != "" && _selectedServices.length > 0 && (_rooShoyi || _tooShooyi);
    validate(result);
  };

  var timeHandler = function timeHandler(event) {
    setTime(event.target.value);
    var index = timesHolder.indexOf(event.target.value);

    switch (event.target.value) {
      case "22:30":
        setTimeEnd("00:30");
        break;

      case "23:00":
        setTimeEnd("01:00");
        break;

      case "23:30":
        setTimeEnd("01:30");
        break;

      case "24:00":
        setTimeEnd("02:00");
        break;

      default:
        setTimeEnd(timesHolder[index + 4]);
    }

    setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      time: event.target.value,
      endTime: timesHolder[index + 1],
      absence: toggle ? 1 : 0
    }));
    var result = (carBrand != 0 && carModel != 0 || selectedCar != 0) && date != "" && event.target.value != "" && services.length > 0 && isTooOrRooSelected;
    validate(result);
  };

  function getTimeStamp(input) {
    var parts = input.trim().split(' ');
    var date = parts[0].split('-');
    var time = (parts[1] ? parts[1] : '00:00:00').split(':'); // NOTE:: Month: 0 = January - 11 = December.

    var d = new Date(date[0], date[1] - 1, date[2], time[0], time[1], time[2]);
    return d.getTime() / 1000;
  }

  var dateHandler = function dateHandler(value) {
    var _d = value.format('YYYY-M-D HH:mm:ss');

    var _timestamp = getTimeStamp(_d); //var date = new Date(timestamp*1000);


    setDate(value);
    if (isEmpty(props.orderData)) timesHandler(value);
    setTimestamp(_timestamp * 1000);
    setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      date: _timestamp * 1000
    }));
    var result = (carBrand != 0 && carModel != 0 || selectedCar != 0) && value != "" && time != "" && services.length > 0 && isTooOrRooSelected;
    validate(result);
  };

  var createOrder = function createOrder() {
    var _orderData = _objectSpread(_objectSpread({}, orderData), {}, {
      services: services,
      servicesTitle: servicesTitle,
      absence: toggle ? 1 : 0,
      time: time,
      endTime: timeEnd,
      price: price,
      carModel: carModel,
      modelTitle: selectedCar > 0 ? selectedCarModelTitle : carModelTitle,
      carBrand: carBrand,
      brandTitle: selectedCar > 0 ? selectedCarBrandTitle : carBrandTitle,
      selectedCar: selectedCar,
      date: isEmpty(props.orderData) ? timestamp : props.orderData.date == timestamp ? props.orderData.date : timestamp
    });

    props.callback("order", _orderData);
  };

  var showModalEdit = function showModalEdit() {
    setShowModal(true);
    setShowCarItems(false);
    setEditCar(true);
  };

  var closeModal = function closeModal() {
    setShowModal(false);
    setToggle(false);
    setRooShoyi(false);
    setRooShoyiClass("false");
    setTooShooyi(false);
    setTooShooyiClass("false");
    setRooShoyiTooShooyi(false);
    setRooShoyiTooShooyiClass("false");
    setDashboardWax(false);
    setDashboardWaxClass("false");
    setLastikWax(false);
    setLastikWaxClass("false");
    setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
      absence: 0
    }));
    setState(_objectSpread(_objectSpread({}, state), {}, {
      rooShoyi: false,
      tooShooyi: false,
      rooShoyiTooShooyi: false,
      dashboardWax: false,
      lastikWax: false
    }));
    setShowCarItems(false);
  };

  var carTagHandler = function carTagHandler(e) {
    setCarTag(e.target.value); //setOrderData({...orderData, carTag: e.target.value})
  };

  var subscribeModal = function subscribeModal() {
    /*setRooShoyi(false)
    setServices([])
    setServicesTitle([])
    setRooShoyiClass("false")
    setPrice("...")
    setState({
        ...state,
        rooShoyi: false,
        tooShooyi: false,
        rooShoyiTooShooyi: false,
        dashboardWax: false,
        lastikWax: false
    })*/
    if (document.getElementById("NotiflixNotifyWrap") != undefined) {
      var myobj = document.getElementById("NotiflixNotifyWrap");
      myobj.remove();
    }

    console.log(file);
    console.log(carTag);

    if (file != "" && carTag != "" && file != null && carTag != null) {
      setShowModal(false);
      if (!setEditCar) setToggle(true);
      setShowCarItems(true);
      setEditCar(false);
    } else if (carTag == "" || carTag == null) notiflix__WEBPACK_IMPORTED_MODULE_23___default.a.Notify.Failure('لطفا پلاک ماشین خود را وارد کنید.');else if (file == "" || file == null) notiflix__WEBPACK_IMPORTED_MODULE_23___default.a.Notify.Failure('لطفا تصویر کارت ماشین خود را آپلود کنید.');
  };

  var calculatePrice = function calculatePrice(selectedServices, model) {
    console.log(selectedServices);
    console.log(model);

    if (model != 0 && selectedServices.length > 0) {
      setLoadingPrice(true);
      var data = new FormData();
      data.append('model_id', model);
      data.append('services', JSON.stringify(selectedServices));
      axios__WEBPACK_IMPORTED_MODULE_19___default.a.post(url + '/prices/guess', data, {
        headers: {
          'Accept': 'application/json',
          'dataType': 'json',
          //you may use jsonp for cross origin request
          'Access-Control-Allow-Origin': '*',
          'Authorization': "Bearer " + token
        }
      }).then(function (responseJson) {
        if (responseJson.data.message == "هزینه‌ها با موفقیت دریافت شد.") {
          setPrice(responseJson.data.prices.price);
          setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
            price: responseJson.data.prices.price
          }));
          setLoadingPrice(false);
        }
      })["catch"](function (error) {
        console.log(error);
      });
    } else setPrice("...");
  };

  var imageHandler = /*#__PURE__*/function () {
    var _ref = Object(D_MyProjects_TWash_twash_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/D_MyProjects_TWash_twash_app_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(event) {
      var _name, _lastModified, _file;

      return D_MyProjects_TWash_twash_app_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              //fileObj1.push(event.target.files)
              _name = event.target.files[0].name;
              _lastModified = event.target.files[0].lastModified;
              setFile(URL.createObjectURL(event.target.files[0]));
              _file = new File([event.target.files[0]], _name, {
                type: "image/jpeg"
              }); //setFile(_file)

              setOrderData(_objectSpread(_objectSpread({}, orderData), {}, {
                cardImg: _file,
                cardFile: URL.createObjectURL(event.target.files[0])
              }));

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function imageHandler(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_13__["MuiThemeProvider"], {
    theme: theme,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
      className: "orderForm",
      dir: "rtl",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Container"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Row"], {
          className: "orderRow car",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 2,
            lg: 2,
            md: 2,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
              className: "formLabel",
              children: "\u0627\u0646\u062A\u062E\u0627\u0628 \u062E\u0648\u062F\u0631\u0648"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1117,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1116,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 3,
            lg: 3,
            md: 3,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["FormControl"], {
              variant: "filled",
              disabled: selectedCarIsSelected,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_lab_Autocomplete__WEBPACK_IMPORTED_MODULE_14__["default"], {
                id: "tags-filled",
                value: carBrandTitle,
                disabled: selectedCarIsSelected,
                options: carBrands.map(function (option) {
                  return option.name;
                }),
                noOptionsText: "\u0645\u0648\u0631\u062F\u06CC \u06CC\u0627\u0641\u062A \u0646\u0634\u062F",
                onChange: carBrandHandler,
                renderInput: function renderInput(params) {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["TextField"], _objectSpread(_objectSpread({}, params), {}, {
                    variant: "filled",
                    label: "\u0628\u0631\u0646\u062F \u062E\u0648\u062F\u0631\u0648 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F",
                    placeholder: "\u0628\u0631\u0627\u06CC \u062C\u0633\u062A\u062C\u0648 \u062A\u0627\u06CC\u067E \u06A9\u0646\u06CC\u062F..."
                  }), void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1129,
                    columnNumber: 41
                  }, _this);
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1121,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1120,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1119,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 3,
            lg: 3,
            md: 3,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["FormControl"], {
              variant: "filled",
              disabled: selectedCarIsSelected,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_lab_Autocomplete__WEBPACK_IMPORTED_MODULE_14__["default"], {
                id: "tags-filled",
                value: carModelTitle,
                disabled: selectedCarIsSelected,
                options: carModels.map(function (option) {
                  return option.name;
                }),
                noOptionsText: "\u0645\u0648\u0631\u062F\u06CC \u06CC\u0627\u0641\u062A \u0646\u0634\u062F",
                onChange: carModelHandler,
                renderInput: function renderInput(params) {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["TextField"], _objectSpread(_objectSpread({}, params), {}, {
                    variant: "filled",
                    label: "\u0645\u062F\u0644 \u062E\u0648\u062F\u0631\u0648 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F",
                    placeholder: "\u0628\u0631\u0627\u06CC \u062C\u0633\u062A\u062C\u0648 \u062A\u0627\u06CC\u067E \u06A9\u0646\u06CC\u062F..."
                  }), void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1149,
                    columnNumber: 41
                  }, _this);
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1141,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1140,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1139,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 3,
            lg: 3,
            md: 3,
            sm: 12,
            xs: 12,
            className: "selectedCar",
            children: cars.length > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["FormControl"], {
              variant: "filled",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_lab_Autocomplete__WEBPACK_IMPORTED_MODULE_14__["default"], {
                id: "tags-filled",
                value: selectedCarTitle,
                options: cars.map(function (option) {
                  return option.title;
                }),
                noOptionsText: "\u0645\u0648\u0631\u062F\u06CC \u06CC\u0627\u0641\u062A \u0646\u0634\u062F",
                onChange: selectedCarHandler,
                renderInput: function renderInput(params) {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["TextField"], _objectSpread(_objectSpread({}, params), {}, {
                    variant: "filled",
                    label: "\u062E\u0648\u062F\u0631\u0648\u0647\u0627\u06CC \u0645\u0646\u062A\u062E\u0628",
                    placeholder: "\u0628\u0631\u0627\u06CC \u062C\u0633\u062A\u062C\u0648 \u062A\u0627\u06CC\u067E \u06A9\u0646\u06CC\u062F..."
                  }), void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1169,
                    columnNumber: 41
                  }, _this);
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1162,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1161,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1159,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 1,
            lg: 1,
            md: 1,
            sm: 12,
            xs: 12
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1201,
            columnNumber: 25
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1115,
          columnNumber: 21
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Row"], {
          className: "orderRow",
          style: {
            border: "none"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 2,
            lg: 2,
            md: 2,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
              className: "formLabel",
              children: "\u0627\u0646\u062A\u062E\u0627\u0628 \u062E\u062F\u0645\u0627\u062A"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1206,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1205,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 4,
            lg: 4,
            md: 10,
            sm: 12,
            xs: 12,
            children: ordersCount > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("form", {
              className: "switch-field",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "radio",
                name: "switchToggle",
                value: "\u062E\u06CC\u0631",
                id: "switch_right",
                onChange: toggleState,
                checked: !toggle
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1212,
                columnNumber: 41
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                htmlFor: "switch_right",
                className: "switch_right",
                children: "\u062E\u06CC\u0631"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1220,
                columnNumber: 41
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "radio",
                name: "switchToggle",
                value: "\u0628\u0644\u0647",
                id: "switch_left",
                onChange: toggleState,
                checked: toggle
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1221,
                columnNumber: 41
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                htmlFor: "switch_left",
                className: "switch_left",
                children: "\u0628\u0644\u0647"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1229,
                columnNumber: 41
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                className: "switchTile",
                children: "\u062F\u0631 \u063A\u06CC\u0627\u0628 \u0645\u0634\u062A\u0631\u06CC"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1230,
                columnNumber: 41
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1211,
              columnNumber: 37
            }, _this) : null
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1208,
            columnNumber: 25
          }, _this), showCarItems ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 6,
            lg: 6,
            md: 10,
            sm: 12,
            xs: 12,
            className: "carItems",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("img", {
              src: file,
              className: "carImg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1238,
              columnNumber: 37
            }, _this), carTag != "" && carTag != null ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("span", {
              children: ["\u067E\u0644\u0627\u06A9 \u0645\u0627\u0634\u06CC\u0646 : ", carTag]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1240,
              columnNumber: 74
            }, _this) : null, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("button", {
              onClick: showModalEdit,
              children: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0645\u062F\u0627\u0631\u06A9 \u062E\u0648\u062F\u0631\u0648"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1243,
              columnNumber: 37
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 1237,
            columnNumber: 33
          }, _this) : toggle && selectedCar != 0 || toggle && carModel != 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("button", {
            onClick: showModalEdit,
            children: "\u0622\u067E\u0644\u0648\u062F \u0645\u062F\u0627\u0631\u06A9 \u062E\u0648\u062F\u0631\u0648"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1248,
            columnNumber: 37
          }, _this) : null]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1204,
          columnNumber: 21
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Row"], {
          className: "orderRow",
          style: {
            paddingTop: "0",
            margin: "0 20px"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 9,
            lg: 9,
            md: 12,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["FormControl"], {
              className: "checkServices",
              component: "fieldset",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "form-check",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                  className: rooShoyiClass,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                    type: "checkbox",
                    name: "rooShoyi",
                    value: rooShoyi,
                    checked: rooShoyi,
                    disabled: rooShoyiTooShooyi,
                    onChange: servicesHandler,
                    className: "form-check-input"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1258,
                    columnNumber: 41
                  }, _this), "\u0631\u0648\u0634\u0648\u06CC\u06CC"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1257,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1256,
                columnNumber: 33
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "form-check",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                  className: tooShooyiClass,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                    type: "checkbox",
                    name: "tooShooyi",
                    value: tooShooyi,
                    checked: tooShooyi,
                    disabled: rooShoyiTooShooyi || toggle,
                    onChange: servicesHandler,
                    className: "form-check-input"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1265,
                    columnNumber: 41
                  }, _this), "\u062A\u0648\u0634\u0648\u06CC\u06CC"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1264,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1263,
                columnNumber: 33
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "form-check form-check-25",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                  className: lastikWaxClass,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                    type: "checkbox",
                    name: "lastikWax",
                    value: lastikWax,
                    checked: lastikWax,
                    onChange: servicesHandler,
                    className: "form-check-input"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1279,
                    columnNumber: 41
                  }, _this), "\u0648\u0627\u06A9\u0633 \u0644\u0627\u0633\u062A\u06CC\u06A9"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1278,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1277,
                columnNumber: 33
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "form-check form-check-25",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                  className: dashboardWaxClass,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                    type: "checkbox",
                    name: "dashboardWax",
                    value: dashboardWax,
                    checked: dashboardWax,
                    disabled: toggle,
                    onChange: servicesHandler,
                    className: "form-check-input"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1286,
                    columnNumber: 41
                  }, _this), "\u0648\u0627\u06A9\u0633 \u062F\u0627\u0634\u0628\u0648\u0631\u062F"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1285,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1284,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1255,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1254,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 3,
            lg: 3,
            md: 12,
            sm: 12,
            xs: 12,
            children: loadingPrice ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              className: "loader"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1298,
              columnNumber: 37
            }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
              className: "servicesPrice",
              children: ["\u0647\u0632\u06CC\u0646\u0647 \u062E\u062F\u0645\u0627\u062A : ", Object(persian_tools2__WEBPACK_IMPORTED_MODULE_22__["addCommas"])(price), " \u062A\u0648\u0645\u0627\u0646"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1300,
              columnNumber: 37
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1295,
            columnNumber: 25
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1253,
          columnNumber: 21
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Row"], {
          className: "orderRow timeSelect",
          style: {
            border: "none"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 2,
            lg: 2,
            md: 2,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
              className: "formLabel",
              children: "\u0627\u0646\u062A\u062E\u0627\u0628 \u0632\u0645\u0627\u0646"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1307,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1306,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 3,
            lg: 3,
            md: 3,
            sm: 12,
            xs: 12,
            className: "form-item",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("img", {
                src: _assets_images_down_png__WEBPACK_IMPORTED_MODULE_20___default.a,
                className: "down"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1311,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1310,
              columnNumber: 29
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_datepicker2__WEBPACK_IMPORTED_MODULE_16___default.a, {
                label: "\u062A\u0627\u0631\u06CC\u062E \u06A9\u0627\u0631\u0648\u0627\u0634",
                placeholder: "\u062A\u0627\u0631\u06CC\u062E \u06A9\u0627\u0631\u0648\u0627\u0634",
                isGregorian: false,
                timePicker: false,
                min: enabledRange.min,
                max: enabledRange.max,
                value: date,
                showTodayButton: false,
                inputFormat: "YYYY-M-D",
                onChange: dateHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1314,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 1313,
              columnNumber: 29
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 1309,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 3,
            lg: 3,
            md: 3,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["FormControl"], {
              variant: "filled",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["InputLabel"], {
                id: "demo-simple-select-filled-label",
                children: "\u0633\u0627\u0639\u062A \u0634\u0631\u0648\u0639"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1332,
                columnNumber: 33
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["Select"], {
                labelId: "demo-simple-select-filled-label",
                id: "demo-simple-select-filled",
                value: time,
                onChange: timeHandler,
                label: "\u0633\u0627\u0639\u062A \u0634\u0631\u0648\u0639",
                children: times
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1333,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1331,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1330,
            columnNumber: 25
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Col"], {
            xl: 4,
            lg: 10,
            md: 12,
            sm: 12,
            xs: 12,
            children: time != "" && timeEnd != "" && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
              className: "servicesTime",
              children: ["\u062E\u0648\u062F\u0631\u0648 \u0634\u0645\u0627 \u062F\u0631 \u0628\u0627\u0632\u0647 \u0632\u0645\u0627\u0646\u06CC ", time, " \u062A\u0627 ", timeEnd, " \u0634\u0633\u062A\u0647 \u062E\u0648\u0627\u0647\u062F \u0634\u062F."]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1346,
              columnNumber: 33
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1343,
            columnNumber: 25
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1305,
          columnNumber: 21
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(react_bootstrap__WEBPACK_IMPORTED_MODULE_15__["Row"], {
          className: "orderBtn",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["Button"], {
            className: "",
            variant: "contained",
            color: "secondary",
            onClick: function onClick() {
              return createOrder();
            },
            disabled: btnDisabled,
            children: "\u0645\u0631\u062D\u0644\u0647 \u0628\u0639\u062F (\u0627\u0646\u062A\u062E\u0627\u0628 \u0645\u062D\u0644 \u0634\u0633\u062A \u0648 \u0634\u0648)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1353,
            columnNumber: 25
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 1352,
          columnNumber: 21
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 1114,
        columnNumber: 17
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1113,
      columnNumber: 13
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_8__["default"], {
      open: showModal,
      onClose: closeModal,
      "aria-labelledby": "form-dialog-title",
      className: "absenseDialog",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_12__["default"], {
        id: "form-dialog-title",
        children: "\u0627\u0631\u0633\u0627\u0644 \u0645\u062F\u0627\u0631\u06A9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1370,
        columnNumber: 17
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_10__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_11__["default"], {
          children: ["\u0644\u0637\u0641\u0627 \u0628\u0631\u0627\u06CC \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0627\u0632 \u062E\u062F\u0645\u0627\u062A \u062F\u0631\u063A\u06CC\u0627\u0628 \u0645\u0634\u062A\u0631\u06CC \u0628\u0647 \u0646\u06A9\u0627\u062A \u0632\u06CC\u0631 \u062A\u0648\u062C\u0647 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u06CC\u062F:", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1374,
            columnNumber: 25
          }, _this), "- \u0645\u062D\u0644 \u067E\u0627\u0631\u06A9 \u06A9\u0631\u062F\u0646 \u0645\u0627\u0634\u06CC\u0646 \u0628\u0627\u06CC\u062F \u0628\u0647 \u06AF\u0648\u0646\u0647 \u0627\u06CC \u0628\u0627\u0634\u062F \u06A9\u0647 \u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0647\u0645\u0647 \u0646\u0642\u0627\u0637 \u0645\u0627\u0634\u06CC\u0646 \u0627\u0645\u06A9\u0627\u0646 \u067E\u0630\u06CC\u0631 \u0628\u0627\u0634\u062F (\u06A9\u0646\u0627\u0631 \u062F\u06CC\u0648\u0627\u0631 \u06CC\u0627 \u0686\u0633\u0628\u06CC\u062F\u0647 \u0628\u0647 \u062C\u062F\u0648\u0644 \u0648 ... \u0646\u0628\u0627\u0634\u062F\u060C \u0646\u0642\u0627\u0637\u06CC \u06A9\u0647 \u062F\u0633\u062A \u06A9\u0627\u0631\u0648\u0627\u0634\u0645\u0646 \u0646\u0631\u0633\u062F \u0634\u0633\u062A\u0647 \u0646\u062E\u0648\u0627\u0647\u062F \u0634\u062F.)", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1378,
            columnNumber: 25
          }, _this), "- \u0647\u0645 \u0686\u0646\u06CC\u0646 \u062F\u0627\u062E\u0644 \u0634\u06CC\u0634\u0647 \u0647\u0627 \u062F\u0633\u062A\u0645\u0627\u0644 \u06A9\u0634\u06CC\u062F\u0647 \u0646\u062E\u0648\u0627\u0647\u062F \u0634\u062F.", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1380,
            columnNumber: 25
          }, _this), "\u0628\u0631\u0627\u06CC \u062D\u0641\u0638 \u0627\u0645\u0646\u06CC\u062A \u062F\u0631 \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0627\u0632 \u062E\u062F\u0645\u0627\u062A \u06A9\u0627\u0631\u0648\u0627\u0634 \u062F\u0631 \u063A\u06CC\u0627\u0628 \u0645\u0634\u062A\u0631\u06CC \u0644\u0637\u0641\u0627 \u067E\u0644\u0627\u06A9 \u062E\u0648\u062F\u0631\u0648 \u062E\u0648\u062F \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0647 \u0648 \u06A9\u0627\u0631\u062A \u0645\u0627\u0634\u06CC\u0646 \u0631\u0627 \u0622\u067E\u0644\u0648\u062F \u0646\u0645\u0627\u06CC\u06CC\u062F."]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1372,
          columnNumber: 21
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_13__["MuiThemeProvider"], {
          theme: theme,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
            dir: "rtl",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              className: "carPlate orderPlate",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "tel",
                inputMode: "number",
                maxLength: 1,
                value: num0,
                id: "0",
                onChange: numHandler,
                pattern: "[0-9]*",
                onKeyDown: numHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1388,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "tel",
                inputMode: "number",
                maxLength: 1,
                value: num1,
                id: "1",
                onChange: numHandler,
                pattern: "[0-9]*",
                onKeyDown: numHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1391,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("select", {
                value: num2,
                id: "2",
                onChange: numHandler,
                onKeyDown: numHandler,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0627",
                  children: " \u0627\u0644\u0641"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1395,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0628",
                  children: " \u0628"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1396,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u067E",
                  children: " \u067E"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1397,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u062A",
                  children: " \u062A"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1398,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u062B",
                  children: " \u062B"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1399,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u062C",
                  children: " \u062C"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1400,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u062D",
                  children: " \u062D"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1402,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u062E",
                  children: " \u062E"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1403,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u062F",
                  children: " \u062F"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1404,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0630",
                  children: " \u0630"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1405,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0631",
                  children: " \u0631"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1406,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0632",
                  children: " \u0632"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1407,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0633",
                  children: " \u0633"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1408,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0634",
                  children: " \u0634"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1409,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0635",
                  children: " \u0635"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1410,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0636",
                  children: " \u0636"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1411,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0637",
                  children: " \u0637"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1412,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0638",
                  children: " \u0638"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1413,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0639",
                  children: " \u0639"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1414,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u063A",
                  children: " \u063A"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1415,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0641",
                  children: " \u0641"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1416,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0642",
                  children: " \u0642"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1417,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u06A9",
                  children: " \u06A9"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1418,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u06AF",
                  children: " \u06AF"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1419,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0644",
                  children: " \u0644"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1420,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0645",
                  children: " \u0645"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1421,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0646",
                  children: " \u0646"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1422,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0648",
                  children: " \u0648"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1423,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u0647\u0640",
                  children: " \u0647\u0640"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1424,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "\u06CC",
                  children: " \u06CC"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1425,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "D",
                  children: " D"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1426,
                  columnNumber: 41
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("option", {
                  value: "S",
                  children: " S"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1427,
                  columnNumber: 41
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1394,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "tel",
                inputMode: "number",
                maxLength: 1,
                value: num3,
                id: "3",
                onChange: numHandler,
                pattern: "[0-9]*",
                onKeyDown: numHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1429,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "tel",
                inputMode: "number",
                maxLength: 1,
                value: num4,
                id: "4",
                onChange: numHandler,
                pattern: "[0-9]*",
                onKeyDown: numHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1432,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "tel",
                inputMode: "number",
                maxLength: 1,
                value: num5,
                id: "5",
                onChange: numHandler,
                pattern: "[0-9]*",
                onKeyDown: numHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1435,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "tel",
                inputMode: "number",
                maxLength: 1,
                value: num6,
                id: "6",
                onChange: numHandler,
                pattern: "[0-9]*",
                onKeyDown: numHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1438,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "tel",
                inputMode: "number",
                maxLength: 1,
                value: num7,
                id: "7",
                onChange: numHandler,
                pattern: "[0-9]*",
                onKeyDown: numHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1441,
                columnNumber: 37
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1387,
              columnNumber: 29
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              className: "uploadInput",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
                type: "file",
                accept: "image/*",
                className: "inputfile",
                id: "inputGroupFile01",
                "aria-describedby": "inputGroupFileAddon01",
                onClick: function onClick(e) {
                  return e.target.value = '';
                } //به خاطر مشکل آپلود در کروم
                ,
                onChange: imageHandler
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1457,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("span", {
                className: "inputFileLabel",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("img", {
                  src: _assets_images_cloud_computing_png__WEBPACK_IMPORTED_MODULE_21___default.a
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1467,
                  columnNumber: 25
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("label", {
                  htmlFor: "file",
                  children: "\u0622\u067E\u0644\u0648\u062F \u062A\u0635\u0648\u06CC\u0631 \u06A9\u0627\u0631\u062A \u0645\u0627\u0634\u06CC\u0646"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1468,
                  columnNumber: 25
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1466,
                columnNumber: 37
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("img", {
                src: file,
                className: "carImg"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 1471,
                columnNumber: 37
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1456,
              columnNumber: 29
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 1386,
            columnNumber: 25
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 1385,
          columnNumber: 21
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 1371,
        columnNumber: 17
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_9__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["Button"], {
          onClick: closeModal,
          color: "primary",
          variant: "fill",
          className: "dialogBtn",
          children: "\u0644\u063A\u0648"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 1477,
          columnNumber: 21
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["Button"], {
          onClick: subscribeModal,
          color: "primary",
          variant: "fill",
          className: "dialogBtn",
          children: "\u062A\u0627\u06CC\u06CC\u062F"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 1480,
          columnNumber: 21
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 1476,
        columnNumber: 17
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1369,
      columnNumber: 13
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 1112,
    columnNumber: 9
  }, _this);
};

_s(Order, "QCgPHCYyMS7TvZxFxm7+C4+hNKU=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_18__["useRouter"], useStyles];
});

_c = Order;
/* harmony default export */ __webpack_exports__["default"] = (Order);

var _c;

$RefreshReg$(_c, "Order");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9vcmRlci9vcmRlci5qcyJdLCJuYW1lcyI6WyJ0aGVtZSIsImNyZWF0ZU11aVRoZW1lIiwiZGlyZWN0aW9uIiwicmFuZCIsIk1hdGgiLCJyb3VuZCIsInJhbmRvbSIsImdldE1vZGFsU3R5bGUiLCJ0b3AiLCJsZWZ0IiwidHJhbnNmb3JtIiwidXNlU3R5bGVzIiwibWFrZVN0eWxlcyIsInBhcGVyIiwicG9zaXRpb24iLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsInBhbGV0dGUiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm94U2hhZG93Iiwic2hhZG93cyIsInBhZGRpbmciLCJzcGFjaW5nIiwiT3JkZXIiLCJwcm9wcyIsInJvdXRlciIsInVzZVJvdXRlciIsImNsYXNzZXMiLCJSZWFjdCIsInVzZVN0YXRlIiwibW9kYWxTdHlsZSIsImVycm9yTWVzc2FnZSIsInNldEVycm9yTWVzc2FnZSIsImJ0bkRpc2FibGVkIiwic2V0QnRuRGlzYWJsZWQiLCJjYXJCcmFuZFRpdGxlIiwic2V0Q2FyQnJhbmRUaXRsZSIsImNhck1vZGVsVGl0bGUiLCJzZXRDYXJNb2RlbFRpdGxlIiwiY2FyQnJhbmRzIiwic2V0Q2FyQnJhbmRzIiwiY2FyTW9kZWxzIiwic2V0Q2FyTW9kZWxzIiwiY2FyQnJhbmQiLCJzZXRDYXJCcmFuZCIsImNhck1vZGVsIiwic2V0Q2FyTW9kZWwiLCJzZWxlY3RlZENhciIsInNldFNlbGVjdGVkQ2FyIiwic2VsZWN0ZWRDYXJUaXRsZSIsInNldFNlbGVjdGVkQ2FyVGl0bGUiLCJzZWxlY3RlZENhck1vZGVsVGl0bGUiLCJzZXRTZWxlY3RlZENhck1vZGVsVGl0bGUiLCJzZWxlY3RlZENhckJyYW5kVGl0bGUiLCJzZXRTZWxlY3RlZENhckJyYW5kVGl0bGUiLCJzZWxlY3RlZENhcklzU2VsZWN0ZWQiLCJzZXRTZWxlY3RlZENhcklzU2VsZWN0ZWQiLCJ0b2dnbGUiLCJzZXRUb2dnbGUiLCJ0aW1lIiwic2V0VGltZSIsInRpbWVFbmQiLCJzZXRUaW1lRW5kIiwiZGF0ZSIsInNldERhdGUiLCJ0aW1lc3RhbXAiLCJzZXRUaW1lc3RhbXAiLCJ0aW1lcyIsInNldFRpbWVzIiwiY2FyVGFnIiwic2V0Q2FyVGFnIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwib3JkZXJEYXRhIiwic2V0T3JkZXJEYXRhIiwic2VydmljZXMiLCJzZXRTZXJ2aWNlcyIsInNlcnZpY2VzVGl0bGUiLCJzZXRTZXJ2aWNlc1RpdGxlIiwicHJpY2UiLCJzZXRQcmljZSIsImNhcnMiLCJzZXRDYXJzIiwiY2Fyc0hvbGRlciIsInNldENhcnNIb2xkZXIiLCJyb29TaG95aSIsInNldFJvb1Nob3lpIiwicm9vU2hveWlDbGFzcyIsInNldFJvb1Nob3lpQ2xhc3MiLCJyb29TaG95aVRvb1Nob295aSIsInNldFJvb1Nob3lpVG9vU2hvb3lpIiwicm9vU2hveWlUb29TaG9veWlDbGFzcyIsInNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MiLCJ0b29TaG9veWkiLCJzZXRUb29TaG9veWkiLCJ0b29TaG9veWlDbGFzcyIsInNldFRvb1Nob295aUNsYXNzIiwiZGFzaGJvYXJkV2F4Iiwic2V0RGFzaGJvYXJkV2F4IiwiZGFzaGJvYXJkV2F4Q2xhc3MiLCJzZXREYXNoYm9hcmRXYXhDbGFzcyIsImxhc3Rpa1dheCIsInNldExhc3Rpa1dheCIsImxhc3Rpa1dheENsYXNzIiwic2V0TGFzdGlrV2F4Q2xhc3MiLCJmaWxlIiwic2V0RmlsZSIsImxvYWRpbmdQcmljZSIsInNldExvYWRpbmdQcmljZSIsInNob3dGaWxlIiwic2V0c2hvd0ZpbGUiLCJzaG93Q2FySXRlbXMiLCJzZXRTaG93Q2FySXRlbXMiLCJlZGl0Q2FyIiwic2V0RWRpdENhciIsImlzVG9vT3JSb29TZWxlY3RlZCIsInNldElzVG9vT3JSb29TZWxlY3RlZCIsIm51bTAiLCJzZXROdW0wIiwibnVtMSIsInNldE51bTEiLCJudW0yIiwic2V0TnVtMiIsIm51bTMiLCJzZXROdW0zIiwibnVtNCIsInNldE51bTQiLCJudW01Iiwic2V0TnVtNSIsIm51bTYiLCJzZXROdW02IiwibnVtNyIsInNldE51bTciLCJtaW4iLCJtb21lbnRKYWxhYWxpIiwiYWRkIiwibWF4IiwiZW5hYmxlZFJhbmdlIiwic2V0RW5hYmxlZFJhbmdlIiwiTm90aWZsaXgiLCJOb3RpZnkiLCJJbml0IiwidXNlSWNvbiIsImZvbnRTaXplIiwiZm9udEZhbWlseSIsImNsb3NlQnV0dG9uIiwicnRsIiwiY3NzQW5pbWF0aW9uU3R5bGUiLCJMb2FkaW5nIiwic3ZnQ29sb3IiLCJwcm9jZXNzIiwibG9hZGluZ0RvdHNDb2xvciIsInVybCIsInN0YXRlIiwic2V0U3RhdGUiLCJLRVlfQ09ERSIsImJhY2tzcGFjZSIsInVwIiwicmlnaHQiLCJkb3duIiwibnVtSGFuZGxlciIsImV2ZW50IiwiaWQiLCJwYXJzZUludCIsInRhcmdldCIsInZhbGlkaXR5IiwidmFsaWQiLCJrZXlDb2RlIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInRvU3RyaW5nIiwiZm9jdXMiLCJ2YWx1ZSIsInRpbWVzSG9sZGVyIiwidGltZXNIYW5kbGVyIiwibmV3RGF0ZSIsInRvZGF5IiwiRGF0ZSIsImN1cnJlbnRIIiwiZ2V0SG91cnMiLCJsZW5ndGgiLCJjdXJyZW50TSIsImdldE1pbnV0ZXMiLCJjdXJyZW50IiwiakRhdGUiLCJqTW9udGgiLCJqWWVhciIsIm1hcCIsImluZGV4IiwidXNlRWZmZWN0IiwiZmV0Y2hDYXJNb2RlbHMiLCJmZXRjaENhcnMiLCJhYm9ydENvbnRyb2xsZXIiLCJBYm9ydENvbnRyb2xsZXIiLCJwcm9taXNlIiwid2luZG93IiwiZmV0Y2giLCJoZWFkZXJzIiwibWV0aG9kIiwibW9kZSIsInNpZ25hbCIsInRoZW4iLCJyZXMiLCJqc29uIiwicmVzcG9uc2VKc29uIiwibWVzc2FnZSIsImJyYW5kcyIsImlzRW1wdHkiLCJtb2RlbFRpdGxlIiwiYnJhbmRUaXRsZSIsInZhbGlkYXRlIiwiZXJyIiwiY29uc29sZSIsImxvZyIsInNldFRpbWVvdXQiLCJhYm9ydCIsImluY2x1ZGVzIiwiZW5kVGltZSIsImNhbGN1bGF0ZVByaWNlIiwiYWJzZW5jZSIsInVuZGVmaW5lZCIsInRhZyIsInNwbGl0IiwiY2FyZEltZyIsImNhcmRGaWxlIiwidCIsImdldEVsZW1lbnRzQnlDbGFzc05hbWUiLCJzZXRBdHRyaWJ1dGUiLCJvYmoiLCJPYmplY3QiLCJrZXlzIiwidG9rZW4iLCJvcmRlcnNDb3VudCIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyX2NhcnMiLCJ4IiwiY2FyIiwibmFtZSIsInB1c2giLCJ0aXRsZSIsIm1vZGVsIiwiaSIsInBsYXF1ZSIsImNhcmRfaW1hZ2UiLCJicmFuZCIsInJlc3VsdCIsInEiLCJtb2RlbHMiLCJyZXNldCIsImNhckJyYW5kSGFuZGxlciIsImUiLCJjQnJhbmQiLCJjYXJNb2RlbEhhbmRsZXIiLCJjTW9kZWwiLCJjVGl0bGUiLCJjQnJhbmRUaXRsZSIsImJyYW5kX2lkIiwiaiIsInNlbGVjdGVkQ2FySGFuZGxlciIsImNTZWxlY3RlZCIsImNTZWxlY3RlZFRpdGxlIiwiY1BsYXF1ZSIsImNGaWxlIiwiY2FyX21vZGVsX2lkIiwidG9nZ2xlU3RhdGUiLCJyZXNldFRvZ2dsZVN0YXRlIiwicmVtb3ZlSXRlbU9uY2UiLCJhcnIiLCJpbmRleE9mIiwic3BsaWNlIiwic2VydmljZXNIYW5kbGVyIiwiX3NlcnZpY2VzIiwiY2hlY2tlZCIsIl9zZWxlY3RlZFNlcnZpY2VzIiwiX3NlbGVjdGVkU2VydmljZXNUaXRsZSIsIl9yb29TaG95aSIsIl90b29TaG9veWkiLCJfcm9vU2hveWlUb29TaG9veWkiLCJfbGFzdGlrV2F4IiwiX2Rhc2hib2FyZFdheCIsInRpbWVIYW5kbGVyIiwiZ2V0VGltZVN0YW1wIiwiaW5wdXQiLCJwYXJ0cyIsInRyaW0iLCJkIiwiZ2V0VGltZSIsImRhdGVIYW5kbGVyIiwiX2QiLCJmb3JtYXQiLCJfdGltZXN0YW1wIiwiY3JlYXRlT3JkZXIiLCJfb3JkZXJEYXRhIiwiY2FsbGJhY2siLCJzaG93TW9kYWxFZGl0IiwiY2xvc2VNb2RhbCIsImNhclRhZ0hhbmRsZXIiLCJzdWJzY3JpYmVNb2RhbCIsIm15b2JqIiwicmVtb3ZlIiwiRmFpbHVyZSIsInNlbGVjdGVkU2VydmljZXMiLCJkYXRhIiwiRm9ybURhdGEiLCJhcHBlbmQiLCJzdHJpbmdpZnkiLCJheGlvcyIsInBvc3QiLCJwcmljZXMiLCJlcnJvciIsImltYWdlSGFuZGxlciIsIl9uYW1lIiwiZmlsZXMiLCJfbGFzdE1vZGlmaWVkIiwibGFzdE1vZGlmaWVkIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiX2ZpbGUiLCJGaWxlIiwidHlwZSIsIm9wdGlvbiIsInBhcmFtcyIsInBhZGRpbmdUb3AiLCJtYXJnaW4iLCJhZGRDb21tYXMiLCJjbG91ZENvbXB1dGluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQVNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFNQSxLQUFLLEdBQUdDLGdGQUFjLENBQUM7QUFDekJDLFdBQVMsRUFBRTtBQURjLENBQUQsQ0FBNUI7O0FBSUEsU0FBU0MsSUFBVCxHQUFnQjtBQUNaLFNBQU9DLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsRUFBM0IsSUFBaUMsRUFBeEM7QUFDSDs7QUFFRCxTQUFTQyxhQUFULEdBQXlCO0FBQ3JCLE1BQU1DLEdBQUcsR0FBRyxLQUFLTCxJQUFJLEVBQXJCO0FBQ0EsTUFBTU0sSUFBSSxHQUFHLEtBQUtOLElBQUksRUFBdEI7QUFFQSxTQUFPO0FBQ0hLLE9BQUcsWUFBS0EsR0FBTCxNQURBO0FBRUhDLFFBQUksWUFBS0EsSUFBTCxNQUZEO0FBR0hDLGFBQVMsdUJBQWdCRixHQUFoQixpQkFBMEJDLElBQTFCO0FBSE4sR0FBUDtBQUtIOztBQUVELElBQU1FLFNBQVMsR0FBR0MsNEVBQVUsQ0FBQyxVQUFDWixLQUFEO0FBQUEsU0FBWTtBQUNyQ2EsU0FBSyxFQUFFO0FBQ0hDLGNBQVEsRUFBRSxVQURQO0FBRUhDLFdBQUssRUFBRSxHQUZKO0FBR0hDLHFCQUFlLEVBQUVoQixLQUFLLENBQUNpQixPQUFOLENBQWNDLFVBQWQsQ0FBeUJMLEtBSHZDO0FBSUhNLFlBQU0sRUFBRSxnQkFKTDtBQUtIQyxlQUFTLEVBQUVwQixLQUFLLENBQUNxQixPQUFOLENBQWMsQ0FBZCxDQUxSO0FBTUhDLGFBQU8sRUFBRXRCLEtBQUssQ0FBQ3VCLE9BQU4sQ0FBYyxDQUFkLEVBQWlCLENBQWpCLEVBQW9CLENBQXBCO0FBTk47QUFEOEIsR0FBWjtBQUFBLENBQUQsQ0FBNUI7O0FBV0EsSUFBTUMsS0FBSyxHQUFHLFNBQVJBLEtBQVEsQ0FBQ0MsS0FBRCxFQUFXO0FBQUE7O0FBQ3JCLE1BQU1DLE1BQU0sR0FBR0MsOERBQVMsRUFBeEI7QUFDQSxNQUFNQyxPQUFPLEdBQUdqQixTQUFTLEVBQXpCOztBQUZxQix3QkFHQWtCLDRDQUFLLENBQUNDLFFBQU4sQ0FBZXZCLGFBQWYsQ0FIQTtBQUFBO0FBQUEsTUFHZHdCLFVBSGM7O0FBQUEsa0JBSW1CRCxzREFBUSxDQUFDLEVBQUQsQ0FKM0I7QUFBQSxNQUlkRSxZQUpjO0FBQUEsTUFJQUMsZUFKQTs7QUFBQSxtQkFLaUJILHNEQUFRLENBQUMsSUFBRCxDQUx6QjtBQUFBLE1BS2RJLFdBTGM7QUFBQSxNQUtEQyxjQUxDOztBQUFBLG1CQU1xQkwsc0RBQVEsQ0FBQyxFQUFELENBTjdCO0FBQUEsTUFNZE0sYUFOYztBQUFBLE1BTUNDLGdCQU5EOztBQUFBLG1CQU9xQlAsc0RBQVEsQ0FBQyxFQUFELENBUDdCO0FBQUEsTUFPZFEsYUFQYztBQUFBLE1BT0NDLGdCQVBEOztBQUFBLG1CQVFhVCxzREFBUSxDQUFDLEVBQUQsQ0FSckI7QUFBQSxNQVFkVSxTQVJjO0FBQUEsTUFRSEMsWUFSRzs7QUFBQSxtQkFTYVgsc0RBQVEsQ0FBQyxFQUFELENBVHJCO0FBQUEsTUFTZFksU0FUYztBQUFBLE1BU0hDLFlBVEc7O0FBQUEsbUJBVVdiLHNEQUFRLENBQUMsQ0FBRCxDQVZuQjtBQUFBLE1BVWRjLFFBVmM7QUFBQSxNQVVKQyxXQVZJOztBQUFBLG1CQVdXZixzREFBUSxDQUFDLENBQUQsQ0FYbkI7QUFBQSxNQVdkZ0IsUUFYYztBQUFBLE1BV0pDLFdBWEk7O0FBQUEsbUJBWWlCakIsc0RBQVEsQ0FBQyxDQUFELENBWnpCO0FBQUEsTUFZZGtCLFdBWmM7QUFBQSxNQVlEQyxjQVpDOztBQUFBLG9CQWEyQm5CLHNEQUFRLENBQUMsRUFBRCxDQWJuQztBQUFBLE1BYWRvQixnQkFiYztBQUFBLE1BYUlDLG1CQWJKOztBQUFBLG9CQWNxQ3JCLHNEQUFRLENBQUMsRUFBRCxDQWQ3QztBQUFBLE1BY2RzQixxQkFkYztBQUFBLE1BY1NDLHdCQWRUOztBQUFBLG9CQWVxQ3ZCLHNEQUFRLENBQUMsRUFBRCxDQWY3QztBQUFBLE1BZWR3QixxQkFmYztBQUFBLE1BZVNDLHdCQWZUOztBQUFBLG9CQWdCcUN6QixzREFBUSxDQUFDLEtBQUQsQ0FoQjdDO0FBQUEsTUFnQmQwQixxQkFoQmM7QUFBQSxNQWdCU0Msd0JBaEJUOztBQUFBLG9CQWlCTzNCLHNEQUFRLENBQUMsS0FBRCxDQWpCZjtBQUFBLE1BaUJkNEIsTUFqQmM7QUFBQSxNQWlCTkMsU0FqQk07O0FBQUEsb0JBa0JHN0Isc0RBQVEsQ0FBQyxFQUFELENBbEJYO0FBQUEsTUFrQmQ4QixJQWxCYztBQUFBLE1Ba0JSQyxPQWxCUTs7QUFBQSxvQkFtQlMvQixzREFBUSxDQUFDLEVBQUQsQ0FuQmpCO0FBQUEsTUFtQmRnQyxPQW5CYztBQUFBLE1BbUJMQyxVQW5CSzs7QUFBQSxvQkFvQkdqQyxzREFBUSxDQUFDLEVBQUQsQ0FwQlg7QUFBQSxNQW9CZGtDLElBcEJjO0FBQUEsTUFvQlJDLE9BcEJROztBQUFBLG9CQXFCYW5DLHNEQUFRLENBQUMsRUFBRCxDQXJCckI7QUFBQSxNQXFCZG9DLFNBckJjO0FBQUEsTUFxQkhDLFlBckJHOztBQUFBLG9CQXNCS3JDLHNEQUFRLENBQUMsRUFBRCxDQXRCYjtBQUFBLE1Bc0Jkc0MsS0F0QmM7QUFBQSxNQXNCUEMsUUF0Qk87O0FBQUEsb0JBdUJPdkMsc0RBQVEsQ0FBQyxFQUFELENBdkJmO0FBQUEsTUF1QmR3QyxNQXZCYztBQUFBLE1BdUJOQyxTQXZCTTs7QUFBQSx5QkF3QmExQyw0Q0FBSyxDQUFDQyxRQUFOLENBQWUsS0FBZixDQXhCYjtBQUFBO0FBQUEsTUF3QmQwQyxTQXhCYztBQUFBLE1Bd0JIQyxZQXhCRzs7QUFBQSxvQkF5QmEzQyxzREFBUSxDQUFDLEVBQUQsQ0F6QnJCO0FBQUEsTUF5QmQ0QyxTQXpCYztBQUFBLE1BeUJIQyxZQXpCRzs7QUFBQSxvQkEwQlc3QyxzREFBUSxDQUFDLEVBQUQsQ0ExQm5CO0FBQUEsTUEwQmQ4QyxRQTFCYztBQUFBLE1BMEJKQyxXQTFCSTs7QUFBQSxvQkEyQnFCL0Msc0RBQVEsQ0FBQyxFQUFELENBM0I3QjtBQUFBLE1BMkJkZ0QsYUEzQmM7QUFBQSxNQTJCQ0MsZ0JBM0JEOztBQUFBLG9CQTRCS2pELHNEQUFRLENBQUMsS0FBRCxDQTVCYjtBQUFBLE1BNEJka0QsS0E1QmM7QUFBQSxNQTRCUEMsUUE1Qk87O0FBQUEsb0JBNkJHbkQsc0RBQVEsQ0FBQyxFQUFELENBN0JYO0FBQUEsTUE2QmRvRCxJQTdCYztBQUFBLE1BNkJSQyxPQTdCUTs7QUFBQSxvQkE4QmVyRCxzREFBUSxDQUFDLEVBQUQsQ0E5QnZCO0FBQUEsTUE4QmRzRCxVQTlCYztBQUFBLE1BOEJGQyxhQTlCRTs7QUFBQSxvQkErQld2RCxzREFBUSxDQUFDLEtBQUQsQ0EvQm5CO0FBQUEsTUErQmR3RCxRQS9CYztBQUFBLE1BK0JKQyxXQS9CSTs7QUFBQSxvQkFnQ3FCekQsc0RBQVEsQ0FBQyxPQUFELENBaEM3QjtBQUFBLE1BZ0NkMEQsYUFoQ2M7QUFBQSxNQWdDQ0MsZ0JBaENEOztBQUFBLG9CQWlDNkIzRCxzREFBUSxDQUFDLEtBQUQsQ0FqQ3JDO0FBQUEsTUFpQ2Q0RCxpQkFqQ2M7QUFBQSxNQWlDS0Msb0JBakNMOztBQUFBLG9CQWtDdUM3RCxzREFBUSxDQUFDLE9BQUQsQ0FsQy9DO0FBQUEsTUFrQ2Q4RCxzQkFsQ2M7QUFBQSxNQWtDVUMseUJBbENWOztBQUFBLG9CQW1DYS9ELHNEQUFRLENBQUMsS0FBRCxDQW5DckI7QUFBQSxNQW1DZGdFLFNBbkNjO0FBQUEsTUFtQ0hDLFlBbkNHOztBQUFBLG9CQW9DdUJqRSxzREFBUSxDQUFDLE9BQUQsQ0FwQy9CO0FBQUEsTUFvQ2RrRSxjQXBDYztBQUFBLE1Bb0NFQyxpQkFwQ0Y7O0FBQUEsb0JBcUNtQm5FLHNEQUFRLENBQUMsS0FBRCxDQXJDM0I7QUFBQSxNQXFDZG9FLFlBckNjO0FBQUEsTUFxQ0FDLGVBckNBOztBQUFBLG9CQXNDNkJyRSxzREFBUSxDQUFDLE9BQUQsQ0F0Q3JDO0FBQUEsTUFzQ2RzRSxpQkF0Q2M7QUFBQSxNQXNDS0Msb0JBdENMOztBQUFBLG9CQXVDYXZFLHNEQUFRLENBQUMsS0FBRCxDQXZDckI7QUFBQSxNQXVDZHdFLFNBdkNjO0FBQUEsTUF1Q0hDLFlBdkNHOztBQUFBLG9CQXdDdUJ6RSxzREFBUSxDQUFDLE9BQUQsQ0F4Qy9CO0FBQUEsTUF3Q2QwRSxjQXhDYztBQUFBLE1Bd0NFQyxpQkF4Q0Y7O0FBQUEsb0JBeUNHM0Usc0RBQVEsQ0FBQyxFQUFELENBekNYO0FBQUEsTUF5Q2Q0RSxJQXpDYztBQUFBLE1BeUNSQyxPQXpDUTs7QUFBQSxvQkEwQ21CN0Usc0RBQVEsQ0FBQyxLQUFELENBMUMzQjtBQUFBLE1BMENkOEUsWUExQ2M7QUFBQSxNQTBDQUMsZUExQ0E7O0FBQUEsb0JBMkNXL0Usc0RBQVEsQ0FBQyxFQUFELENBM0NuQjtBQUFBLE1BMkNkZ0YsUUEzQ2M7QUFBQSxNQTJDSkMsV0EzQ0k7O0FBQUEsb0JBNENtQmpGLHNEQUFRLENBQUMsS0FBRCxDQTVDM0I7QUFBQSxNQTRDZGtGLFlBNUNjO0FBQUEsTUE0Q0FDLGVBNUNBOztBQUFBLG9CQTZDU25GLHNEQUFRLENBQUMsS0FBRCxDQTdDakI7QUFBQSxNQTZDZG9GLE9BN0NjO0FBQUEsTUE2Q0xDLFVBN0NLOztBQUFBLG9CQThDK0JyRixzREFBUSxDQUFDLEtBQUQsQ0E5Q3ZDO0FBQUEsTUE4Q2RzRixrQkE5Q2M7QUFBQSxNQThDTUMscUJBOUNOOztBQUFBLG9CQStDR3ZGLHNEQUFRLENBQUMsRUFBRCxDQS9DWDtBQUFBLE1BK0Nkd0YsSUEvQ2M7QUFBQSxNQStDUkMsT0EvQ1E7O0FBQUEsb0JBZ0RHekYsc0RBQVEsQ0FBQyxFQUFELENBaERYO0FBQUEsTUFnRGQwRixJQWhEYztBQUFBLE1BZ0RSQyxPQWhEUTs7QUFBQSxvQkFpREczRixzREFBUSxDQUFDLEVBQUQsQ0FqRFg7QUFBQSxNQWlEZDRGLElBakRjO0FBQUEsTUFpRFJDLE9BakRROztBQUFBLG9CQWtERzdGLHNEQUFRLENBQUMsRUFBRCxDQWxEWDtBQUFBLE1Ba0RkOEYsSUFsRGM7QUFBQSxNQWtEUkMsT0FsRFE7O0FBQUEsb0JBbURHL0Ysc0RBQVEsQ0FBQyxFQUFELENBbkRYO0FBQUEsTUFtRGRnRyxJQW5EYztBQUFBLE1BbURSQyxPQW5EUTs7QUFBQSxvQkFvREdqRyxzREFBUSxDQUFDLEVBQUQsQ0FwRFg7QUFBQSxNQW9EZGtHLElBcERjO0FBQUEsTUFvRFJDLE9BcERROztBQUFBLG9CQXFER25HLHNEQUFRLENBQUMsRUFBRCxDQXJEWDtBQUFBLE1BcURkb0csSUFyRGM7QUFBQSxNQXFEUkMsT0FyRFE7O0FBQUEsb0JBc0RHckcsc0RBQVEsQ0FBQyxFQUFELENBdERYO0FBQUEsTUFzRGRzRyxJQXREYztBQUFBLE1Bc0RSQyxPQXREUTs7QUFBQSxvQkF1RG1Cdkcsc0RBQVEsQ0FBQztBQUM3Q3dHLE9BQUcsRUFBRUMsc0RBQWEsR0FBR0MsR0FBaEIsQ0FBb0IsQ0FBQyxDQUFyQixFQUF3QixNQUF4QixDQUR3QztBQUU3Q0MsT0FBRyxFQUFFRixzREFBYSxHQUFHQyxHQUFoQixDQUFvQixFQUFwQixFQUF3QixNQUF4QjtBQUZ3QyxHQUFELENBdkQzQjtBQUFBLE1BdURkRSxZQXZEYztBQUFBLE1BdURBQyxlQXZEQTs7QUEyRHJCQyxrREFBUSxDQUFDQyxNQUFULENBQWdCQyxJQUFoQixDQUFxQjtBQUNqQi9ILFNBQUssRUFBRSxPQURVO0FBRWpCZ0ksV0FBTyxFQUFFLEtBRlE7QUFHakJDLFlBQVEsRUFBRSxNQUhPO0FBSWpCQyxjQUFVLEVBQUUsYUFKSztBQUtqQm5JLFlBQVEsRUFBRSxZQUxPO0FBTWpCb0ksZUFBVyxFQUFFLElBTkk7QUFPakJDLE9BQUcsRUFBRSxJQVBZO0FBUWpCQyxxQkFBaUIsRUFBRTtBQVJGLEdBQXJCO0FBVUFSLGtEQUFRLENBQUNTLE9BQVQsQ0FBaUJQLElBQWpCLENBQXNCO0FBQ2xCUSxZQUFRLEVBQUVDLG1CQUE0QkM7QUFEcEIsR0FBdEI7QUFHQSxNQUFJQyxHQUFHLEdBQUdGLDBCQUFWOztBQXhFcUIsb0JBeUVLekgsc0RBQVEsQ0FBQztBQUMvQndELFlBQVEsRUFBRUEsUUFEcUI7QUFFL0JRLGFBQVMsRUFBRUEsU0FGb0I7QUFHL0JKLHFCQUFpQixFQUFFQSxpQkFIWTtBQUkvQlksYUFBUyxFQUFFQSxTQUpvQjtBQUsvQkosZ0JBQVksRUFBRUE7QUFMaUIsR0FBRCxDQXpFYjtBQUFBLE1BeUVkd0QsS0F6RWM7QUFBQSxNQXlFUEMsUUF6RU87O0FBZ0ZyQixNQUFJQyxRQUFRLEdBQUc7QUFDWEMsYUFBUyxFQUFFLENBREE7QUFFWHBKLFFBQUksRUFBRSxFQUZLO0FBR1hxSixNQUFFLEVBQUUsRUFITztBQUlYQyxTQUFLLEVBQUUsRUFKSTtBQUtYQyxRQUFJLEVBQUU7QUFMSyxHQUFmOztBQU9BLE1BQU1DLFVBQVUsR0FBRyxTQUFiQSxVQUFhLENBQUNDLEtBQUQsRUFBVztBQUMxQixRQUFJQyxFQUFFLEdBQUdDLFFBQVEsQ0FBQ0YsS0FBSyxDQUFDRyxNQUFOLENBQWFGLEVBQWQsQ0FBakI7QUFDQTtBQUNSO0FBQ0E7O0FBQ1EsUUFBSSxDQUFDRCxLQUFLLENBQUNHLE1BQU4sQ0FBYUMsUUFBYixDQUFzQkMsS0FBM0IsRUFBa0M7QUFDOUI7QUFDSCxLQUZELE1BRU8sSUFBSUwsS0FBSyxDQUFDTSxPQUFOLEtBQWtCWixRQUFRLENBQUNDLFNBQS9CLEVBQTBDO0FBQzdDLGNBQVFNLEVBQVI7QUFDSSxhQUFLLENBQUw7QUFDSTVDLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lFLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lFLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lFLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lFLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lFLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lFLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lFLGlCQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0E7QUF4QlI7O0FBMkJBLFVBQUlvQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsQ0FBQ1AsRUFBRSxHQUFHLENBQU4sRUFBU1EsUUFBVCxFQUF4QixLQUFnRCxJQUFwRCxFQUNJRixRQUFRLENBQUNDLGNBQVQsQ0FBd0IsQ0FBQ1AsRUFBRSxHQUFHLENBQU4sRUFBU1EsUUFBVCxFQUF4QixFQUE2Q0MsS0FBN0MsR0FESixLQUVLSCxRQUFRLENBQUNDLGNBQVQsQ0FBeUJQLEVBQUQsQ0FBS1EsUUFBTCxFQUF4QixFQUF5Q0MsS0FBekM7QUFDUixLQS9CTSxNQStCQSxJQUFJVixLQUFLLENBQUNNLE9BQU4sS0FBa0JaLFFBQVEsQ0FBQ25KLElBQS9CLEVBQXFDO0FBQ3hDLFVBQUlnSyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsQ0FBQ1AsRUFBRSxHQUFHLENBQU4sRUFBU1EsUUFBVCxFQUF4QixLQUFnRCxJQUFwRCxFQUNJRixRQUFRLENBQUNDLGNBQVQsQ0FBd0IsQ0FBQ1AsRUFBRSxHQUFHLENBQU4sRUFBU1EsUUFBVCxFQUF4QixFQUE2Q0MsS0FBN0MsR0FESixLQUVLSCxRQUFRLENBQUNDLGNBQVQsQ0FBeUJQLEVBQUQsQ0FBS1EsUUFBTCxFQUF4QixFQUF5Q0MsS0FBekM7QUFDUixLQUpNLE1BSUEsSUFBSVYsS0FBSyxDQUFDTSxPQUFOLEtBQWtCWixRQUFRLENBQUNHLEtBQS9CLEVBQXNDO0FBQ3pDLFVBQUlVLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixDQUFDUCxFQUFFLEdBQUcsQ0FBTixFQUFTUSxRQUFULEVBQXhCLEtBQWdELElBQXBELEVBQ0lGLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixDQUFDUCxFQUFFLEdBQUcsQ0FBTixFQUFTUSxRQUFULEVBQXhCLEVBQTZDQyxLQUE3QyxHQURKLEtBRUtILFFBQVEsQ0FBQ0MsY0FBVCxDQUF5QlAsRUFBRCxDQUFLUSxRQUFMLEVBQXhCLEVBQXlDQyxLQUF6QztBQUNSLEtBSk0sTUFJQSxJQUFJVixLQUFLLENBQUNNLE9BQU4sS0FBa0JaLFFBQVEsQ0FBQ0UsRUFBM0IsSUFBaUNJLEtBQUssQ0FBQ00sT0FBTixLQUFrQlosUUFBUSxDQUFDSSxJQUFoRSxFQUFzRSxDQUN6RTtBQUNILEtBRk0sTUFFQSxJQUFJRSxLQUFLLENBQUNHLE1BQU4sQ0FBYVEsS0FBYixJQUFzQixFQUExQixFQUE4QjtBQUNqQyxjQUFRVixFQUFSO0FBQ0ksYUFBSyxDQUFMO0FBQ0k1QyxpQkFBTyxDQUFDMkMsS0FBSyxDQUFDRyxNQUFOLENBQWFRLEtBQWQsQ0FBUDtBQUNBOztBQUNKLGFBQUssQ0FBTDtBQUNJcEQsaUJBQU8sQ0FBQ3lDLEtBQUssQ0FBQ0csTUFBTixDQUFhUSxLQUFkLENBQVA7QUFDQTs7QUFDSixhQUFLLENBQUw7QUFDSWxELGlCQUFPLENBQUN1QyxLQUFLLENBQUNHLE1BQU4sQ0FBYVEsS0FBZCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0loRCxpQkFBTyxDQUFDcUMsS0FBSyxDQUFDRyxNQUFOLENBQWFRLEtBQWQsQ0FBUDtBQUNBOztBQUNKLGFBQUssQ0FBTDtBQUNJOUMsaUJBQU8sQ0FBQ21DLEtBQUssQ0FBQ0csTUFBTixDQUFhUSxLQUFkLENBQVA7QUFDQTs7QUFDSixhQUFLLENBQUw7QUFDSTVDLGlCQUFPLENBQUNpQyxLQUFLLENBQUNHLE1BQU4sQ0FBYVEsS0FBZCxDQUFQO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0kxQyxpQkFBTyxDQUFDK0IsS0FBSyxDQUFDRyxNQUFOLENBQWFRLEtBQWQsQ0FBUDtBQUNBOztBQUNKLGFBQUssQ0FBTDtBQUNJeEMsaUJBQU8sQ0FBQzZCLEtBQUssQ0FBQ0csTUFBTixDQUFhUSxLQUFkLENBQVA7QUFDQXRHLG1CQUFTLENBQUMrQyxJQUFJLEdBQUdFLElBQVAsR0FBY0UsSUFBZCxHQUFxQkUsSUFBckIsR0FBNEJFLElBQTVCLEdBQW1DRSxJQUFuQyxHQUEwQ0UsSUFBMUMsR0FBaURnQyxLQUFLLENBQUNHLE1BQU4sQ0FBYVEsS0FBL0QsQ0FBVCxDQUZKLENBR0k7O0FBQ0FsRyxzQkFBWSxpQ0FDTEQsU0FESztBQUVSSixrQkFBTSxFQUFFZ0QsSUFBSSxHQUFHRSxJQUFQLEdBQWNFLElBQWQsR0FBcUJFLElBQXJCLEdBQTRCRSxJQUE1QixHQUFtQ0UsSUFBbkMsR0FBMENFLElBQTFDLEdBQWlEZ0MsS0FBSyxDQUFDRyxNQUFOLENBQWFRO0FBRjlELGFBQVo7QUFJQTtBQTlCUixPQURpQyxDQWtDakM7OztBQUNBLFVBQUlKLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixDQUFDUCxFQUFFLEdBQUcsQ0FBTixFQUFTUSxRQUFULEVBQXhCLEtBQWdELElBQXBELEVBQ0lGLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixDQUFDUCxFQUFFLEdBQUcsQ0FBTixFQUFTUSxRQUFULEVBQXhCLEVBQTZDQyxLQUE3QyxHQURKLEtBRUtILFFBQVEsQ0FBQ0MsY0FBVCxDQUF5QlAsRUFBRCxDQUFLUSxRQUFMLEVBQXhCLEVBQXlDQyxLQUF6QztBQUNSO0FBQ0osR0F2RkQ7QUF3RkE7QUFDSjtBQUNBO0FBQ0E7OztBQUNJLE1BQUlFLFdBQVcsR0FBRyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLE9BQW5CLEVBQTRCLE9BQTVCLEVBQXFDLE9BQXJDLEVBQThDLE9BQTlDLEVBQXVELE9BQXZELEVBQWdFLE9BQWhFLEVBQXlFLE9BQXpFLEVBQWtGLE9BQWxGLEVBQTJGLE9BQTNGLEVBQW9HLE9BQXBHLEVBQ2QsT0FEYyxFQUNMLE9BREssRUFDSSxPQURKLEVBQ2EsT0FEYixFQUNzQixPQUR0QixFQUMrQixPQUQvQixFQUN3QyxPQUR4QyxFQUNpRCxPQURqRCxFQUVkLE9BRmMsRUFFTCxPQUZLLEVBRUksT0FGSixFQUVhLE9BRmIsRUFFc0IsT0FGdEIsRUFFK0IsT0FGL0IsRUFFd0MsT0FGeEMsRUFFaUQsT0FGakQsRUFHZCxPQUhjLEVBR0wsT0FISyxFQUdJLE9BSEosRUFHYSxPQUhiLEVBR3NCLE9BSHRCLEVBRytCLE9BSC9CLEVBR3dDLE9BSHhDLEVBR2lELE9BSGpELEVBRzBELE9BSDFELENBQWxCOztBQUtBLE1BQU1DLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNDLE9BQUQsRUFBYTtBQUM5QixRQUFJQyxLQUFLLEdBQUcsSUFBSUMsSUFBSixFQUFaO0FBQ0EsUUFBSUMsUUFBUSxHQUFHLENBQUNGLEtBQUssQ0FBQ0csUUFBTixLQUFtQixDQUFwQixFQUF1QlQsUUFBdkIsRUFBZjtBQUNBLFFBQUlRLFFBQVEsQ0FBQ0UsTUFBVCxJQUFtQixDQUF2QixFQUEwQkYsUUFBUSxHQUFHLE1BQU1BLFFBQWpCO0FBQzFCLFFBQUlHLFFBQVEsR0FBR0wsS0FBSyxDQUFDTSxVQUFOLEdBQW1CWixRQUFuQixFQUFmO0FBQ0EsUUFBSVcsUUFBUSxDQUFDRCxNQUFULElBQW1CLENBQXZCLEVBQTBCQyxRQUFRLEdBQUcsTUFBTUEsUUFBakI7QUFDMUIsUUFBSUUsT0FBTyxHQUFHTCxRQUFRLEdBQUcsR0FBWCxHQUFpQkcsUUFBL0I7QUFDQSxRQUFJL0Msc0RBQWEsQ0FBQzBDLEtBQUQsQ0FBYixDQUFxQlEsS0FBckIsTUFBZ0NsRCxzREFBYSxDQUFDeUMsT0FBRCxDQUFiLENBQXVCUyxLQUF2QixFQUFoQyxJQUNHbEQsc0RBQWEsQ0FBQzBDLEtBQUQsQ0FBYixDQUFxQlMsTUFBckIsTUFBaUNuRCxzREFBYSxDQUFDeUMsT0FBRCxDQUFiLENBQXVCVSxNQUF2QixFQURwQyxJQUVHbkQsc0RBQWEsQ0FBQzBDLEtBQUQsQ0FBYixDQUFxQlUsS0FBckIsTUFBZ0NwRCxzREFBYSxDQUFDeUMsT0FBRCxDQUFiLENBQXVCVyxLQUF2QixFQUZ2QyxFQUdJdEgsUUFBUSxDQUFDeUcsV0FBVyxDQUFDYyxHQUFaLENBQWdCLFVBQUNoSSxJQUFELEVBQU9pSSxLQUFQO0FBQUEsYUFDckJMLE9BQU8sR0FBRzVILElBQVYsZ0JBQ0kscUVBQUMsMERBQUQ7QUFBc0IsYUFBSyxFQUFFQSxJQUE3QjtBQUFBLGtCQUFvQ0E7QUFBcEMsU0FBZWlJLEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKLEdBRUksSUFIaUI7QUFBQSxLQUFoQixDQUFELENBQVIsQ0FISixLQVNJeEgsUUFBUSxDQUFDeUcsV0FBVyxDQUFDYyxHQUFaLENBQWdCLFVBQUNoSSxJQUFELEVBQU9pSSxLQUFQO0FBQUEsMEJBQ3JCLHFFQUFDLDBEQUFEO0FBQXNCLGFBQUssRUFBRWpJLElBQTdCO0FBQUEsa0JBQW9DQTtBQUFwQyxTQUFlaUksS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRHFCO0FBQUEsS0FBaEIsQ0FBRCxDQUFSO0FBR0o7QUFDUjtBQUNBO0FBQ0E7O0FBQ1FoSSxXQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0FFLGNBQVUsQ0FBQyxFQUFELENBQVY7QUFDSCxHQXpCRDs7QUEwQkErSCx5REFBUyxDQUFDLFlBQU07QUFFWkMsa0JBQWMsQ0FBQyxFQUFELENBQWQ7QUFDQUMsYUFBUztBQUNULFFBQU1DLGVBQWUsR0FBRyxJQUFJQyxlQUFKLEVBQXhCO0FBQ0EsUUFBTUMsT0FBTyxHQUFHQyxNQUFNLENBQ2pCQyxLQURXLENBQ0w1QyxHQUFHLEdBQUcsY0FERCxFQUNpQjtBQUN6QjZDLGFBQU8sRUFBRTtBQUNMLGtCQUFVLGtCQURMO0FBRUwsd0JBQWdCLGtCQUZYO0FBR0wsb0JBQVksT0FIUDtBQUdrQjtBQUN2Qix1Q0FBK0I7QUFKMUIsT0FEZ0I7QUFPekJDLFlBQU0sRUFBRSxLQVBpQjtBQVF6QkMsVUFBSSxFQUFFLE1BUm1CO0FBU3pCQyxZQUFNLEVBQUVSLGVBQWUsQ0FBQ1E7QUFUQyxLQURqQixFQVlYQyxJQVpXLENBWU4sVUFBQUMsR0FBRztBQUFBLGFBQUlBLEdBQUcsQ0FBQ0MsSUFBSixFQUFKO0FBQUEsS0FaRyxFQWFYRixJQWJXLENBYU4sVUFBQUcsWUFBWSxFQUFJO0FBQ2xCLFVBQUlBLFlBQVksQ0FBQ0MsT0FBYixJQUF3Qiw4QkFBNUIsRUFBNEQ7QUFDeERySyxvQkFBWSxDQUFDb0ssWUFBWSxDQUFDRSxNQUFkLENBQVo7O0FBQ0EsWUFBSSxDQUFDQyxPQUFPLENBQUN2TCxLQUFLLENBQUNpRCxTQUFQLENBQVosRUFBK0I7QUFDM0IsY0FBSWpELEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0IxQixXQUFoQixHQUE4QixDQUFsQyxFQUFxQztBQUNqQ0gsdUJBQVcsQ0FBQyxDQUFELENBQVg7QUFDQUUsdUJBQVcsQ0FBQyxDQUFELENBQVg7QUFDQVYsNEJBQWdCLENBQUMsRUFBRCxDQUFoQjtBQUNBRSw0QkFBZ0IsQ0FBQyxFQUFELENBQWhCO0FBQ0FvQyx3QkFBWSxpQ0FDTEQsU0FESztBQUVSMUIseUJBQVcsRUFBRXZCLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0IxQixXQUZyQjtBQUdSRixzQkFBUSxFQUFFLENBSEY7QUFJUm1LLHdCQUFVLEVBQUUsRUFKSjtBQUtSckssc0JBQVEsRUFBRSxDQUxGO0FBTVJzSyx3QkFBVSxFQUFFO0FBTkosZUFBWjtBQVFBekosb0NBQXdCLENBQUMsSUFBRCxDQUF4QjtBQUNILFdBZEQsTUFjTztBQUNIcEIsNEJBQWdCLENBQUNaLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0J3SSxVQUFqQixDQUFoQjtBQUNBckssdUJBQVcsQ0FBQ3BCLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0I5QixRQUFqQixDQUFYO0FBQ0ErQix3QkFBWSxpQ0FDTEQsU0FESztBQUVSOUIsc0JBQVEsRUFBRW5CLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0I5QixRQUZsQjtBQUdSc0ssd0JBQVUsRUFBRXpMLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0J3STtBQUhwQixlQUFaO0FBS0g7O0FBQ0RDLGtCQUFRLENBQUMsSUFBRCxDQUFSO0FBQ0g7QUFDSjtBQUNKLEtBM0NXLFdBNENMLFVBQUFDLEdBQUcsRUFBSTtBQUNWQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsR0FBWjtBQUNILEtBOUNXLENBQWhCLENBTFksQ0FvRFo7O0FBQ0FHLGNBQVUsQ0FBQztBQUFBLGFBQU10QixlQUFlLENBQUN1QixLQUFoQixFQUFOO0FBQUEsS0FBRCxFQUFnQ2pFLE1BQWhDLENBQVY7O0FBRUEsUUFBSSxDQUFDeUQsT0FBTyxDQUFDdkwsS0FBSyxDQUFDaUQsU0FBUCxDQUFaLEVBQStCO0FBQzNCMkksYUFBTyxDQUFDQyxHQUFSLENBQVk3TCxLQUFLLENBQUNpRCxTQUFsQjtBQUNBQyxrQkFBWSxDQUFDbEQsS0FBSyxDQUFDaUQsU0FBUCxDQUFaOztBQUNBLFVBQUlqRCxLQUFLLENBQUNpRCxTQUFOLENBQWdCRSxRQUFoQixDQUF5QjZJLFFBQXpCLENBQWtDLENBQWxDLENBQUosRUFBMEM7QUFDdENsSSxtQkFBVyxDQUFDLElBQUQsQ0FBWDtBQUNBRSx3QkFBZ0IsQ0FBQyxNQUFELENBQWhCO0FBQ0g7O0FBQ0QsVUFBSWhFLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JFLFFBQWhCLENBQXlCNkksUUFBekIsQ0FBa0MsQ0FBbEMsQ0FBSixFQUEwQztBQUN0QzFILG9CQUFZLENBQUMsSUFBRCxDQUFaO0FBQ0FFLHlCQUFpQixDQUFDLE1BQUQsQ0FBakI7QUFDSDs7QUFDRCxVQUFJeEUsS0FBSyxDQUFDaUQsU0FBTixDQUFnQkUsUUFBaEIsQ0FBeUI2SSxRQUF6QixDQUFrQyxDQUFsQyxDQUFKLEVBQTBDO0FBQ3RDbEgsb0JBQVksQ0FBQyxJQUFELENBQVo7QUFDQUUseUJBQWlCLENBQUMsTUFBRCxDQUFqQjtBQUNIOztBQUNELFVBQUloRixLQUFLLENBQUNpRCxTQUFOLENBQWdCRSxRQUFoQixDQUF5QjZJLFFBQXpCLENBQWtDLENBQWxDLENBQUosRUFBMEM7QUFDdEN0SCx1QkFBZSxDQUFDLElBQUQsQ0FBZjtBQUNBRSw0QkFBb0IsQ0FBQyxNQUFELENBQXBCO0FBQ0g7O0FBQ0R0QixzQkFBZ0IsQ0FBQ3RELEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JJLGFBQWpCLENBQWhCO0FBQ0FELGlCQUFXLENBQUNwRCxLQUFLLENBQUNpRCxTQUFOLENBQWdCRSxRQUFqQixDQUFYO0FBQ0ErRSxjQUFRLGlDQUNERCxLQURDO0FBRUpwRSxnQkFBUSxFQUFFN0QsS0FBSyxDQUFDaUQsU0FBTixDQUFnQkUsUUFBaEIsQ0FBeUI2SSxRQUF6QixDQUFrQyxDQUFsQyxJQUF1QyxJQUF2QyxHQUE4QyxLQUZwRDtBQUdKM0gsaUJBQVMsRUFBRXJFLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JFLFFBQWhCLENBQXlCNkksUUFBekIsQ0FBa0MsQ0FBbEMsSUFBdUMsSUFBdkMsR0FBOEMsS0FIckQ7QUFJSnZILG9CQUFZLEVBQUV6RSxLQUFLLENBQUNpRCxTQUFOLENBQWdCRSxRQUFoQixDQUF5QjZJLFFBQXpCLENBQWtDLENBQWxDLElBQXVDLElBQXZDLEdBQThDLEtBSnhEO0FBS0puSCxpQkFBUyxFQUFFN0UsS0FBSyxDQUFDaUQsU0FBTixDQUFnQkUsUUFBaEIsQ0FBeUI2SSxRQUF6QixDQUFrQyxDQUFsQyxJQUF1QyxJQUF2QyxHQUE4QztBQUxyRCxTQUFSLENBckIyQixDQTRCM0I7O0FBRUF4SixhQUFPLENBQUNzRSxzREFBYSxDQUFDOUcsS0FBSyxDQUFDaUQsU0FBTixDQUFnQlYsSUFBakIsQ0FBZCxFQUFzQyxhQUF0QyxDQUFQO0FBQ0FXLGtCQUFZLGlDQUFLRCxTQUFMO0FBQWdCVixZQUFJLEVBQUV2QyxLQUFLLENBQUNpRCxTQUFOLENBQWdCVjtBQUF0QyxTQUFaO0FBQ0FLLGNBQVEsQ0FBQ3lHLFdBQVcsQ0FBQ2MsR0FBWixDQUFnQixVQUFDaEksSUFBRCxFQUFPaUksS0FBUDtBQUFBLDRCQUNyQixxRUFBQywwREFBRDtBQUFzQixlQUFLLEVBQUVqSSxJQUE3QjtBQUFBLG9CQUFvQ0E7QUFBcEMsV0FBZWlJLEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFEcUI7QUFBQSxPQUFoQixDQUFELENBQVI7QUFHQXNCLGNBQVEsQ0FBQyxJQUFELENBQVI7QUFDQXRKLGFBQU8sQ0FBQ3BDLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JkLElBQWpCLENBQVA7QUFDQUcsZ0JBQVUsQ0FBQ3RDLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JnSixPQUFqQixDQUFWO0FBQ0FDLG9CQUFjLENBQUNsTSxLQUFLLENBQUNpRCxTQUFOLENBQWdCRSxRQUFqQixFQUEyQm5ELEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0I1QixRQUEzQyxDQUFkO0FBQ0FtQyxjQUFRLENBQUN4RCxLQUFLLENBQUNpRCxTQUFOLENBQWdCTSxLQUFqQixDQUFSO0FBQ0FyQixlQUFTLENBQUNsQyxLQUFLLENBQUNpRCxTQUFOLENBQWdCa0osT0FBakIsQ0FBVDs7QUFDQSxVQUFJbk0sS0FBSyxDQUFDaUQsU0FBTixDQUFnQkosTUFBaEIsSUFBMEJ1SixTQUE5QixFQUF5QztBQUNyQyxZQUFJQyxHQUFHLEdBQUdyTSxLQUFLLENBQUNpRCxTQUFOLENBQWdCSixNQUFoQixDQUF1QnlKLEtBQXZCLENBQTZCLEVBQTdCLENBQVY7QUFDQXhKLGlCQUFTLENBQUM5QyxLQUFLLENBQUNpRCxTQUFOLENBQWdCSixNQUFqQixDQUFUO0FBQ0FpRCxlQUFPLENBQUN1RyxHQUFHLENBQUMsQ0FBRCxDQUFKLENBQVA7QUFDQXJHLGVBQU8sQ0FBQ3FHLEdBQUcsQ0FBQyxDQUFELENBQUosQ0FBUDtBQUNBbkcsZUFBTyxDQUFDbEcsS0FBSyxDQUFDaUQsU0FBTixDQUFnQkosTUFBaEIsQ0FBdUIsQ0FBdkIsQ0FBRCxDQUFQO0FBQ0F1RCxlQUFPLENBQUNwRyxLQUFLLENBQUNpRCxTQUFOLENBQWdCSixNQUFoQixDQUF1QixDQUF2QixDQUFELENBQVA7QUFDQXlELGVBQU8sQ0FBQ3RHLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JKLE1BQWhCLENBQXVCLENBQXZCLENBQUQsQ0FBUDtBQUNBMkQsZUFBTyxDQUFDeEcsS0FBSyxDQUFDaUQsU0FBTixDQUFnQkosTUFBaEIsQ0FBdUIsQ0FBdkIsQ0FBRCxDQUFQO0FBQ0E2RCxlQUFPLENBQUMxRyxLQUFLLENBQUNpRCxTQUFOLENBQWdCSixNQUFoQixDQUF1QixDQUF2QixDQUFELENBQVA7QUFDQStELGVBQU8sQ0FBQzVHLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JKLE1BQWhCLENBQXVCLENBQXZCLENBQUQsQ0FBUDtBQUVIOztBQUNELFVBQUk3QyxLQUFLLENBQUNpRCxTQUFOLENBQWdCc0osT0FBaEIsSUFBMkJILFNBQS9CLEVBQTBDO0FBQ3RDbEgsZUFBTyxDQUFDbEYsS0FBSyxDQUFDaUQsU0FBTixDQUFnQnVKLFFBQWpCLENBQVA7QUFDSDs7QUFFRCxVQUFJeE0sS0FBSyxDQUFDaUQsU0FBTixDQUFnQmtKLE9BQWhCLElBQTJCbk0sS0FBSyxDQUFDaUQsU0FBTixDQUFnQkosTUFBaEIsSUFBMEJ1SixTQUFyRCxJQUFrRXBNLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0JzSixPQUFoQixJQUEyQkgsU0FBakcsRUFBNEc7QUFDeEc1Ryx1QkFBZSxDQUFDLElBQUQsQ0FBZjtBQUNBbEIsb0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQUUseUJBQWlCLENBQUMsZ0JBQUQsQ0FBakI7QUFDQUUsdUJBQWUsQ0FBQyxLQUFELENBQWY7QUFDQUUsNEJBQW9CLENBQUMsZ0JBQUQsQ0FBcEI7QUFDSDtBQUNKLEtBakVELE1BaUVPO0FBQ0gsVUFBSTZILENBQUMsR0FBRzNGLHNEQUFhLEdBQUdDLEdBQWhCLENBQW9CLENBQXBCLEVBQXVCLE1BQXZCLENBQVI7QUFDQXZFLGFBQU8sQ0FBQ2lLLENBQUQsRUFBSSxhQUFKLENBQVA7QUFDQSxVQUFJekQsUUFBUSxDQUFDMEQsc0JBQVQsQ0FBZ0Msa0JBQWhDLEVBQW9ELENBQXBELEtBQTBETixTQUE5RCxFQUNJcEQsUUFBUSxDQUFDMEQsc0JBQVQsQ0FBZ0Msa0JBQWhDLEVBQW9ELENBQXBELEVBQXVEQyxZQUF2RCxDQUFvRSxVQUFwRSxFQUFnRixVQUFoRjtBQUNKckQsa0JBQVksQ0FBQ21ELENBQUQsQ0FBWjtBQUNIO0FBQ0osR0EvSFEsRUErSE4sRUEvSE0sQ0FBVDs7QUFpSUEsV0FBU2xCLE9BQVQsQ0FBaUJxQixHQUFqQixFQUFzQjtBQUNsQixXQUFPQyxNQUFNLENBQUNDLElBQVAsQ0FBWUYsR0FBWixFQUFpQmhELE1BQWpCLEtBQTRCLENBQW5DO0FBQ0g7O0FBRUQsTUFBSW1ELEtBQUssR0FBRyxJQUFaO0FBQ0EsTUFBSUMsV0FBVyxHQUFHLENBQWxCOztBQUNBLFlBQWtDO0FBQzlCRCxTQUFLLEdBQUdFLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsYUFBckIsQ0FBWCxDQUFSO0FBQ0FKLGVBQVcsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixRQUFyQixDQUFYLENBQWQ7QUFDSDs7QUFDRCxNQUFNN0MsU0FBUyxHQUFHLFNBQVpBLFNBQVksR0FBTTtBQUNwQixRQUFNQyxlQUFlLEdBQUcsSUFBSUMsZUFBSixFQUF4QjtBQUNBLFFBQU1DLE9BQU8sR0FBR0MsTUFBTSxDQUNqQkMsS0FEVyxDQUNMNUMsR0FBRyxHQUFHLFdBREQsRUFDYztBQUN0QjZDLGFBQU8sRUFBRTtBQUNMLGtCQUFVLGtCQURMO0FBRUwsd0JBQWdCLGtCQUZYO0FBR0wsb0JBQVksT0FIUDtBQUdrQjtBQUN2Qix1Q0FBK0IsR0FKMUI7QUFLTCx5QkFBaUIsWUFBWWtDO0FBTHhCLE9BRGE7QUFRdEJqQyxZQUFNLEVBQUUsS0FSYztBQVN0QkMsVUFBSSxFQUFFLE1BVGdCO0FBVXRCQyxZQUFNLEVBQUVSLGVBQWUsQ0FBQ1E7QUFWRixLQURkLEVBYVhDLElBYlcsQ0FhTixVQUFBQyxHQUFHO0FBQUEsYUFBSUEsR0FBRyxDQUFDQyxJQUFKLEVBQUo7QUFBQSxLQWJHLEVBY1hGLElBZFcsQ0FjTixVQUFBRyxZQUFZLEVBQUk7QUFDbEIsVUFBSUEsWUFBWSxDQUFDQyxPQUFiLElBQXdCLCtCQUE1QixFQUE2RDtBQUN6RHpILHFCQUFhLENBQUN3SCxZQUFZLENBQUNpQyxTQUFkLENBQWI7QUFDQSxZQUFJQyxDQUFDLEdBQUcsRUFBUjtBQUNBbEMsb0JBQVksQ0FBQ2lDLFNBQWIsQ0FBdUJsRCxHQUF2QixDQUEyQixVQUFDb0QsR0FBRCxFQUFNbkQsS0FBTjtBQUFBLGlCQUN2Qm1ELEdBQUcsQ0FBQ0MsSUFBSixJQUFZLEVBQVosR0FBaUJGLENBQUMsQ0FBQ0csSUFBRixDQUFPO0FBQUNDLGlCQUFLLEVBQUVILEdBQUcsQ0FBQ0ksS0FBSixDQUFVSCxJQUFsQjtBQUF3QjlFLGNBQUUsRUFBRTZFLEdBQUcsQ0FBQzdFO0FBQWhDLFdBQVAsQ0FBakIsR0FBK0QsSUFEeEM7QUFBQSxTQUEzQjtBQUdBaEYsZUFBTyxDQUFDNEosQ0FBRCxDQUFQOztBQUNBLFlBQUksQ0FBQy9CLE9BQU8sQ0FBQ3ZMLEtBQUssQ0FBQ2lELFNBQVAsQ0FBWixFQUErQjtBQUUzQixjQUFJakQsS0FBSyxDQUFDaUQsU0FBTixDQUFnQjFCLFdBQWhCLEdBQThCLENBQWxDLEVBQXFDO0FBQ2pDQywwQkFBYyxDQUFDeEIsS0FBSyxDQUFDaUQsU0FBTixDQUFnQjFCLFdBQWpCLENBQWQ7QUFDQUQsdUJBQVcsQ0FBQ3RCLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0IxQixXQUFqQixDQUFYOztBQUNBLGlCQUFLLElBQUlxTSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHeEMsWUFBWSxDQUFDaUMsU0FBYixDQUF1QnpELE1BQTNDLEVBQW1EZ0UsQ0FBQyxFQUFwRDtBQUNJLGtCQUFJeEMsWUFBWSxDQUFDaUMsU0FBYixDQUF1Qk8sQ0FBdkIsRUFBMEJsRixFQUExQixJQUFnQzFJLEtBQUssQ0FBQ2lELFNBQU4sQ0FBZ0IxQixXQUFwRCxFQUFpRTtBQUM3REcsbUNBQW1CLENBQUMwSixZQUFZLENBQUNpQyxTQUFiLENBQXVCTyxDQUF2QixFQUEwQkQsS0FBMUIsQ0FBZ0NILElBQWpDLENBQW5CO0FBQ0F4TCx3Q0FBd0IsQ0FBQyxJQUFELENBQXhCOztBQUNBLG9CQUFJaEMsS0FBSyxDQUFDaUQsU0FBTixDQUFnQkosTUFBaEIsSUFBMEJ1SixTQUE5QixFQUF5QztBQUNyQ3RKLDJCQUFTLENBQUNzSSxZQUFZLENBQUNpQyxTQUFiLENBQXVCTyxDQUF2QixFQUEwQkMsTUFBM0IsQ0FBVDtBQUNBL0gseUJBQU8sQ0FBQ3NGLFlBQVksQ0FBQ2lDLFNBQWIsQ0FBdUJPLENBQXZCLEVBQTBCQyxNQUExQixDQUFpQyxDQUFqQyxDQUFELENBQVA7QUFDQTdILHlCQUFPLENBQUNvRixZQUFZLENBQUNpQyxTQUFiLENBQXVCTyxDQUF2QixFQUEwQkMsTUFBMUIsQ0FBaUMsQ0FBakMsQ0FBRCxDQUFQO0FBQ0EzSCx5QkFBTyxDQUFDa0YsWUFBWSxDQUFDaUMsU0FBYixDQUF1Qk8sQ0FBdkIsRUFBMEJDLE1BQTFCLENBQWlDLENBQWpDLENBQUQsQ0FBUDtBQUNBekgseUJBQU8sQ0FBQ2dGLFlBQVksQ0FBQ2lDLFNBQWIsQ0FBdUJPLENBQXZCLEVBQTBCQyxNQUExQixDQUFpQyxDQUFqQyxDQUFELENBQVA7QUFDQXZILHlCQUFPLENBQUM4RSxZQUFZLENBQUNpQyxTQUFiLENBQXVCTyxDQUF2QixFQUEwQkMsTUFBMUIsQ0FBaUMsQ0FBakMsQ0FBRCxDQUFQO0FBQ0FySCx5QkFBTyxDQUFDNEUsWUFBWSxDQUFDaUMsU0FBYixDQUF1Qk8sQ0FBdkIsRUFBMEJDLE1BQTFCLENBQWlDLENBQWpDLENBQUQsQ0FBUDtBQUNBbkgseUJBQU8sQ0FBQzBFLFlBQVksQ0FBQ2lDLFNBQWIsQ0FBdUJPLENBQXZCLEVBQTBCQyxNQUExQixDQUFpQyxDQUFqQyxDQUFELENBQVA7QUFDQWpILHlCQUFPLENBQUN3RSxZQUFZLENBQUNpQyxTQUFiLENBQXVCTyxDQUF2QixFQUEwQkMsTUFBMUIsQ0FBaUMsQ0FBakMsQ0FBRCxDQUFQO0FBQ0g7O0FBQ0Qsb0JBQUk3TixLQUFLLENBQUNpRCxTQUFOLENBQWdCc0osT0FBaEIsSUFBMkJILFNBQS9CLEVBQTBDbEgsT0FBTyxDQUFDa0csWUFBWSxDQUFDaUMsU0FBYixDQUF1Qk8sQ0FBdkIsRUFBMEJFLFVBQTNCLENBQVA7QUFDMUN0SSwrQkFBZSxDQUFDLElBQUQsQ0FBZjtBQUNBNUUsZ0NBQWdCLENBQUN3SyxZQUFZLENBQUNpQyxTQUFiLENBQXVCTyxDQUF2QixFQUEwQkQsS0FBMUIsQ0FBZ0NJLEtBQWhDLENBQXNDUCxJQUF2QyxDQUFoQjtBQUNBMU0sZ0NBQWdCLENBQUNzSyxZQUFZLENBQUNpQyxTQUFiLENBQXVCTyxDQUF2QixFQUEwQkQsS0FBMUIsQ0FBZ0NILElBQWpDLENBQWhCO0FBQ0ExTCx3Q0FBd0IsQ0FBQ3NKLFlBQVksQ0FBQ2lDLFNBQWIsQ0FBdUJPLENBQXZCLEVBQTBCRCxLQUExQixDQUFnQ0ksS0FBaEMsQ0FBc0NQLElBQXZDLENBQXhCO0FBQ0E1TCx3Q0FBd0IsQ0FBQ3dKLFlBQVksQ0FBQ2lDLFNBQWIsQ0FBdUJPLENBQXZCLEVBQTBCRCxLQUExQixDQUFnQ0gsSUFBakMsQ0FBeEI7QUFDSDtBQXJCTDs7QUFzQkE5QixvQkFBUSxDQUFDLElBQUQsQ0FBUjtBQUNIO0FBQ0o7QUFDSjtBQUNKLEtBckRXLFdBc0RMLFVBQUFDLEdBQUcsRUFBSTtBQUNWQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsR0FBWjtBQUNILEtBeERXLENBQWhCLENBRm9CLENBMkRwQjs7QUFDQUcsY0FBVSxDQUFDO0FBQUEsYUFBTXRCLGVBQWUsQ0FBQ3VCLEtBQWhCLEVBQU47QUFBQSxLQUFELEVBQWdDakUsTUFBaEMsQ0FBVjtBQUNILEdBN0REOztBQThEQSxNQUFNNEQsUUFBUSxHQUFHLFNBQVhBLFFBQVcsQ0FBQ3NDLE1BQUQsRUFBWTtBQUN6QixRQUFJQSxNQUFKLEVBQVk7QUFDUnROLG9CQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0gsS0FGRCxNQUVPQSxjQUFjLENBQUMsSUFBRCxDQUFkO0FBQ1YsR0FKRDs7QUFLQSxNQUFNNEosY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixDQUFDNUIsRUFBRCxFQUFRO0FBQzNCLFFBQUl1RixDQUFDLEdBQUcsRUFBUjtBQUNBLFFBQUl2RixFQUFFLElBQUksRUFBVixFQUNJdUYsQ0FBQyxHQUFHLEVBQUosQ0FESixLQUVLQSxDQUFDLEdBQUcsZUFBZXZGLEVBQW5CO0FBQ0wsUUFBTThCLGVBQWUsR0FBRyxJQUFJQyxlQUFKLEVBQXhCO0FBQ0EsUUFBTUMsT0FBTyxHQUFHQyxNQUFNLENBQ2pCQyxLQURXLENBQ0w1QyxHQUFHLEdBQUcsY0FBTixHQUF1QmlHLENBRGxCLEVBQ3FCO0FBQzdCcEQsYUFBTyxFQUFFO0FBQ0wsa0JBQVUsa0JBREw7QUFFTCx3QkFBZ0Isa0JBRlg7QUFHTCxvQkFBWSxPQUhQO0FBR2tCO0FBQ3ZCLHVDQUErQjtBQUoxQixPQURvQjtBQU83QkMsWUFBTSxFQUFFLEtBUHFCO0FBUTdCQyxVQUFJLEVBQUUsTUFSdUI7QUFTN0JDLFlBQU0sRUFBRVIsZUFBZSxDQUFDUTtBQVRLLEtBRHJCLEVBWVhDLElBWlcsQ0FZTixVQUFBQyxHQUFHO0FBQUEsYUFBSUEsR0FBRyxDQUFDQyxJQUFKLEVBQUo7QUFBQSxLQVpHLEVBYVhGLElBYlcsQ0FhTixVQUFBRyxZQUFZLEVBQUk7QUFDbEIsVUFBSUEsWUFBWSxDQUFDQyxPQUFiLElBQXdCLDZCQUE1QixFQUEyRDtBQUN2RG5LLG9CQUFZLENBQUNrSyxZQUFZLENBQUM4QyxNQUFkLENBQVo7O0FBQ0EsWUFBSSxDQUFDM0MsT0FBTyxDQUFDdkwsS0FBSyxDQUFDaUQsU0FBUCxDQUFaLEVBQStCO0FBQzNCLGNBQUlqRCxLQUFLLENBQUNpRCxTQUFOLENBQWdCMUIsV0FBaEIsR0FBOEIsQ0FBbEMsRUFBcUM7QUFDakNILHVCQUFXLENBQUMsQ0FBRCxDQUFYO0FBQ0FFLHVCQUFXLENBQUN0QixLQUFLLENBQUNpRCxTQUFOLENBQWdCMUIsV0FBakIsQ0FBWDtBQUNBWCw0QkFBZ0IsQ0FBQyxFQUFELENBQWhCO0FBQ0FFLDRCQUFnQixDQUFDLEVBQUQsQ0FBaEI7QUFDQW9DLHdCQUFZLGlDQUNMRCxTQURLO0FBRVIxQix5QkFBVyxFQUFFdkIsS0FBSyxDQUFDaUQsU0FBTixDQUFnQjFCLFdBRnJCO0FBR1JGLHNCQUFRLEVBQUUsQ0FIRjtBQUlSbUssd0JBQVUsRUFBRSxFQUpKO0FBS1JySyxzQkFBUSxFQUFFLENBTEY7QUFNUnNLLHdCQUFVLEVBQUU7QUFOSixlQUFaO0FBUUF6SixvQ0FBd0IsQ0FBQyxJQUFELENBQXhCO0FBQ0gsV0FkRCxNQWNPO0FBQ0hWLHVCQUFXLENBQUN0QixLQUFLLENBQUNpRCxTQUFOLENBQWdCNUIsUUFBakIsQ0FBWDtBQUNBUCw0QkFBZ0IsQ0FBQ2QsS0FBSyxDQUFDaUQsU0FBTixDQUFnQnVJLFVBQWpCLENBQWhCO0FBQ0F0SSx3QkFBWSxpQ0FDTEQsU0FESztBQUVSMUIseUJBQVcsRUFBRSxDQUZMO0FBR1JGLHNCQUFRLEVBQUVyQixLQUFLLENBQUNpRCxTQUFOLENBQWdCNUIsUUFIbEI7QUFJUm1LLHdCQUFVLEVBQUV4TCxLQUFLLENBQUNpRCxTQUFOLENBQWdCdUksVUFKcEI7QUFLUnJLLHNCQUFRLEVBQUVuQixLQUFLLENBQUNpRCxTQUFOLENBQWdCOUIsUUFMbEI7QUFNUnNLLHdCQUFVLEVBQUV6TCxLQUFLLENBQUNpRCxTQUFOLENBQWdCd0k7QUFOcEIsZUFBWjtBQVFIOztBQUdEQyxrQkFBUSxDQUFDLElBQUQsQ0FBUjtBQUNIO0FBQ0o7QUFDSixLQWhEVyxXQWlETCxVQUFBQyxHQUFHLEVBQUk7QUFDVkMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLEdBQVo7QUFDSCxLQW5EVyxDQUFoQixDQU4yQixDQTBEM0I7O0FBQ0FHLGNBQVUsQ0FBQztBQUFBLGFBQU10QixlQUFlLENBQUN1QixLQUFoQixFQUFOO0FBQUEsS0FBRCxFQUFnQ2pFLE1BQWhDLENBQVY7QUFDSCxHQTVERDs7QUE2REEsTUFBTXFHLEtBQUssR0FBRyxTQUFSQSxLQUFRLEdBQU07QUFDaEI3SyxvQkFBZ0IsQ0FBQyxFQUFELENBQWhCO0FBQ0FGLGVBQVcsQ0FBQyxFQUFELENBQVg7QUFDQUksWUFBUSxDQUFDLEtBQUQsQ0FBUjtBQUNBZ0MsbUJBQWUsQ0FBQyxLQUFELENBQWY7QUFDQU4sV0FBTyxDQUFDLEVBQUQsQ0FBUDtBQUNBcEMsYUFBUyxDQUFDLEVBQUQsQ0FBVDtBQUNBMEMsbUJBQWUsQ0FBQyxLQUFELENBQWY7QUFDQXRELGFBQVMsQ0FBQyxLQUFELENBQVQ7QUFDQTRCLGVBQVcsQ0FBQyxLQUFELENBQVg7QUFDQUUsb0JBQWdCLENBQUMsT0FBRCxDQUFoQjtBQUNBTSxnQkFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNBRSxxQkFBaUIsQ0FBQyxPQUFELENBQWpCO0FBQ0FOLHdCQUFvQixDQUFDLEtBQUQsQ0FBcEI7QUFDQUUsNkJBQXlCLENBQUMsT0FBRCxDQUF6QjtBQUNBTSxtQkFBZSxDQUFDLEtBQUQsQ0FBZjtBQUNBRSx3QkFBb0IsQ0FBQyxPQUFELENBQXBCO0FBQ0FFLGdCQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0FFLHFCQUFpQixDQUFDLE9BQUQsQ0FBakI7QUFDQTlCLGdCQUFZLGlDQUFLRCxTQUFMO0FBQWdCa0osYUFBTyxFQUFFO0FBQXpCLE9BQVo7QUFDQWpFLFlBQVEsaUNBQ0RELEtBREM7QUFFSnBFLGNBQVEsRUFBRSxLQUZOO0FBR0pRLGVBQVMsRUFBRSxLQUhQO0FBSUpKLHVCQUFpQixFQUFFLEtBSmY7QUFLSlEsa0JBQVksRUFBRSxLQUxWO0FBTUpJLGVBQVMsRUFBRTtBQU5QLE9BQVI7QUFRQTtBQUNILEdBN0JEOztBQThCQSxNQUFNdUosZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDQyxDQUFELEVBQUlqRixLQUFKLEVBQWM7QUFDbEMsUUFBSUEsS0FBSyxJQUFJLElBQWIsRUFBbUI7QUFDZmxFLGFBQU8sQ0FBQyxFQUFELENBQVA7QUFDQXBDLGVBQVMsQ0FBQyxFQUFELENBQVQ7QUFDQXhCLGlCQUFXLENBQUMsQ0FBRCxDQUFYO0FBQ0FSLHNCQUFnQixDQUFDLEVBQUQsQ0FBaEI7QUFDQU0saUJBQVcsQ0FBQyxDQUFELENBQVg7QUFDQVIsc0JBQWdCLENBQUMsRUFBRCxDQUFoQjtBQUNBMEosb0JBQWMsQ0FBQyxFQUFELENBQWQ7QUFDQTZELFdBQUs7QUFDUixLQVRELE1BU087QUFDSCxVQUFJRyxNQUFNLEdBQUcsQ0FBYjs7QUFDQSxXQUFLLElBQUlWLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUc3TSxTQUFTLENBQUM2SSxNQUE5QixFQUFzQ2dFLENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsWUFBSTdNLFNBQVMsQ0FBQzZNLENBQUQsQ0FBVCxDQUFhSixJQUFiLElBQXFCcEUsS0FBekIsRUFBZ0M7QUFDNUJrRixnQkFBTSxHQUFHdk4sU0FBUyxDQUFDNk0sQ0FBRCxDQUFULENBQWFsRixFQUF0QjtBQUNBOUgsMEJBQWdCLENBQUNHLFNBQVMsQ0FBQzZNLENBQUQsQ0FBVCxDQUFhSixJQUFkLENBQWhCO0FBQ0FsRCx3QkFBYyxDQUFDZ0UsTUFBRCxDQUFkO0FBQ0FsTixxQkFBVyxDQUFDa04sTUFBRCxDQUFYO0FBQ0F4TiwwQkFBZ0IsQ0FBQyxFQUFELENBQWhCO0FBQ0FRLHFCQUFXLENBQUMsQ0FBRCxDQUFYO0FBQ0E0QixzQkFBWSxpQ0FBS0QsU0FBTDtBQUFnQjlCLG9CQUFRLEVBQUVtTixNQUExQjtBQUFrQzdDLHNCQUFVLEVBQUUxSyxTQUFTLENBQUM2TSxDQUFELENBQVQsQ0FBYUo7QUFBM0QsYUFBWjtBQUNBO0FBQ3BCOztBQUNvQixjQUFJUSxNQUFNLEdBQUcsQ0FBRU0sTUFBTSxJQUFJLENBQVYsSUFBZWpOLFFBQVEsSUFBSSxDQUE1QixJQUFrQ0UsV0FBVyxJQUFJLENBQWxELEtBQXdEZ0IsSUFBSSxJQUFJLEVBQWhFLElBQXNFSixJQUFJLElBQUksRUFBOUUsSUFBb0ZnQixRQUFRLENBQUN5RyxNQUFULEdBQWtCLENBQXRHLElBQTJHakUsa0JBQXhIO0FBQ0ErRixrQkFBUSxDQUFDc0MsTUFBRCxDQUFSO0FBRUg7QUFDSjtBQUNKO0FBRUosR0E5QkQ7O0FBK0JBLE1BQU1PLGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0YsQ0FBRCxFQUFJakYsS0FBSixFQUFjO0FBQ2xDLFFBQUlvRixNQUFNLEdBQUcsQ0FBYjtBQUNBLFFBQUlDLE1BQU0sR0FBRyxFQUFiO0FBQ0EsUUFBSUgsTUFBTSxHQUFHLENBQWI7QUFDQSxRQUFJSSxXQUFXLEdBQUcsRUFBbEI7O0FBQ0EsUUFBSXRGLEtBQUssSUFBSSxJQUFiLEVBQW1CO0FBQ2ZsRSxhQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0FwQyxlQUFTLENBQUMsRUFBRCxDQUFUO0FBQ0F4QixpQkFBVyxDQUFDLENBQUQsQ0FBWDtBQUNBUixzQkFBZ0IsQ0FBQyxFQUFELENBQWhCO0FBQ0E7QUFDWjs7QUFDWXFOLFdBQUs7QUFDUixLQVJELE1BUU87QUFDSCxXQUFLLElBQUlQLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUczTSxTQUFTLENBQUMySSxNQUE5QixFQUFzQ2dFLENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsWUFBSTNNLFNBQVMsQ0FBQzJNLENBQUQsQ0FBVCxDQUFhSixJQUFiLElBQXFCcEUsS0FBekIsRUFBZ0M7QUFDNUJvRixnQkFBTSxHQUFHdk4sU0FBUyxDQUFDMk0sQ0FBRCxDQUFULENBQWFsRixFQUF0QjtBQUNBNUgsMEJBQWdCLENBQUNHLFNBQVMsQ0FBQzJNLENBQUQsQ0FBVCxDQUFhSixJQUFkLENBQWhCO0FBQ0FsTSxxQkFBVyxDQUFDa04sTUFBRCxDQUFYO0FBQ0FDLGdCQUFNLEdBQUd4TixTQUFTLENBQUMyTSxDQUFELENBQVQsQ0FBYUosSUFBdEI7QUFDQWMsZ0JBQU0sR0FBR3JOLFNBQVMsQ0FBQzJNLENBQUQsQ0FBVCxDQUFhZSxRQUF0QjtBQUNBdk4scUJBQVcsQ0FBQ0gsU0FBUyxDQUFDMk0sQ0FBRCxDQUFULENBQWFlLFFBQWQsQ0FBWDs7QUFDQSxlQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUc3TixTQUFTLENBQUM2SSxNQUE5QixFQUFzQ2dGLENBQUMsRUFBdkM7QUFDSSxnQkFBSTNOLFNBQVMsQ0FBQzJNLENBQUQsQ0FBVCxDQUFhZSxRQUFiLElBQXlCNU4sU0FBUyxDQUFDNk4sQ0FBRCxDQUFULENBQWFsRyxFQUExQyxFQUE4QztBQUMxQzlILDhCQUFnQixDQUFDRyxTQUFTLENBQUM2TixDQUFELENBQVQsQ0FBYXBCLElBQWQsQ0FBaEI7QUFDQWtCLHlCQUFXLEdBQUczTixTQUFTLENBQUM2TixDQUFELENBQVQsQ0FBYXBCLElBQTNCO0FBQ0g7QUFKTCxXQVA0QixDQVk1Qjs7O0FBQ0EsY0FBSXJLLFFBQVEsQ0FBQ3lHLE1BQVQsR0FBa0IsQ0FBdEIsRUFDSXNDLGNBQWMsQ0FBQy9JLFFBQUQsRUFBV3FMLE1BQVgsQ0FBZDtBQUNQO0FBQ0o7QUFDSjs7QUFDRCxRQUFJRSxXQUFXLElBQUksRUFBbkIsRUFDSXhMLFlBQVksaUNBQUtELFNBQUw7QUFBZ0IxQixpQkFBVyxFQUFFLENBQTdCO0FBQWdDRixjQUFRLEVBQUVtTixNQUExQztBQUFrRGhELGdCQUFVLEVBQUVpRDtBQUE5RCxPQUFaLENBREosS0FFS3ZMLFlBQVksaUNBQ1ZELFNBRFU7QUFFYjFCLGlCQUFXLEVBQUUsQ0FGQTtBQUdiRixjQUFRLEVBQUVtTixNQUhHO0FBSWJoRCxnQkFBVSxFQUFFaUQsTUFKQztBQUtidE4sY0FBUSxFQUFFbU4sTUFMRztBQU1iN0MsZ0JBQVUsRUFBRWlEO0FBTkMsT0FBWjtBQVFMLFFBQUlWLE1BQU0sR0FBRyxDQUFFN00sUUFBUSxJQUFJLENBQVosSUFBaUJxTixNQUFNLElBQUksQ0FBNUIsSUFBa0NqTixXQUFXLElBQUksQ0FBbEQsS0FBd0RnQixJQUFJLElBQUksRUFBaEUsSUFBc0VKLElBQUksSUFBSSxFQUE5RSxJQUFvRmdCLFFBQVEsQ0FBQ3lHLE1BQVQsR0FBa0IsQ0FBdEcsSUFBMkdqRSxrQkFBeEg7QUFDQStGLFlBQVEsQ0FBQ3NDLE1BQUQsQ0FBUjtBQUNILEdBN0NEOztBQThDQSxNQUFNYSxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNSLENBQUQsRUFBSWpGLEtBQUosRUFBYztBQUNyQyxRQUFJMEYsU0FBUyxHQUFHLENBQWhCO0FBQ0EsUUFBSUMsY0FBYyxHQUFHLEVBQXJCO0FBQ0EsUUFBSUMsT0FBTyxHQUFHLEVBQWQ7QUFDQSxRQUFJQyxLQUFLLEdBQUcsRUFBWjtBQUNBLFFBQUlULE1BQU0sR0FBRyxFQUFiO0FBQ0F0SixXQUFPLENBQUMsRUFBRCxDQUFQO0FBQ0FwQyxhQUFTLENBQUMsRUFBRCxDQUFUO0FBQ0F0QixrQkFBYyxDQUFDLENBQUQsQ0FBZDtBQUNBRSx1QkFBbUIsQ0FBQyxFQUFELENBQW5COztBQUNBLFFBQUkwSCxLQUFLLElBQUksSUFBYixFQUFtQjtBQUNmbEUsYUFBTyxDQUFDLEVBQUQsQ0FBUDtBQUNBcEMsZUFBUyxDQUFDLEVBQUQsQ0FBVDtBQUNBdEIsb0JBQWMsQ0FBQyxDQUFELENBQWQ7QUFDQTJNLFdBQUs7QUFDUixLQUxELE1BS087QUFDSCxXQUFLLElBQUlQLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdqSyxVQUFVLENBQUNpRyxNQUEvQixFQUF1Q2dFLENBQUMsRUFBeEMsRUFBNEM7QUFDeEMsWUFBSXhFLEtBQUssSUFBSSxJQUFULElBQWlCekYsVUFBVSxDQUFDaUssQ0FBRCxDQUFWLENBQWNELEtBQWQsQ0FBb0JILElBQXBCLElBQTRCcEUsS0FBakQsRUFBd0Q7QUFDcEQwRixtQkFBUyxHQUFHbkwsVUFBVSxDQUFDaUssQ0FBRCxDQUFWLENBQWNsRixFQUExQjtBQUNBc0csaUJBQU8sR0FBR3JMLFVBQVUsQ0FBQ2lLLENBQUQsQ0FBVixDQUFjQyxNQUF4QjtBQUNBVyxnQkFBTSxHQUFHN0ssVUFBVSxDQUFDaUssQ0FBRCxDQUFWLENBQWNzQixZQUF2QjtBQUNBRCxlQUFLLEdBQUd0TCxVQUFVLENBQUNpSyxDQUFELENBQVYsQ0FBY0UsVUFBdEI7QUFDQTVJLGlCQUFPLENBQUN2QixVQUFVLENBQUNpSyxDQUFELENBQVYsQ0FBY0UsVUFBZixDQUFQO0FBQ0FwTSw2QkFBbUIsQ0FBQ2lDLFVBQVUsQ0FBQ2lLLENBQUQsQ0FBVixDQUFjRCxLQUFkLENBQW9CSCxJQUFyQixDQUFuQjtBQUNBMUwsa0NBQXdCLENBQUM2QixVQUFVLENBQUNpSyxDQUFELENBQVYsQ0FBY0QsS0FBZCxDQUFvQixPQUFwQixFQUE2QkgsSUFBOUIsQ0FBeEI7QUFDQTVMLGtDQUF3QixDQUFDK0IsVUFBVSxDQUFDaUssQ0FBRCxDQUFWLENBQWNELEtBQWQsQ0FBb0JILElBQXJCLENBQXhCO0FBQ0ExSyxtQkFBUyxDQUFDa00sT0FBRCxDQUFUO0FBQ0FwRCxpQkFBTyxDQUFDQyxHQUFSLENBQVltRCxPQUFaO0FBQ0EsY0FBR0EsT0FBTyxJQUFFLEVBQVosRUFDQWxKLE9BQU8sQ0FBQ2tKLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUNBaEosaUJBQU8sQ0FBQ2dKLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUNBOUksaUJBQU8sQ0FBQzhJLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUNBNUksaUJBQU8sQ0FBQzRJLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUNBMUksaUJBQU8sQ0FBQzBJLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUNBeEksaUJBQU8sQ0FBQ3dJLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUNBdEksaUJBQU8sQ0FBQ3NJLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUNBcEksaUJBQU8sQ0FBQ29JLE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUDtBQUVBeEoseUJBQWUsQ0FBQyxJQUFELENBQWY7QUFDQXRDLHNCQUFZLGlDQUFLRCxTQUFMO0FBQWdCMUIsdUJBQVcsRUFBRSxDQUE3QjtBQUFnQ0Ysb0JBQVEsRUFBRW1OO0FBQTFDLGFBQVo7QUFDQSxjQUFJckwsUUFBUSxDQUFDeUcsTUFBVCxHQUFrQixDQUF0QixFQUNJc0MsY0FBYyxDQUFDL0ksUUFBRCxFQUFXcUwsTUFBWCxDQUFkO0FBQ1A7QUFFSjtBQUNKOztBQUNELFFBQUlNLFNBQVMsSUFBSSxDQUFqQixFQUFvQjtBQUNoQjFOLGlCQUFXLENBQUMsQ0FBRCxDQUFYO0FBQ0FFLGlCQUFXLENBQUMsQ0FBRCxDQUFYO0FBQ0FWLHNCQUFnQixDQUFDLEVBQUQsQ0FBaEI7QUFDQUUsc0JBQWdCLENBQUMsRUFBRCxDQUFoQjtBQUNBa0IsOEJBQXdCLENBQUMsSUFBRCxDQUF4QjtBQUNILEtBTkQsTUFNT0Esd0JBQXdCLENBQUMsS0FBRCxDQUF4Qjs7QUFDUFIsa0JBQWMsQ0FBQ3NOLFNBQUQsQ0FBZDtBQUNBeE4sZUFBVyxDQUFDa04sTUFBRCxDQUFYO0FBQ0F0TCxnQkFBWSxpQ0FBS0QsU0FBTDtBQUFnQjFCLGlCQUFXLEVBQUV1TixTQUE3QjtBQUF3Q3pOLGNBQVEsRUFBRW1OO0FBQWxELE9BQVo7QUFDQSxRQUFJUixNQUFNLEdBQUcsQ0FBRTdNLFFBQVEsSUFBSSxDQUFaLElBQWlCRSxRQUFRLElBQUksQ0FBOUIsSUFBb0N5TixTQUFTLElBQUksQ0FBbEQsS0FBd0R2TSxJQUFJLElBQUksRUFBaEUsSUFBc0VKLElBQUksSUFBSSxFQUE5RSxJQUFvRmdCLFFBQVEsQ0FBQ3lHLE1BQVQsR0FBa0IsQ0FBdEcsSUFBMkdqRSxrQkFBeEg7QUFDQStGLFlBQVEsQ0FBQ3NDLE1BQUQsQ0FBUjtBQUNILEdBMUREOztBQTJEQSxNQUFNbUIsV0FBVyxHQUFHLFNBQWRBLFdBQWMsQ0FBQ2QsQ0FBRCxFQUFPO0FBQ3ZCakwsZUFBVyxDQUFDLEVBQUQsQ0FBWDtBQUNBRSxvQkFBZ0IsQ0FBQyxFQUFELENBQWhCO0FBQ0FFLFlBQVEsQ0FBQyxLQUFELENBQVI7QUFDQW9JLFdBQU8sQ0FBQ0MsR0FBUixDQUFZd0MsQ0FBQyxDQUFDekYsTUFBRixDQUFTUSxLQUFyQjs7QUFDQSxRQUFJaUYsQ0FBQyxDQUFDekYsTUFBRixDQUFTUSxLQUFULElBQWtCLEtBQXRCLEVBQTZCO0FBQ3pCbEgsZUFBUyxDQUFDLElBQUQsQ0FBVDtBQUNBNEIsaUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDQUUsc0JBQWdCLENBQUMsT0FBRCxDQUFoQjtBQUNBTSxrQkFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNBRSx1QkFBaUIsQ0FBQyxnQkFBRCxDQUFqQjtBQUNBTiwwQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ0FFLCtCQUF5QixDQUFDLGdCQUFELENBQXpCO0FBQ0FNLHFCQUFlLENBQUMsS0FBRCxDQUFmO0FBQ0FFLDBCQUFvQixDQUFDLGdCQUFELENBQXBCO0FBQ0FFLGtCQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0FFLHVCQUFpQixDQUFDLE9BQUQsQ0FBakI7QUFDQTlCLGtCQUFZLGlDQUFLRCxTQUFMO0FBQWdCa0osZUFBTyxFQUFFO0FBQXpCLFNBQVo7QUFDQWpFLGNBQVEsaUNBQ0RELEtBREM7QUFFSnBFLGdCQUFRLEVBQUUsS0FGTjtBQUdKUSxpQkFBUyxFQUFFLEtBSFA7QUFJSkoseUJBQWlCLEVBQUUsS0FKZjtBQUtKUSxvQkFBWSxFQUFFLEtBTFY7QUFNSkksaUJBQVMsRUFBRTtBQU5QLFNBQVIsQ0FieUIsQ0FxQnpCOztBQUNBN0Isa0JBQVksQ0FBQyxJQUFELENBQVo7QUFDSCxLQXZCRCxNQXVCTyxJQUFJcUwsQ0FBQyxDQUFDekYsTUFBRixDQUFTUSxLQUFULElBQWtCLEtBQXRCLEVBQTZCO0FBQ2hDNUQscUJBQWUsQ0FBQyxLQUFELENBQWY7QUFDQXRELGVBQVMsQ0FBQyxLQUFELENBQVQ7QUFDQTRCLGlCQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0FFLHNCQUFnQixDQUFDLE9BQUQsQ0FBaEI7QUFDQU0sa0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQUUsdUJBQWlCLENBQUMsT0FBRCxDQUFqQjtBQUNBTiwwQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ0FFLCtCQUF5QixDQUFDLE9BQUQsQ0FBekI7QUFDQU0scUJBQWUsQ0FBQyxLQUFELENBQWY7QUFDQUUsMEJBQW9CLENBQUMsT0FBRCxDQUFwQjtBQUNBRSxrQkFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNBRSx1QkFBaUIsQ0FBQyxPQUFELENBQWpCO0FBQ0E5QixrQkFBWSxpQ0FBS0QsU0FBTDtBQUFnQmtKLGVBQU8sRUFBRTtBQUF6QixTQUFaO0FBQ0FqRSxjQUFRLGlDQUNERCxLQURDO0FBRUpwRSxnQkFBUSxFQUFFLEtBRk47QUFHSlEsaUJBQVMsRUFBRSxLQUhQO0FBSUpKLHlCQUFpQixFQUFFLEtBSmY7QUFLSlEsb0JBQVksRUFBRSxLQUxWO0FBTUpJLGlCQUFTLEVBQUU7QUFOUCxTQUFSO0FBUUg7QUFDSixHQW5ERDs7QUFvREEsTUFBTXVLLGdCQUFnQixHQUFHLFNBQW5CQSxnQkFBbUIsQ0FBQ2hHLEtBQUQsRUFBVztBQUNoQ2hHLGVBQVcsQ0FBQyxFQUFELENBQVg7QUFDQUUsb0JBQWdCLENBQUMsRUFBRCxDQUFoQjtBQUNBRSxZQUFRLENBQUMsS0FBRCxDQUFSO0FBRUFnQyxtQkFBZSxDQUFDLEtBQUQsQ0FBZjtBQUNBdEQsYUFBUyxDQUFDLEtBQUQsQ0FBVDtBQUNBNEIsZUFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNBRSxvQkFBZ0IsQ0FBQyxPQUFELENBQWhCO0FBQ0FNLGdCQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0FFLHFCQUFpQixDQUFDLE9BQUQsQ0FBakI7QUFDQU4sd0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNBRSw2QkFBeUIsQ0FBQyxPQUFELENBQXpCO0FBQ0FNLG1CQUFlLENBQUMsS0FBRCxDQUFmO0FBQ0FFLHdCQUFvQixDQUFDLE9BQUQsQ0FBcEI7QUFDQUUsZ0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQUUscUJBQWlCLENBQUMsT0FBRCxDQUFqQjtBQUNBOUIsZ0JBQVksaUNBQUtELFNBQUw7QUFBZ0JrSixhQUFPLEVBQUU7QUFBekIsT0FBWjtBQUNBakUsWUFBUSxpQ0FDREQsS0FEQztBQUVKcEUsY0FBUSxFQUFFLEtBRk47QUFHSlEsZUFBUyxFQUFFLEtBSFA7QUFJSkosdUJBQWlCLEVBQUUsS0FKZjtBQUtKUSxrQkFBWSxFQUFFLEtBTFY7QUFNSkksZUFBUyxFQUFFO0FBTlAsT0FBUjtBQVNILEdBM0JEOztBQTZCQSxXQUFTd0ssY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkJsRyxLQUE3QixFQUFvQztBQUNoQyxRQUFJZ0IsS0FBSyxHQUFHa0YsR0FBRyxDQUFDQyxPQUFKLENBQVluRyxLQUFaLENBQVo7O0FBQ0EsUUFBSWdCLEtBQUssR0FBRyxDQUFDLENBQWIsRUFBZ0I7QUFDWmtGLFNBQUcsQ0FBQ0UsTUFBSixDQUFXcEYsS0FBWCxFQUFrQixDQUFsQjtBQUNIOztBQUNELFdBQU9rRixHQUFQO0FBQ0g7O0FBRUQsTUFBTUcsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDaEgsS0FBRCxFQUFXO0FBQy9CLFFBQUlpSCxTQUFTLG1DQUFPekgsS0FBUCw4SUFBZVEsS0FBSyxDQUFDRyxNQUFOLENBQWE0RSxJQUE1QixFQUFtQy9FLEtBQUssQ0FBQ0csTUFBTixDQUFhK0csT0FBaEQsRUFBYjs7QUFDQSxRQUFJQyxpQkFBaUIsR0FBRyxFQUF4QjtBQUNBLFFBQUlDLHNCQUFzQixHQUFHLEVBQTdCOztBQUNBLFFBQUlDLFNBQUosRUFBZUMsVUFBZixFQUEyQkMsa0JBQTNCLEVBQStDQyxVQUEvQyxFQUEyREMsYUFBM0Q7O0FBQ0EsUUFBSVIsU0FBUyxDQUFDLFVBQUQsQ0FBYixFQUEyQjtBQUN2QjVMLGlCQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0FFLHNCQUFnQixDQUFDLE1BQUQsQ0FBaEI7O0FBQ0E0TCx1QkFBaUIsQ0FBQ25DLElBQWxCLENBQXVCLENBQXZCOztBQUNBb0MsNEJBQXNCLENBQUNwQyxJQUF2QixDQUE0QixRQUE1Qjs7QUFDQXFDLGVBQVMsR0FBRyxJQUFaO0FBQ0FFLHdCQUFrQixHQUFHLEtBQXJCO0FBQ0E5TCwwQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ0EsVUFBSWpDLE1BQUosRUFDSW1DLHlCQUF5QixDQUFDLGdCQUFELENBQXpCLENBREosS0FFS0EseUJBQXlCLENBQUMsT0FBRCxDQUF6QjtBQUNSLEtBWEQsTUFXTztBQUNIaUwsb0JBQWMsQ0FBQ08saUJBQUQsRUFBb0IsQ0FBcEIsQ0FBZDtBQUNBUCxvQkFBYyxDQUFDUSxzQkFBRCxFQUF5QixRQUF6QixDQUFkO0FBQ0EvTCxpQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNBRSxzQkFBZ0IsQ0FBQyxPQUFELENBQWhCO0FBQ0FFLDBCQUFvQixDQUFDLEtBQUQsQ0FBcEI7QUFDQSxVQUFJakMsTUFBSixFQUNJbUMseUJBQXlCLENBQUMsZ0JBQUQsQ0FBekIsQ0FESixLQUVLO0FBQ0RBLGlDQUF5QixDQUFDLE9BQUQsQ0FBekI7QUFDSDtBQUNEMEwsZUFBUyxHQUFHLEtBQVo7QUFDSDs7QUFDRCxRQUFJSixTQUFTLENBQUMsV0FBRCxDQUFiLEVBQTRCO0FBQ3hCcEwsa0JBQVksQ0FBQyxJQUFELENBQVo7QUFDQUUsdUJBQWlCLENBQUMsTUFBRCxDQUFqQjs7QUFDQW9MLHVCQUFpQixDQUFDbkMsSUFBbEIsQ0FBdUIsQ0FBdkI7O0FBQ0FvQyw0QkFBc0IsQ0FBQ3BDLElBQXZCLENBQTRCLFFBQTVCOztBQUNBc0MsZ0JBQVUsR0FBRyxJQUFiO0FBQ0FDLHdCQUFrQixHQUFHLEtBQXJCO0FBQ0E5TCwwQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ0FFLCtCQUF5QixDQUFDLGdCQUFELENBQXpCO0FBQ0gsS0FURCxNQVNPO0FBQ0hpTCxvQkFBYyxDQUFDTyxpQkFBRCxFQUFvQixDQUFwQixDQUFkO0FBQ0FQLG9CQUFjLENBQUNRLHNCQUFELEVBQXlCLFFBQXpCLENBQWQ7O0FBQ0EsVUFBSSxDQUFDNU4sTUFBTCxFQUFhO0FBQ1RxQyxvQkFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNBRSx5QkFBaUIsQ0FBQyxPQUFELENBQWpCO0FBQ0FOLDRCQUFvQixDQUFDLEtBQUQsQ0FBcEI7QUFDQSxZQUFJakMsTUFBSixFQUNJbUMseUJBQXlCLENBQUMsZ0JBQUQsQ0FBekIsQ0FESixLQUVLQSx5QkFBeUIsQ0FBQyxPQUFELENBQXpCO0FBQ0wyTCxrQkFBVSxHQUFHLEtBQWI7QUFDSCxPQVJELE1BUU87QUFDSHpMLG9CQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0FFLHlCQUFpQixDQUFDLGdCQUFELENBQWpCO0FBQ0FOLDRCQUFvQixDQUFDLEtBQUQsQ0FBcEI7QUFDQSxZQUFJakMsTUFBSixFQUNJbUMseUJBQXlCLENBQUMsZ0JBQUQsQ0FBekIsQ0FESixLQUVLQSx5QkFBeUIsQ0FBQyxPQUFELENBQXpCO0FBQ0wyTCxrQkFBVSxHQUFHLEtBQWI7QUFDSDtBQUVKOztBQUNELFFBQUlMLFNBQVMsQ0FBQyxtQkFBRCxDQUFiLEVBQW9DO0FBQ2hDRSx1QkFBaUIsQ0FBQ25DLElBQWxCLENBQXVCLENBQXZCOztBQUNBb0MsNEJBQXNCLENBQUNwQyxJQUF2QixDQUE0QixlQUE1Qjs7QUFDQXZKLDBCQUFvQixDQUFDLElBQUQsQ0FBcEI7QUFDQUUsK0JBQXlCLENBQUMsTUFBRCxDQUF6QjtBQUNBTixpQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNBRSxzQkFBZ0IsQ0FBQyxnQkFBRCxDQUFoQjtBQUNBTSxrQkFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNBRSx1QkFBaUIsQ0FBQyxnQkFBRCxDQUFqQjtBQUNBd0wsd0JBQWtCLEdBQUcsSUFBckI7QUFDQUYsZUFBUyxHQUFHLEtBQVo7QUFDQUMsZ0JBQVUsR0FBRyxLQUFiO0FBQ0FWLG9CQUFjLENBQUNPLGlCQUFELEVBQW9CLENBQXBCLENBQWQ7QUFDQVAsb0JBQWMsQ0FBQ08saUJBQUQsRUFBb0IsQ0FBcEIsQ0FBZDtBQUNBUCxvQkFBYyxDQUFDUSxzQkFBRCxFQUF5QixRQUF6QixDQUFkO0FBQ0FSLG9CQUFjLENBQUNRLHNCQUFELEVBQXlCLFFBQXpCLENBQWQ7QUFDSCxLQWhCRCxNQWdCTztBQUNIM0wsMEJBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNBLFVBQUl3TCxTQUFTLENBQUMsVUFBRCxDQUFULElBQXlCQSxTQUFTLENBQUMsV0FBRCxDQUF0QyxFQUNJdEwseUJBQXlCLENBQUMsZ0JBQUQsQ0FBekIsQ0FESixLQUVLLElBQUluQyxNQUFKLEVBQ0RtQyx5QkFBeUIsQ0FBQyxnQkFBRCxDQUF6QixDQURDLEtBRUFBLHlCQUF5QixDQUFDLE9BQUQsQ0FBekI7O0FBQ0wsVUFBSSxDQUFDc0wsU0FBUyxDQUFDLFVBQUQsQ0FBZCxFQUE0QjtBQUN4QjVMLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0EsWUFBSTdCLE1BQUosRUFDSStCLGdCQUFnQixDQUFDLE9BQUQsQ0FBaEI7QUFDSjhMLGlCQUFTLEdBQUcsS0FBWjtBQUNBVCxzQkFBYyxDQUFDTyxpQkFBRCxFQUFvQixDQUFwQixDQUFkO0FBQ0FQLHNCQUFjLENBQUNRLHNCQUFELEVBQXlCLFFBQXpCLENBQWQ7QUFDSDs7QUFDRCxVQUFJLENBQUNILFNBQVMsQ0FBQyxXQUFELENBQWQsRUFBNkI7QUFDekIsWUFBSXpOLE1BQUosRUFDSXVDLGlCQUFpQixDQUFDLGdCQUFELENBQWpCLENBREosS0FHSUEsaUJBQWlCLENBQUMsT0FBRCxDQUFqQjtBQUNKRixvQkFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNBeUwsa0JBQVUsR0FBRyxLQUFiO0FBQ0FWLHNCQUFjLENBQUNPLGlCQUFELEVBQW9CLENBQXBCLENBQWQ7QUFDQVAsc0JBQWMsQ0FBQ1Esc0JBQUQsRUFBeUIsUUFBekIsQ0FBZDtBQUNIOztBQUNEUixvQkFBYyxDQUFDTyxpQkFBRCxFQUFvQixDQUFwQixDQUFkO0FBQ0FQLG9CQUFjLENBQUNRLHNCQUFELEVBQXlCLGVBQXpCLENBQWQ7QUFDQUcsd0JBQWtCLEdBQUcsS0FBckI7QUFDSDs7QUFDRCxRQUFJTixTQUFTLENBQUMsV0FBRCxDQUFiLEVBQTRCO0FBQ3hCNUssa0JBQVksQ0FBQyxJQUFELENBQVo7QUFDQUUsdUJBQWlCLENBQUMsTUFBRCxDQUFqQjs7QUFDQTRLLHVCQUFpQixDQUFDbkMsSUFBbEIsQ0FBdUIsQ0FBdkI7O0FBQ0FvQyw0QkFBc0IsQ0FBQ3BDLElBQXZCLENBQTRCLGFBQTVCOztBQUNBd0MsZ0JBQVUsR0FBRyxJQUFiO0FBQ0gsS0FORCxNQU1PO0FBQ0haLG9CQUFjLENBQUNPLGlCQUFELEVBQW9CLENBQXBCLENBQWQ7QUFDQVAsb0JBQWMsQ0FBQ1Esc0JBQUQsRUFBeUIsYUFBekIsQ0FBZDtBQUNBL0ssa0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQUUsdUJBQWlCLENBQUMsT0FBRCxDQUFqQjtBQUNBaUwsZ0JBQVUsR0FBRyxLQUFiO0FBQ0g7O0FBQ0QsUUFBSVAsU0FBUyxDQUFDLGNBQUQsQ0FBYixFQUErQjtBQUMzQmhMLHFCQUFlLENBQUMsSUFBRCxDQUFmO0FBQ0FFLDBCQUFvQixDQUFDLE1BQUQsQ0FBcEI7O0FBQ0FnTCx1QkFBaUIsQ0FBQ25DLElBQWxCLENBQXVCLENBQXZCOztBQUNBb0MsNEJBQXNCLENBQUNwQyxJQUF2QixDQUE0QixjQUE1Qjs7QUFDQXlDLG1CQUFhLEdBQUcsSUFBaEI7QUFDSCxLQU5ELE1BTU87QUFDSGIsb0JBQWMsQ0FBQ08saUJBQUQsRUFBb0IsQ0FBcEIsQ0FBZDtBQUNBUCxvQkFBYyxDQUFDUSxzQkFBRCxFQUF5QixjQUF6QixDQUFkO0FBQ0FuTCxxQkFBZSxDQUFDLEtBQUQsQ0FBZjtBQUNBLFVBQUl6QyxNQUFKLEVBQ0kyQyxvQkFBb0IsQ0FBQyxnQkFBRCxDQUFwQixDQURKLEtBRUtBLG9CQUFvQixDQUFDLE9BQUQsQ0FBcEI7QUFDTHNMLG1CQUFhLEdBQUcsS0FBaEI7QUFDSDs7QUFDRDVNLG9CQUFnQixDQUFDdU0sc0JBQUQsQ0FBaEI7QUFDQXpNLGVBQVcsQ0FBQ3dNLGlCQUFELENBQVg7QUFDQTFNLGdCQUFZLGlDQUFLRCxTQUFMO0FBQWdCRSxjQUFRLEVBQUV5TSxpQkFBMUI7QUFBNkN2TSxtQkFBYSxFQUFFd007QUFBNUQsT0FBWjtBQUNBM0gsWUFBUSxpQ0FDREQsS0FEQztBQUVKcEUsY0FBUSxFQUFFaU0sU0FGTjtBQUdKekwsZUFBUyxFQUFFMEwsVUFIUDtBQUlKOUwsdUJBQWlCLEVBQUUrTCxrQkFKZjtBQUtKdkwsa0JBQVksRUFBRXlMLGFBTFY7QUFNSnJMLGVBQVMsRUFBRW9MO0FBTlAsT0FBUjtBQVFBL0Qsa0JBQWMsQ0FBQzBELGlCQUFELEVBQW9Cdk8sUUFBcEIsQ0FBZDtBQUNBdUUseUJBQXFCLENBQUNrSyxTQUFTLElBQUlDLFVBQWQsQ0FBckI7QUFDQSxRQUFJL0IsTUFBTSxHQUFHLENBQUU3TSxRQUFRLElBQUksQ0FBWixJQUFpQkUsUUFBUSxJQUFJLENBQTlCLElBQW9DRSxXQUFXLElBQUksQ0FBcEQsS0FBMERnQixJQUFJLElBQUksRUFBbEUsSUFBd0VKLElBQUksSUFBSSxFQUFoRixJQUF1RnlOLGlCQUFpQixDQUFDaEcsTUFBbEIsR0FBMkIsQ0FBM0IsS0FBaUNrRyxTQUFTLElBQUlDLFVBQTlDLENBQXBHO0FBQ0FyRSxZQUFRLENBQUNzQyxNQUFELENBQVI7QUFDSCxHQXBKRDs7QUFxSkEsTUFBTW1DLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUMxSCxLQUFELEVBQVc7QUFDM0JyRyxXQUFPLENBQUNxRyxLQUFLLENBQUNHLE1BQU4sQ0FBYVEsS0FBZCxDQUFQO0FBQ0EsUUFBSWdCLEtBQUssR0FBR2YsV0FBVyxDQUFDa0csT0FBWixDQUFvQjlHLEtBQUssQ0FBQ0csTUFBTixDQUFhUSxLQUFqQyxDQUFaOztBQUNBLFlBQVFYLEtBQUssQ0FBQ0csTUFBTixDQUFhUSxLQUFyQjtBQUNJLFdBQUssT0FBTDtBQUNJOUcsa0JBQVUsQ0FBQyxPQUFELENBQVY7QUFDQTs7QUFDSixXQUFLLE9BQUw7QUFDSUEsa0JBQVUsQ0FBQyxPQUFELENBQVY7QUFDQTs7QUFDSixXQUFLLE9BQUw7QUFDSUEsa0JBQVUsQ0FBQyxPQUFELENBQVY7QUFDQTs7QUFDSixXQUFLLE9BQUw7QUFDSUEsa0JBQVUsQ0FBQyxPQUFELENBQVY7QUFDQTs7QUFDSjtBQUNJQSxrQkFBVSxDQUFDK0csV0FBVyxDQUFDZSxLQUFLLEdBQUcsQ0FBVCxDQUFaLENBQVY7QUFkUjs7QUFpQkFsSCxnQkFBWSxpQ0FBS0QsU0FBTDtBQUFnQmQsVUFBSSxFQUFFc0csS0FBSyxDQUFDRyxNQUFOLENBQWFRLEtBQW5DO0FBQTBDNkMsYUFBTyxFQUFFNUMsV0FBVyxDQUFDZSxLQUFLLEdBQUcsQ0FBVCxDQUE5RDtBQUEyRStCLGFBQU8sRUFBRWxLLE1BQU0sR0FBRyxDQUFILEdBQU87QUFBakcsT0FBWjtBQUNBLFFBQUkrTCxNQUFNLEdBQUcsQ0FBRTdNLFFBQVEsSUFBSSxDQUFaLElBQWlCRSxRQUFRLElBQUksQ0FBOUIsSUFBb0NFLFdBQVcsSUFBSSxDQUFwRCxLQUEwRGdCLElBQUksSUFBSSxFQUFsRSxJQUF3RWtHLEtBQUssQ0FBQ0csTUFBTixDQUFhUSxLQUFiLElBQXNCLEVBQTlGLElBQW9HakcsUUFBUSxDQUFDeUcsTUFBVCxHQUFrQixDQUF0SCxJQUEySGpFLGtCQUF4STtBQUNBK0YsWUFBUSxDQUFDc0MsTUFBRCxDQUFSO0FBQ0gsR0F2QkQ7O0FBeUJBLFdBQVNvQyxZQUFULENBQXNCQyxLQUF0QixFQUE2QjtBQUN6QixRQUFJQyxLQUFLLEdBQUdELEtBQUssQ0FBQ0UsSUFBTixHQUFhakUsS0FBYixDQUFtQixHQUFuQixDQUFaO0FBQ0EsUUFBSS9KLElBQUksR0FBRytOLEtBQUssQ0FBQyxDQUFELENBQUwsQ0FBU2hFLEtBQVQsQ0FBZSxHQUFmLENBQVg7QUFDQSxRQUFJbkssSUFBSSxHQUFHLENBQUNtTyxLQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVdBLEtBQUssQ0FBQyxDQUFELENBQWhCLEdBQXNCLFVBQXZCLEVBQW1DaEUsS0FBbkMsQ0FBeUMsR0FBekMsQ0FBWCxDQUh5QixDQUt6Qjs7QUFDQSxRQUFJa0UsQ0FBQyxHQUFHLElBQUkvRyxJQUFKLENBQVNsSCxJQUFJLENBQUMsQ0FBRCxDQUFiLEVBQWtCQSxJQUFJLENBQUMsQ0FBRCxDQUFKLEdBQVUsQ0FBNUIsRUFBK0JBLElBQUksQ0FBQyxDQUFELENBQW5DLEVBQXdDSixJQUFJLENBQUMsQ0FBRCxDQUE1QyxFQUFpREEsSUFBSSxDQUFDLENBQUQsQ0FBckQsRUFBMERBLElBQUksQ0FBQyxDQUFELENBQTlELENBQVI7QUFDQSxXQUFPcU8sQ0FBQyxDQUFDQyxPQUFGLEtBQWMsSUFBckI7QUFDSDs7QUFFRCxNQUFNQyxXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFDdEgsS0FBRCxFQUFXO0FBQzNCLFFBQUl1SCxFQUFFLEdBQUd2SCxLQUFLLENBQUN3SCxNQUFOLENBQWEsbUJBQWIsQ0FBVDs7QUFDQSxRQUFJQyxVQUFVLEdBQUdULFlBQVksQ0FBQ08sRUFBRCxDQUE3QixDQUYyQixDQUczQjs7O0FBRUFuTyxXQUFPLENBQUM0RyxLQUFELENBQVA7QUFDQSxRQUFJbUMsT0FBTyxDQUFDdkwsS0FBSyxDQUFDaUQsU0FBUCxDQUFYLEVBQ0lxRyxZQUFZLENBQUNGLEtBQUQsQ0FBWjtBQUNKMUcsZ0JBQVksQ0FBQ21PLFVBQVUsR0FBRyxJQUFkLENBQVo7QUFDQTNOLGdCQUFZLGlDQUFLRCxTQUFMO0FBQWdCVixVQUFJLEVBQUVzTyxVQUFVLEdBQUc7QUFBbkMsT0FBWjtBQUNBLFFBQUk3QyxNQUFNLEdBQUcsQ0FBRTdNLFFBQVEsSUFBSSxDQUFaLElBQWlCRSxRQUFRLElBQUksQ0FBOUIsSUFBb0NFLFdBQVcsSUFBSSxDQUFwRCxLQUEwRDZILEtBQUssSUFBSSxFQUFuRSxJQUF5RWpILElBQUksSUFBSSxFQUFqRixJQUF1RmdCLFFBQVEsQ0FBQ3lHLE1BQVQsR0FBa0IsQ0FBekcsSUFBOEdqRSxrQkFBM0g7QUFDQStGLFlBQVEsQ0FBQ3NDLE1BQUQsQ0FBUjtBQUNILEdBWkQ7O0FBYUEsTUFBTThDLFdBQVcsR0FBRyxTQUFkQSxXQUFjLEdBQU07QUFDdEIsUUFBSUMsVUFBVSxtQ0FDUDlOLFNBRE87QUFFVkUsY0FBUSxFQUFFQSxRQUZBO0FBR1ZFLG1CQUFhLEVBQUVBLGFBSEw7QUFJVjhJLGFBQU8sRUFBRWxLLE1BQU0sR0FBRyxDQUFILEdBQU8sQ0FKWjtBQUtWRSxVQUFJLEVBQUVBLElBTEk7QUFNVjhKLGFBQU8sRUFBRTVKLE9BTkM7QUFPVmtCLFdBQUssRUFBRUEsS0FQRztBQVFWbEMsY0FBUSxFQUFFQSxRQVJBO0FBU1ZtSyxnQkFBVSxFQUFFakssV0FBVyxHQUFHLENBQWQsR0FBa0JJLHFCQUFsQixHQUEwQ2QsYUFUNUM7QUFVVk0sY0FBUSxFQUFFQSxRQVZBO0FBV1ZzSyxnQkFBVSxFQUFFbEssV0FBVyxHQUFHLENBQWQsR0FBa0JNLHFCQUFsQixHQUEwQ2xCLGFBWDVDO0FBWVZZLGlCQUFXLEVBQUVBLFdBWkg7QUFhVmdCLFVBQUksRUFBRWdKLE9BQU8sQ0FBQ3ZMLEtBQUssQ0FBQ2lELFNBQVAsQ0FBUCxHQUEyQlIsU0FBM0IsR0FBdUN6QyxLQUFLLENBQUNpRCxTQUFOLENBQWdCVixJQUFoQixJQUF3QkUsU0FBeEIsR0FBb0N6QyxLQUFLLENBQUNpRCxTQUFOLENBQWdCVixJQUFwRCxHQUEyREU7QUFiOUYsTUFBZDs7QUFnQkF6QyxTQUFLLENBQUNnUixRQUFOLENBQWUsT0FBZixFQUF3QkQsVUFBeEI7QUFDSCxHQWxCRDs7QUFtQkEsTUFBTUUsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixHQUFNO0FBQ3hCak8sZ0JBQVksQ0FBQyxJQUFELENBQVo7QUFDQXdDLG1CQUFlLENBQUMsS0FBRCxDQUFmO0FBQ0FFLGNBQVUsQ0FBQyxJQUFELENBQVY7QUFDSCxHQUpEOztBQUtBLE1BQU13TCxVQUFVLEdBQUcsU0FBYkEsVUFBYSxHQUFNO0FBQ3JCbE8sZ0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQWQsYUFBUyxDQUFDLEtBQUQsQ0FBVDtBQUNBNEIsZUFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNBRSxvQkFBZ0IsQ0FBQyxPQUFELENBQWhCO0FBQ0FNLGdCQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0FFLHFCQUFpQixDQUFDLE9BQUQsQ0FBakI7QUFDQU4sd0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNBRSw2QkFBeUIsQ0FBQyxPQUFELENBQXpCO0FBQ0FNLG1CQUFlLENBQUMsS0FBRCxDQUFmO0FBQ0FFLHdCQUFvQixDQUFDLE9BQUQsQ0FBcEI7QUFDQUUsZ0JBQVksQ0FBQyxLQUFELENBQVo7QUFDQUUscUJBQWlCLENBQUMsT0FBRCxDQUFqQjtBQUNBOUIsZ0JBQVksaUNBQUtELFNBQUw7QUFBZ0JrSixhQUFPLEVBQUU7QUFBekIsT0FBWjtBQUNBakUsWUFBUSxpQ0FDREQsS0FEQztBQUVKcEUsY0FBUSxFQUFFLEtBRk47QUFHSlEsZUFBUyxFQUFFLEtBSFA7QUFJSkosdUJBQWlCLEVBQUUsS0FKZjtBQUtKUSxrQkFBWSxFQUFFLEtBTFY7QUFNSkksZUFBUyxFQUFFO0FBTlAsT0FBUjtBQVFBVyxtQkFBZSxDQUFDLEtBQUQsQ0FBZjtBQUNILEdBdkJEOztBQXdCQSxNQUFNMkwsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFDOUMsQ0FBRCxFQUFPO0FBQ3pCdkwsYUFBUyxDQUFDdUwsQ0FBQyxDQUFDekYsTUFBRixDQUFTUSxLQUFWLENBQVQsQ0FEeUIsQ0FFekI7QUFDSCxHQUhEOztBQUlBLE1BQU1nSSxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLEdBQU07QUFDekI7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFUSxRQUFJcEksUUFBUSxDQUFDQyxjQUFULENBQXdCLG9CQUF4QixLQUFpRG1ELFNBQXJELEVBQWdFO0FBQzVELFVBQUlpRixLQUFLLEdBQUdySSxRQUFRLENBQUNDLGNBQVQsQ0FBd0Isb0JBQXhCLENBQVo7QUFDQW9JLFdBQUssQ0FBQ0MsTUFBTjtBQUNIOztBQUNEMUYsV0FBTyxDQUFDQyxHQUFSLENBQVk1RyxJQUFaO0FBQ0EyRyxXQUFPLENBQUNDLEdBQVIsQ0FBWWhKLE1BQVo7O0FBQ0EsUUFBSW9DLElBQUksSUFBSSxFQUFSLElBQWNwQyxNQUFNLElBQUksRUFBeEIsSUFBOEJvQyxJQUFJLElBQUksSUFBdEMsSUFBOENwQyxNQUFNLElBQUksSUFBNUQsRUFBa0U7QUFDOURHLGtCQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0EsVUFBSSxDQUFDMEMsVUFBTCxFQUFpQnhELFNBQVMsQ0FBQyxJQUFELENBQVQ7QUFDakJzRCxxQkFBZSxDQUFDLElBQUQsQ0FBZjtBQUNBRSxnQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNILEtBTEQsTUFLTyxJQUFJN0MsTUFBTSxJQUFJLEVBQVYsSUFBZ0JBLE1BQU0sSUFBSSxJQUE5QixFQUFvQ3NFLGdEQUFRLENBQUNDLE1BQVQsQ0FBZ0JtSyxPQUFoQixDQUF3QixtQ0FBeEIsRUFBcEMsS0FDRixJQUFJdE0sSUFBSSxJQUFJLEVBQVIsSUFBY0EsSUFBSSxJQUFJLElBQTFCLEVBQWdDa0MsZ0RBQVEsQ0FBQ0MsTUFBVCxDQUFnQm1LLE9BQWhCLENBQXdCLDBDQUF4QjtBQUV4QyxHQTdCRDs7QUErQkEsTUFBTXJGLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ3NGLGdCQUFELEVBQW1CN0QsS0FBbkIsRUFBNkI7QUFDaEQvQixXQUFPLENBQUNDLEdBQVIsQ0FBWTJGLGdCQUFaO0FBQ0E1RixXQUFPLENBQUNDLEdBQVIsQ0FBWThCLEtBQVo7O0FBQ0EsUUFBS0EsS0FBSyxJQUFJLENBQVYsSUFBZ0I2RCxnQkFBZ0IsQ0FBQzVILE1BQWpCLEdBQTBCLENBQTlDLEVBQWlEO0FBQzdDeEUscUJBQWUsQ0FBQyxJQUFELENBQWY7QUFDQSxVQUFJcU0sSUFBSSxHQUFHLElBQUlDLFFBQUosRUFBWDtBQUNBRCxVQUFJLENBQUNFLE1BQUwsQ0FBWSxVQUFaLEVBQXdCaEUsS0FBeEI7QUFDQThELFVBQUksQ0FBQ0UsTUFBTCxDQUFZLFVBQVosRUFBd0IxRSxJQUFJLENBQUMyRSxTQUFMLENBQWVKLGdCQUFmLENBQXhCO0FBRUFLLG1EQUFLLENBQUNDLElBQU4sQ0FBVzlKLEdBQUcsR0FBRyxlQUFqQixFQUFrQ3lKLElBQWxDLEVBQXdDO0FBQ3BDNUcsZUFBTyxFQUFFO0FBQ0wsb0JBQVUsa0JBREw7QUFFTCxzQkFBWSxNQUZQO0FBRWlCO0FBQ3RCLHlDQUErQixHQUgxQjtBQUlMLDJCQUFpQixZQUFZa0M7QUFKeEI7QUFEMkIsT0FBeEMsRUFRSzlCLElBUkwsQ0FRVSxVQUFDRyxZQUFELEVBQWtCO0FBQ3BCLFlBQUlBLFlBQVksQ0FBQ3FHLElBQWIsQ0FBa0JwRyxPQUFsQixJQUE2QiwrQkFBakMsRUFBa0U7QUFDOUQ3SCxrQkFBUSxDQUFDNEgsWUFBWSxDQUFDcUcsSUFBYixDQUFrQk0sTUFBbEIsQ0FBeUJ4TyxLQUExQixDQUFSO0FBQ0FMLHNCQUFZLGlDQUFLRCxTQUFMO0FBQWdCTSxpQkFBSyxFQUFFNkgsWUFBWSxDQUFDcUcsSUFBYixDQUFrQk0sTUFBbEIsQ0FBeUJ4TztBQUFoRCxhQUFaO0FBQ0E2Qix5QkFBZSxDQUFDLEtBQUQsQ0FBZjtBQUNIO0FBQ0osT0FkTCxXQWVXLFVBQUM0TSxLQUFELEVBQVc7QUFDZHBHLGVBQU8sQ0FBQ0MsR0FBUixDQUFZbUcsS0FBWjtBQUNILE9BakJMO0FBa0JILEtBeEJELE1Bd0JPeE8sUUFBUSxDQUFDLEtBQUQsQ0FBUjtBQUNWLEdBNUJEOztBQTZCQSxNQUFNeU8sWUFBWTtBQUFBLGtSQUFHLGlCQUFPeEosS0FBUDtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2pCO0FBQ0l5SixtQkFGYSxHQUVMekosS0FBSyxDQUFDRyxNQUFOLENBQWF1SixLQUFiLENBQW1CLENBQW5CLEVBQXNCM0UsSUFGakI7QUFHYjRFLDJCQUhhLEdBR0czSixLQUFLLENBQUNHLE1BQU4sQ0FBYXVKLEtBQWIsQ0FBbUIsQ0FBbkIsRUFBc0JFLFlBSHpCO0FBSWpCbk4scUJBQU8sQ0FBQ29OLEdBQUcsQ0FBQ0MsZUFBSixDQUFvQjlKLEtBQUssQ0FBQ0csTUFBTixDQUFhdUosS0FBYixDQUFtQixDQUFuQixDQUFwQixDQUFELENBQVA7QUFDSUssbUJBTGEsR0FLTCxJQUFJQyxJQUFKLENBQVMsQ0FBQ2hLLEtBQUssQ0FBQ0csTUFBTixDQUFhdUosS0FBYixDQUFtQixDQUFuQixDQUFELENBQVQsRUFBa0NELEtBQWxDLEVBQXlDO0FBQUNRLG9CQUFJLEVBQUU7QUFBUCxlQUF6QyxDQUxLLEVBTWpCOztBQUNBeFAsMEJBQVksaUNBQUtELFNBQUw7QUFBZ0JzSix1QkFBTyxFQUFFaUcsS0FBekI7QUFBZ0NoRyx3QkFBUSxFQUFFOEYsR0FBRyxDQUFDQyxlQUFKLENBQW9COUosS0FBSyxDQUFDRyxNQUFOLENBQWF1SixLQUFiLENBQW1CLENBQW5CLENBQXBCO0FBQTFDLGlCQUFaOztBQVBpQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFaRixZQUFZO0FBQUE7QUFBQTtBQUFBLEtBQWxCOztBQVVBLHNCQUNJLHFFQUFDLDBFQUFEO0FBQWtCLFNBQUssRUFBRTFULEtBQXpCO0FBQUEsNEJBQ0k7QUFBSyxlQUFTLEVBQUMsV0FBZjtBQUEyQixTQUFHLEVBQUMsS0FBL0I7QUFBQSw2QkFDSSxxRUFBQywwREFBRDtBQUFBLGdDQUNJLHFFQUFDLG9EQUFEO0FBQUssbUJBQVMsRUFBQyxjQUFmO0FBQUEsa0NBQ0kscUVBQUMsb0RBQUQ7QUFBSyxjQUFFLEVBQUUsQ0FBVDtBQUFZLGNBQUUsRUFBRSxDQUFoQjtBQUFtQixjQUFFLEVBQUUsQ0FBdkI7QUFBMEIsY0FBRSxFQUFFLEVBQTlCO0FBQWtDLGNBQUUsRUFBRSxFQUF0QztBQUFBLG1DQUNJO0FBQU8sdUJBQVMsRUFBQyxXQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFJSSxxRUFBQyxvREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksY0FBRSxFQUFFLENBQWhCO0FBQW1CLGNBQUUsRUFBRSxDQUF2QjtBQUEwQixjQUFFLEVBQUUsRUFBOUI7QUFBa0MsY0FBRSxFQUFFLEVBQXRDO0FBQUEsbUNBQ0kscUVBQUMsNkRBQUQ7QUFBYSxxQkFBTyxFQUFDLFFBQXJCO0FBQThCLHNCQUFRLEVBQUV3RCxxQkFBeEM7QUFBQSxxQ0FDSSxxRUFBQyxzRUFBRDtBQUNJLGtCQUFFLEVBQUMsYUFEUDtBQUVJLHFCQUFLLEVBQUVwQixhQUZYO0FBR0ksd0JBQVEsRUFBRW9CLHFCQUhkO0FBSUksdUJBQU8sRUFBRWhCLFNBQVMsQ0FBQ29KLEdBQVYsQ0FBYyxVQUFDd0ksTUFBRDtBQUFBLHlCQUFZQSxNQUFNLENBQUNuRixJQUFuQjtBQUFBLGlCQUFkLENBSmI7QUFLSSw2QkFBYSxFQUFDLDRFQUxsQjtBQU1JLHdCQUFRLEVBQUVZLGVBTmQ7QUFPSSwyQkFBVyxFQUFFLHFCQUFDd0UsTUFBRDtBQUFBLHNDQUNULHFFQUFDLDJEQUFELGtDQUNRQSxNQURSO0FBRUksMkJBQU8sRUFBQyxRQUZaO0FBR0kseUJBQUssRUFBQyxvSUFIVjtBQUlJLCtCQUFXLEVBQUM7QUFKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFEUztBQUFBO0FBUGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKSixlQXdCSSxxRUFBQyxvREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksY0FBRSxFQUFFLENBQWhCO0FBQW1CLGNBQUUsRUFBRSxDQUF2QjtBQUEwQixjQUFFLEVBQUUsRUFBOUI7QUFBa0MsY0FBRSxFQUFFLEVBQXRDO0FBQUEsbUNBQ0kscUVBQUMsNkRBQUQ7QUFBYSxxQkFBTyxFQUFDLFFBQXJCO0FBQThCLHNCQUFRLEVBQUU3USxxQkFBeEM7QUFBQSxxQ0FDSSxxRUFBQyxzRUFBRDtBQUNJLGtCQUFFLEVBQUMsYUFEUDtBQUVJLHFCQUFLLEVBQUVsQixhQUZYO0FBR0ksd0JBQVEsRUFBRWtCLHFCQUhkO0FBSUksdUJBQU8sRUFBRWQsU0FBUyxDQUFDa0osR0FBVixDQUFjLFVBQUN3SSxNQUFEO0FBQUEseUJBQVlBLE1BQU0sQ0FBQ25GLElBQW5CO0FBQUEsaUJBQWQsQ0FKYjtBQUtJLDZCQUFhLEVBQUMsNEVBTGxCO0FBTUksd0JBQVEsRUFBRWUsZUFOZDtBQU9JLDJCQUFXLEVBQUUscUJBQUNxRSxNQUFEO0FBQUEsc0NBQ1QscUVBQUMsMkRBQUQsa0NBQ1FBLE1BRFI7QUFFSSwyQkFBTyxFQUFDLFFBRlo7QUFHSSx5QkFBSyxFQUFDLDhIQUhWO0FBSUksK0JBQVcsRUFBQztBQUpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURTO0FBQUE7QUFQakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXhCSixlQTRDSSxxRUFBQyxvREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksY0FBRSxFQUFFLENBQWhCO0FBQW1CLGNBQUUsRUFBRSxDQUF2QjtBQUEwQixjQUFFLEVBQUUsRUFBOUI7QUFBa0MsY0FBRSxFQUFFLEVBQXRDO0FBQTBDLHFCQUFTLEVBQUMsYUFBcEQ7QUFBQSxzQkFDS25QLElBQUksQ0FBQ21HLE1BQUwsR0FBYyxDQUFkLGlCQUNELHFFQUFDLDZEQUFEO0FBQWEscUJBQU8sRUFBQyxRQUFyQjtBQUFBLHFDQUNJLHFFQUFDLHNFQUFEO0FBQ0ksa0JBQUUsRUFBQyxhQURQO0FBRUkscUJBQUssRUFBRW5JLGdCQUZYO0FBR0ksdUJBQU8sRUFBRWdDLElBQUksQ0FBQzBHLEdBQUwsQ0FBUyxVQUFDd0ksTUFBRDtBQUFBLHlCQUFZQSxNQUFNLENBQUNqRixLQUFuQjtBQUFBLGlCQUFULENBSGI7QUFJSSw2QkFBYSxFQUFDLDRFQUpsQjtBQUtJLHdCQUFRLEVBQUVtQixrQkFMZDtBQU1JLDJCQUFXLEVBQUUscUJBQUMrRCxNQUFEO0FBQUEsc0NBQ1QscUVBQUMsMkRBQUQsa0NBQ1FBLE1BRFI7QUFFSSwyQkFBTyxFQUFDLFFBRlo7QUFHSSx5QkFBSyxFQUFDLGlGQUhWO0FBSUksK0JBQVcsRUFBQztBQUpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURTO0FBQUE7QUFOakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVDSixlQXNGSSxxRUFBQyxvREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksY0FBRSxFQUFFLENBQWhCO0FBQW1CLGNBQUUsRUFBRSxDQUF2QjtBQUEwQixjQUFFLEVBQUUsRUFBOUI7QUFBa0MsY0FBRSxFQUFFO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdEZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQTBGSSxxRUFBQyxvREFBRDtBQUFLLG1CQUFTLEVBQUMsVUFBZjtBQUEwQixlQUFLLEVBQUU7QUFBQ2xULGtCQUFNLEVBQUU7QUFBVCxXQUFqQztBQUFBLGtDQUNJLHFFQUFDLG9EQUFEO0FBQUssY0FBRSxFQUFFLENBQVQ7QUFBWSxjQUFFLEVBQUUsQ0FBaEI7QUFBbUIsY0FBRSxFQUFFLENBQXZCO0FBQTBCLGNBQUUsRUFBRSxFQUE5QjtBQUFrQyxjQUFFLEVBQUUsRUFBdEM7QUFBQSxtQ0FDSTtBQUFPLHVCQUFTLEVBQUMsV0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBSUkscUVBQUMsb0RBQUQ7QUFBSyxjQUFFLEVBQUUsQ0FBVDtBQUFZLGNBQUUsRUFBRSxDQUFoQjtBQUFtQixjQUFFLEVBQUUsRUFBdkI7QUFBMkIsY0FBRSxFQUFFLEVBQS9CO0FBQW1DLGNBQUUsRUFBRSxFQUF2QztBQUFBLHNCQUVRc04sV0FBVyxHQUFHLENBQWQsZ0JBQ0k7QUFBTSx1QkFBUyxFQUFDLGNBQWhCO0FBQUEsc0NBQ0k7QUFDSSxvQkFBSSxFQUFDLE9BRFQ7QUFFSSxvQkFBSSxFQUFDLGNBRlQ7QUFHSSxxQkFBSyxFQUFDLG9CQUhWO0FBSUksa0JBQUUsRUFBQyxjQUpQO0FBS0ksd0JBQVEsRUFBRW1DLFdBTGQ7QUFNSSx1QkFBTyxFQUFFLENBQUNsTjtBQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFTSTtBQUFPLHVCQUFPLEVBQUMsY0FBZjtBQUE4Qix5QkFBUyxFQUFDLGNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVRKLGVBVUk7QUFDSSxvQkFBSSxFQUFDLE9BRFQ7QUFFSSxvQkFBSSxFQUFDLGNBRlQ7QUFHSSxxQkFBSyxFQUFDLG9CQUhWO0FBSUksa0JBQUUsRUFBQyxhQUpQO0FBS0ksd0JBQVEsRUFBRWtOLFdBTGQ7QUFNSSx1QkFBTyxFQUFFbE47QUFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVZKLGVBa0JJO0FBQU8sdUJBQU8sRUFBQyxhQUFmO0FBQTZCLHlCQUFTLEVBQUMsYUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbEJKLGVBbUJJO0FBQU8seUJBQVMsRUFBQyxZQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLEdBc0JNO0FBeEJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkosRUFnQ1FzRCxZQUFZLGdCQUNSLHFFQUFDLG9EQUFEO0FBQUssY0FBRSxFQUFFLENBQVQ7QUFBWSxjQUFFLEVBQUUsQ0FBaEI7QUFBbUIsY0FBRSxFQUFFLEVBQXZCO0FBQTJCLGNBQUUsRUFBRSxFQUEvQjtBQUFtQyxjQUFFLEVBQUUsRUFBdkM7QUFBMkMscUJBQVMsRUFBQyxVQUFyRDtBQUFBLG9DQUNJO0FBQUssaUJBQUcsRUFBRU4sSUFBVjtBQUFnQix1QkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosRUFHUXBDLE1BQU0sSUFBSSxFQUFWLElBQWdCQSxNQUFNLElBQUksSUFBMUIsZ0JBQWlDO0FBQUEsdUZBQW9CQSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWpDLEdBQ00sSUFKZCxlQU1JO0FBQVEscUJBQU8sRUFBRW9PLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFEUSxHQVVSaFAsTUFBTSxJQUFJVixXQUFXLElBQUksQ0FBekIsSUFDR1UsTUFBTSxJQUFJWixRQUFRLElBQUksQ0FEekIsZ0JBRUk7QUFBUSxtQkFBTyxFQUFFNFAsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosR0FHTSxJQTdDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTFGSixlQTJJSSxxRUFBQyxvREFBRDtBQUFLLG1CQUFTLEVBQUMsVUFBZjtBQUEwQixlQUFLLEVBQUU7QUFBQzRCLHNCQUFVLEVBQUUsR0FBYjtBQUFrQkMsa0JBQU0sRUFBRTtBQUExQixXQUFqQztBQUFBLGtDQUNJLHFFQUFDLG9EQUFEO0FBQUssY0FBRSxFQUFFLENBQVQ7QUFBWSxjQUFFLEVBQUUsQ0FBaEI7QUFBbUIsY0FBRSxFQUFFLEVBQXZCO0FBQTJCLGNBQUUsRUFBRSxFQUEvQjtBQUFtQyxjQUFFLEVBQUUsRUFBdkM7QUFBQSxtQ0FDSSxxRUFBQyw2REFBRDtBQUFhLHVCQUFTLEVBQUMsZUFBdkI7QUFBdUMsdUJBQVMsRUFBQyxVQUFqRDtBQUFBLHNDQUNJO0FBQUsseUJBQVMsRUFBQyxZQUFmO0FBQUEsdUNBQ0k7QUFBTywyQkFBUyxFQUFFL08sYUFBbEI7QUFBQSwwQ0FDSTtBQUFPLHdCQUFJLEVBQUMsVUFBWjtBQUF1Qix3QkFBSSxFQUFDLFVBQTVCO0FBQXVDLHlCQUFLLEVBQUVGLFFBQTlDO0FBQXdELDJCQUFPLEVBQUVBLFFBQWpFO0FBQ08sNEJBQVEsRUFBRUksaUJBRGpCO0FBRU8sNEJBQVEsRUFBRXdMLGVBRmpCO0FBRWtDLDZCQUFTLEVBQUM7QUFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBUUk7QUFBSyx5QkFBUyxFQUFDLFlBQWY7QUFBQSx1Q0FDSTtBQUFPLDJCQUFTLEVBQUVsTCxjQUFsQjtBQUFBLDBDQUNJO0FBQU8sd0JBQUksRUFBQyxVQUFaO0FBQXVCLHdCQUFJLEVBQUMsV0FBNUI7QUFBd0MseUJBQUssRUFBRUYsU0FBL0M7QUFBMEQsMkJBQU8sRUFBRUEsU0FBbkU7QUFDTyw0QkFBUSxFQUFFSixpQkFBaUIsSUFBSWhDLE1BRHRDO0FBRU8sNEJBQVEsRUFBRXdOLGVBRmpCO0FBRWtDLDZCQUFTLEVBQUM7QUFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVJKLGVBc0JJO0FBQUsseUJBQVMsRUFBQywwQkFBZjtBQUFBLHVDQUNJO0FBQU8sMkJBQVMsRUFBRTFLLGNBQWxCO0FBQUEsMENBQ0k7QUFBTyx3QkFBSSxFQUFDLFVBQVo7QUFBdUIsd0JBQUksRUFBQyxXQUE1QjtBQUF3Qyx5QkFBSyxFQUFFRixTQUEvQztBQUEwRCwyQkFBTyxFQUFFQSxTQUFuRTtBQUNPLDRCQUFRLEVBQUU0SyxlQURqQjtBQUNrQyw2QkFBUyxFQUFDO0FBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF0QkosZUE2Qkk7QUFBSyx5QkFBUyxFQUFDLDBCQUFmO0FBQUEsdUNBQ0k7QUFBTywyQkFBUyxFQUFFOUssaUJBQWxCO0FBQUEsMENBQ0k7QUFBTyx3QkFBSSxFQUFDLFVBQVo7QUFBdUIsd0JBQUksRUFBQyxjQUE1QjtBQUEyQyx5QkFBSyxFQUFFRixZQUFsRDtBQUNPLDJCQUFPLEVBQUVBLFlBRGhCO0FBRU8sNEJBQVEsRUFBRXhDLE1BRmpCO0FBR08sNEJBQVEsRUFBRXdOLGVBSGpCO0FBR2tDLDZCQUFTLEVBQUM7QUFINUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBMENJLHFFQUFDLG9EQUFEO0FBQUssY0FBRSxFQUFFLENBQVQ7QUFBWSxjQUFFLEVBQUUsQ0FBaEI7QUFBbUIsY0FBRSxFQUFFLEVBQXZCO0FBQTJCLGNBQUUsRUFBRSxFQUEvQjtBQUFtQyxjQUFFLEVBQUUsRUFBdkM7QUFBQSxzQkFFUXRLLFlBQVksZ0JBQ1I7QUFBSyx1QkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFEUSxnQkFHUjtBQUFPLHVCQUFTLEVBQUMsZUFBakI7QUFBQSw2RkFBZ0Q0TixpRUFBUyxDQUFDeFAsS0FBRCxDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBM0lKLGVBK0xJLHFFQUFDLG9EQUFEO0FBQUssbUJBQVMsRUFBQyxxQkFBZjtBQUFxQyxlQUFLLEVBQUU7QUFBQzdELGtCQUFNLEVBQUU7QUFBVCxXQUE1QztBQUFBLGtDQUNJLHFFQUFDLG9EQUFEO0FBQUssY0FBRSxFQUFFLENBQVQ7QUFBWSxjQUFFLEVBQUUsQ0FBaEI7QUFBbUIsY0FBRSxFQUFFLENBQXZCO0FBQTBCLGNBQUUsRUFBRSxFQUE5QjtBQUFrQyxjQUFFLEVBQUUsRUFBdEM7QUFBQSxtQ0FDSTtBQUFPLHVCQUFTLEVBQUMsV0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBSUkscUVBQUMsb0RBQUQ7QUFBSyxjQUFFLEVBQUUsQ0FBVDtBQUFZLGNBQUUsRUFBRSxDQUFoQjtBQUFtQixjQUFFLEVBQUUsQ0FBdkI7QUFBMEIsY0FBRSxFQUFFLEVBQTlCO0FBQWtDLGNBQUUsRUFBRSxFQUF0QztBQUEwQyxxQkFBUyxFQUFDLFdBQXBEO0FBQUEsb0NBQ0k7QUFBQSxxQ0FDSTtBQUFLLG1CQUFHLEVBQUU2SSwrREFBVjtBQUFnQix5QkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBSUk7QUFBQSxxQ0FDSSxxRUFBQyx5REFBRDtBQUNJLHFCQUFLLEVBQUMscUVBRFY7QUFFSSwyQkFBVyxFQUFDLHFFQUZoQjtBQUdJLDJCQUFXLEVBQUUsS0FIakI7QUFJSSwwQkFBVSxFQUFFLEtBSmhCO0FBS0ksbUJBQUcsRUFBRXRCLFlBQVksQ0FBQ0osR0FMdEI7QUFNSSxtQkFBRyxFQUFFSSxZQUFZLENBQUNELEdBTnRCO0FBT0kscUJBQUssRUFBRXpFLElBUFg7QUFRSSwrQkFBZSxFQUFFLEtBUnJCO0FBU0ksMkJBQVcsRUFBQyxVQVRoQjtBQVVJLHdCQUFRLEVBQUVtTztBQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKSixlQXlCSSxxRUFBQyxvREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksY0FBRSxFQUFFLENBQWhCO0FBQW1CLGNBQUUsRUFBRSxDQUF2QjtBQUEwQixjQUFFLEVBQUUsRUFBOUI7QUFBa0MsY0FBRSxFQUFFLEVBQXRDO0FBQUEsbUNBQ0kscUVBQUMsNkRBQUQ7QUFBYSxxQkFBTyxFQUFDLFFBQXJCO0FBQUEsc0NBQ0kscUVBQUMsNERBQUQ7QUFBWSxrQkFBRSxFQUFDLGlDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBRUkscUVBQUMsd0RBQUQ7QUFDSSx1QkFBTyxFQUFDLGlDQURaO0FBRUksa0JBQUUsRUFBQywyQkFGUDtBQUdJLHFCQUFLLEVBQUV2TyxJQUhYO0FBSUksd0JBQVEsRUFBRWdPLFdBSmQ7QUFLSSxxQkFBSyxFQUFDLG1EQUxWO0FBQUEsMEJBTUt4TjtBQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6QkosZUFzQ0kscUVBQUMsb0RBQUQ7QUFBSyxjQUFFLEVBQUUsQ0FBVDtBQUFZLGNBQUUsRUFBRSxFQUFoQjtBQUFvQixjQUFFLEVBQUUsRUFBeEI7QUFBNEIsY0FBRSxFQUFFLEVBQWhDO0FBQW9DLGNBQUUsRUFBRSxFQUF4QztBQUFBLHNCQUVRUixJQUFJLElBQUksRUFBUixJQUFjRSxPQUFPLElBQUksRUFBekIsaUJBQ0E7QUFBTyx1QkFBUyxFQUFDLGNBQWpCO0FBQUEsb0pBQXlERixJQUF6RCxvQkFBbUVFLE9BQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEvTEosZUE4T0kscUVBQUMsb0RBQUQ7QUFBSyxtQkFBUyxFQUFDLFVBQWY7QUFBQSxpQ0FDSSxxRUFBQyx3REFBRDtBQUFRLHFCQUFTLEVBQUMsRUFBbEI7QUFBcUIsbUJBQU8sRUFBQyxXQUE3QjtBQUF5QyxpQkFBSyxFQUFDLFdBQS9DO0FBQ1EsbUJBQU8sRUFBRTtBQUFBLHFCQUFNeU8sV0FBVyxFQUFqQjtBQUFBLGFBRGpCO0FBRVEsb0JBQVEsRUFBRXJRLFdBRmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE5T0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURKLGVBaVFJLHFFQUFDLGdFQUFEO0FBQVEsVUFBSSxFQUFFc0MsU0FBZDtBQUF5QixhQUFPLEVBQUVtTyxVQUFsQztBQUE4Qyx5QkFBZ0IsbUJBQTlEO0FBQWtGLGVBQVMsRUFBQyxlQUE1RjtBQUFBLDhCQUNJLHFFQUFDLHNFQUFEO0FBQWEsVUFBRSxFQUFDLG1CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKLGVBRUkscUVBQUMsd0VBQUQ7QUFBQSxnQ0FDSSxxRUFBQyw0RUFBRDtBQUFBLG1ZQUVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosKzBCQU1JO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkosZ1BBUUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFjSSxxRUFBQywwRUFBRDtBQUFrQixlQUFLLEVBQUUzUyxLQUF6QjtBQUFBLGlDQUNJO0FBQUssZUFBRyxFQUFDLEtBQVQ7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMscUJBQWY7QUFBQSxzQ0FDUTtBQUFPLG9CQUFJLEVBQUMsS0FBWjtBQUFrQix5QkFBUyxFQUFDLFFBQTVCO0FBQXFDLHlCQUFTLEVBQUUsQ0FBaEQ7QUFBbUQscUJBQUssRUFBRXNILElBQTFEO0FBQWdFLGtCQUFFLEVBQUMsR0FBbkU7QUFDTyx3QkFBUSxFQUFFMkMsVUFEakI7QUFFTyx1QkFBTyxFQUFDLFFBRmY7QUFFd0IseUJBQVMsRUFBRUE7QUFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFEUixlQUlRO0FBQU8sb0JBQUksRUFBQyxLQUFaO0FBQWtCLHlCQUFTLEVBQUMsUUFBNUI7QUFBcUMseUJBQVMsRUFBRSxDQUFoRDtBQUFtRCxxQkFBSyxFQUFFekMsSUFBMUQ7QUFBZ0Usa0JBQUUsRUFBQyxHQUFuRTtBQUNPLHdCQUFRLEVBQUV5QyxVQURqQjtBQUVPLHVCQUFPLEVBQUMsUUFGZjtBQUV3Qix5QkFBUyxFQUFFQTtBQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpSLGVBT1E7QUFBUSxxQkFBSyxFQUFFdkMsSUFBZjtBQUFxQixrQkFBRSxFQUFDLEdBQXhCO0FBQTRCLHdCQUFRLEVBQUV1QyxVQUF0QztBQUFrRCx5QkFBUyxFQUFFQSxVQUE3RDtBQUFBLHdDQUNJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBRUk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkosZUFHSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFISixlQUlJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUpKLGVBS0k7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTEosZUFNSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFOSixlQVFJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVJKLGVBU0k7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVEosZUFVSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFWSixlQVdJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVhKLGVBWUk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWkosZUFhSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFiSixlQWNJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWRKLGVBZUk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZkosZUFnQkk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaEJKLGVBaUJJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWpCSixlQWtCSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFsQkosZUFtQkk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbkJKLGVBb0JJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXBCSixlQXFCSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFyQkosZUFzQkk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdEJKLGVBdUJJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXZCSixlQXdCSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF4QkosZUF5Qkk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBekJKLGVBMEJJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTFCSixlQTJCSTtBQUFRLHVCQUFLLEVBQUMsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEzQkosZUE0Qkk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBNUJKLGVBNkJJO0FBQVEsdUJBQUssRUFBQyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTdCSixlQThCSTtBQUFRLHVCQUFLLEVBQUMsY0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE5QkosZUErQkk7QUFBUSx1QkFBSyxFQUFDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBL0JKLGVBZ0NJO0FBQVEsdUJBQUssRUFBQyxHQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWhDSixlQWlDSTtBQUFRLHVCQUFLLEVBQUMsR0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVBSLGVBMENRO0FBQU8sb0JBQUksRUFBQyxLQUFaO0FBQWtCLHlCQUFTLEVBQUMsUUFBNUI7QUFBcUMseUJBQVMsRUFBRSxDQUFoRDtBQUFtRCxxQkFBSyxFQUFFckMsSUFBMUQ7QUFBZ0Usa0JBQUUsRUFBQyxHQUFuRTtBQUNPLHdCQUFRLEVBQUVxQyxVQURqQjtBQUVPLHVCQUFPLEVBQUMsUUFGZjtBQUV3Qix5QkFBUyxFQUFFQTtBQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTFDUixlQTZDUTtBQUFPLG9CQUFJLEVBQUMsS0FBWjtBQUFrQix5QkFBUyxFQUFDLFFBQTVCO0FBQXFDLHlCQUFTLEVBQUUsQ0FBaEQ7QUFBbUQscUJBQUssRUFBRW5DLElBQTFEO0FBQWdFLGtCQUFFLEVBQUMsR0FBbkU7QUFDTyx3QkFBUSxFQUFFbUMsVUFEakI7QUFFTyx1QkFBTyxFQUFDLFFBRmY7QUFFd0IseUJBQVMsRUFBRUE7QUFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE3Q1IsZUFnRFE7QUFBTyxvQkFBSSxFQUFDLEtBQVo7QUFBa0IseUJBQVMsRUFBQyxRQUE1QjtBQUFxQyx5QkFBUyxFQUFFLENBQWhEO0FBQW1ELHFCQUFLLEVBQUVqQyxJQUExRDtBQUFnRSxrQkFBRSxFQUFDLEdBQW5FO0FBQ08sd0JBQVEsRUFBRWlDLFVBRGpCO0FBRU8sdUJBQU8sRUFBQyxRQUZmO0FBRXdCLHlCQUFTLEVBQUVBO0FBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaERSLGVBbURRO0FBQU8sb0JBQUksRUFBQyxLQUFaO0FBQWtCLHlCQUFTLEVBQUMsUUFBNUI7QUFBcUMseUJBQVMsRUFBRSxDQUFoRDtBQUFtRCxxQkFBSyxFQUFFL0IsSUFBMUQ7QUFBZ0Usa0JBQUUsRUFBQyxHQUFuRTtBQUNPLHdCQUFRLEVBQUUrQixVQURqQjtBQUVPLHVCQUFPLEVBQUMsUUFGZjtBQUV3Qix5QkFBUyxFQUFFQTtBQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW5EUixlQXNEUTtBQUFPLG9CQUFJLEVBQUMsS0FBWjtBQUFrQix5QkFBUyxFQUFDLFFBQTVCO0FBQXFDLHlCQUFTLEVBQUUsQ0FBaEQ7QUFBbUQscUJBQUssRUFBRTdCLElBQTFEO0FBQWdFLGtCQUFFLEVBQUMsR0FBbkU7QUFDTyx3QkFBUSxFQUFFNkIsVUFEakI7QUFFTyx1QkFBTyxFQUFDLFFBRmY7QUFFd0IseUJBQVMsRUFBRUE7QUFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF0RFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBc0VJO0FBQUssdUJBQVMsRUFBQyxhQUFmO0FBQUEsc0NBQ1E7QUFDSSxvQkFBSSxFQUFDLE1BRFQ7QUFFSSxzQkFBTSxFQUFDLFNBRlg7QUFHSSx5QkFBUyxFQUFDLFdBSGQ7QUFJSSxrQkFBRSxFQUFDLGtCQUpQO0FBS0ksb0NBQWlCLHVCQUxyQjtBQU1JLHVCQUFPLEVBQUUsaUJBQUM2RixDQUFEO0FBQUEseUJBQU9BLENBQUMsQ0FBQ3pGLE1BQUYsQ0FBU1EsS0FBVCxHQUFpQixFQUF4QjtBQUFBLGlCQU5iLENBTXdDO0FBTnhDO0FBT0ksd0JBQVEsRUFBRTZJO0FBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFEUixlQVVRO0FBQU0seUJBQVMsRUFBQyxnQkFBaEI7QUFBQSx3Q0FDWjtBQUFLLHFCQUFHLEVBQUVlLDBFQUFjQTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURZLGVBRVo7QUFBTyx5QkFBTyxFQUFDLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRlk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVZSLGVBZVE7QUFBSyxtQkFBRyxFQUFFL04sSUFBVjtBQUFnQix5QkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXRFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZKLGVBMkdJLHFFQUFDLHVFQUFEO0FBQUEsZ0NBQ0kscUVBQUMsd0RBQUQ7QUFBUSxpQkFBTyxFQUFFaU0sVUFBakI7QUFBNkIsZUFBSyxFQUFDLFNBQW5DO0FBQTZDLGlCQUFPLEVBQUMsTUFBckQ7QUFBNEQsbUJBQVMsRUFBQyxXQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQUlJLHFFQUFDLHdEQUFEO0FBQVEsaUJBQU8sRUFBRUUsY0FBakI7QUFBaUMsZUFBSyxFQUFDLFNBQXZDO0FBQWlELGlCQUFPLEVBQUMsTUFBekQ7QUFBZ0UsbUJBQVMsRUFBQyxXQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEzR0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBalFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURKO0FBd1hILENBbjVDRDs7R0FBTXJSLEs7VUFDYUcsc0QsRUFDQ2hCLFM7OztLQUZkYSxLO0FBbzVDU0Esb0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvb3JkZXIuMDQxYzJhNzI1Y2UyZjE0ZTg5MDIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwge3VzZVN0YXRlLCB1c2VFZmZlY3R9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgXCIuL29yZGVyLmNzc1wiXHJcbmltcG9ydCB7XHJcbiAgICBUZXh0RmllbGQsXHJcbiAgICBCdXR0b24sXHJcbiAgICBJbnB1dExhYmVsLFxyXG4gICAgU2VsZWN0LFxyXG4gICAgTWVudUl0ZW0sXHJcbiAgICBGb3JtQ29udHJvbCxcclxuICAgIE1vZGFsXHJcbn0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcbmltcG9ydCBEaWFsb2cgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nJztcclxuaW1wb3J0IERpYWxvZ0FjdGlvbnMgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nQWN0aW9ucyc7XHJcbmltcG9ydCBEaWFsb2dDb250ZW50IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ0NvbnRlbnQnO1xyXG5pbXBvcnQgRGlhbG9nQ29udGVudFRleHQgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nQ29udGVudFRleHQnO1xyXG5pbXBvcnQgRGlhbG9nVGl0bGUgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nVGl0bGUnO1xyXG5pbXBvcnQge011aVRoZW1lUHJvdmlkZXIsIGNyZWF0ZU11aVRoZW1lfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5pbXBvcnQgQXV0b2NvbXBsZXRlIGZyb20gJ0BtYXRlcmlhbC11aS9sYWIvQXV0b2NvbXBsZXRlJztcclxuaW1wb3J0IHtDb2wsIENvbnRhaW5lciwgUm93fSBmcm9tIFwicmVhY3QtYm9vdHN0cmFwXCI7XHJcbmltcG9ydCBEYXRlUGlja2VyIGZyb20gJ3JlYWN0LWRhdGVwaWNrZXIyJztcclxuaW1wb3J0IG1vbWVudEphbGFhbGkgZnJvbSBcIm1vbWVudC1qYWxhYWxpXCI7XHJcbmltcG9ydCB7dXNlUm91dGVyfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHttYWtlU3R5bGVzfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xyXG5pbXBvcnQgZG93biBmcm9tIFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9kb3duLnBuZ1wiO1xyXG5pbXBvcnQgY2xvdWRDb21wdXRpbmcgZnJvbSBcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvY2xvdWQtY29tcHV0aW5nLnBuZ1wiO1xyXG5pbXBvcnQge2FkZENvbW1hc30gZnJvbSBcInBlcnNpYW4tdG9vbHMyXCI7XHJcbmltcG9ydCBOb3RpZmxpeCBmcm9tIFwibm90aWZsaXhcIjtcclxuXHJcbmNvbnN0IHRoZW1lID0gY3JlYXRlTXVpVGhlbWUoe1xyXG4gICAgZGlyZWN0aW9uOiAncnRsJ1xyXG59KTtcclxuXHJcbmZ1bmN0aW9uIHJhbmQoKSB7XHJcbiAgICByZXR1cm4gTWF0aC5yb3VuZChNYXRoLnJhbmRvbSgpICogMjApIC0gMTA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldE1vZGFsU3R5bGUoKSB7XHJcbiAgICBjb25zdCB0b3AgPSA1MCArIHJhbmQoKTtcclxuICAgIGNvbnN0IGxlZnQgPSA1MCArIHJhbmQoKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIHRvcDogYCR7dG9wfSVgLFxyXG4gICAgICAgIGxlZnQ6IGAke2xlZnR9JWAsXHJcbiAgICAgICAgdHJhbnNmb3JtOiBgdHJhbnNsYXRlKC0ke3RvcH0lLCAtJHtsZWZ0fSUpYCxcclxuICAgIH07XHJcbn1cclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgcGFwZXI6IHtcclxuICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcclxuICAgICAgICB3aWR0aDogNDAwLFxyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5iYWNrZ3JvdW5kLnBhcGVyLFxyXG4gICAgICAgIGJvcmRlcjogJzJweCBzb2xpZCAjMDAwJyxcclxuICAgICAgICBib3hTaGFkb3c6IHRoZW1lLnNoYWRvd3NbNV0sXHJcbiAgICAgICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyLCA0LCAzKSxcclxuICAgIH0sXHJcbn0pKTtcclxuXHJcbmNvbnN0IE9yZGVyID0gKHByb3BzKSA9PiB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgW21vZGFsU3R5bGVdID0gUmVhY3QudXNlU3RhdGUoZ2V0TW9kYWxTdHlsZSk7XHJcbiAgICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbYnRuRGlzYWJsZWQsIHNldEJ0bkRpc2FibGVkXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gICAgY29uc3QgW2NhckJyYW5kVGl0bGUsIHNldENhckJyYW5kVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbY2FyTW9kZWxUaXRsZSwgc2V0Q2FyTW9kZWxUaXRsZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtjYXJCcmFuZHMsIHNldENhckJyYW5kc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbY2FyTW9kZWxzLCBzZXRDYXJNb2RlbHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2NhckJyYW5kLCBzZXRDYXJCcmFuZF0gPSB1c2VTdGF0ZSgwKTtcclxuICAgIGNvbnN0IFtjYXJNb2RlbCwgc2V0Q2FyTW9kZWxdID0gdXNlU3RhdGUoMCk7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRDYXIsIHNldFNlbGVjdGVkQ2FyXSA9IHVzZVN0YXRlKDApO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkQ2FyVGl0bGUsIHNldFNlbGVjdGVkQ2FyVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRDYXJNb2RlbFRpdGxlLCBzZXRTZWxlY3RlZENhck1vZGVsVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRDYXJCcmFuZFRpdGxlLCBzZXRTZWxlY3RlZENhckJyYW5kVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRDYXJJc1NlbGVjdGVkLCBzZXRTZWxlY3RlZENhcklzU2VsZWN0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3RvZ2dsZSwgc2V0VG9nZ2xlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFt0aW1lLCBzZXRUaW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3RpbWVFbmQsIHNldFRpbWVFbmRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbZGF0ZSwgc2V0RGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFt0aW1lc3RhbXAsIHNldFRpbWVzdGFtcF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFt0aW1lcywgc2V0VGltZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2NhclRhZywgc2V0Q2FyVGFnXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtvcmRlckRhdGEsIHNldE9yZGVyRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbc2VydmljZXMsIHNldFNlcnZpY2VzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtzZXJ2aWNlc1RpdGxlLCBzZXRTZXJ2aWNlc1RpdGxlXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtwcmljZSwgc2V0UHJpY2VdID0gdXNlU3RhdGUoXCIuLi5cIik7XHJcbiAgICBjb25zdCBbY2Fycywgc2V0Q2Fyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbY2Fyc0hvbGRlciwgc2V0Q2Fyc0hvbGRlcl0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbcm9vU2hveWksIHNldFJvb1Nob3lpXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtyb29TaG95aUNsYXNzLCBzZXRSb29TaG95aUNsYXNzXSA9IHVzZVN0YXRlKFwiZmFsc2VcIik7XHJcbiAgICBjb25zdCBbcm9vU2hveWlUb29TaG9veWksIHNldFJvb1Nob3lpVG9vU2hvb3lpXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtyb29TaG95aVRvb1Nob295aUNsYXNzLCBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzXSA9IHVzZVN0YXRlKFwiZmFsc2VcIik7XHJcbiAgICBjb25zdCBbdG9vU2hvb3lpLCBzZXRUb29TaG9veWldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Rvb1Nob295aUNsYXNzLCBzZXRUb29TaG9veWlDbGFzc10gPSB1c2VTdGF0ZShcImZhbHNlXCIpO1xyXG4gICAgY29uc3QgW2Rhc2hib2FyZFdheCwgc2V0RGFzaGJvYXJkV2F4XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtkYXNoYm9hcmRXYXhDbGFzcywgc2V0RGFzaGJvYXJkV2F4Q2xhc3NdID0gdXNlU3RhdGUoXCJmYWxzZVwiKTtcclxuICAgIGNvbnN0IFtsYXN0aWtXYXgsIHNldExhc3Rpa1dheF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbbGFzdGlrV2F4Q2xhc3MsIHNldExhc3Rpa1dheENsYXNzXSA9IHVzZVN0YXRlKFwiZmFsc2VcIik7XHJcbiAgICBjb25zdCBbZmlsZSwgc2V0RmlsZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nUHJpY2UsIHNldExvYWRpbmdQcmljZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc2hvd0ZpbGUsIHNldHNob3dGaWxlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3Nob3dDYXJJdGVtcywgc2V0U2hvd0Nhckl0ZW1zXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtlZGl0Q2FyLCBzZXRFZGl0Q2FyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtpc1Rvb09yUm9vU2VsZWN0ZWQsIHNldElzVG9vT3JSb29TZWxlY3RlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbbnVtMCwgc2V0TnVtMF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtudW0xLCBzZXROdW0xXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW251bTIsIHNldE51bTJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbbnVtMywgc2V0TnVtM10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtudW00LCBzZXROdW00XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW251bTUsIHNldE51bTVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbbnVtNiwgc2V0TnVtNl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtudW03LCBzZXROdW03XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW2VuYWJsZWRSYW5nZSwgc2V0RW5hYmxlZFJhbmdlXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICBtaW46IG1vbWVudEphbGFhbGkoKS5hZGQoLTEsICdkYXlzJyksXHJcbiAgICAgICAgbWF4OiBtb21lbnRKYWxhYWxpKCkuYWRkKDE0LCAnZGF5cycpXHJcbiAgICB9KTtcclxuICAgIE5vdGlmbGl4Lk5vdGlmeS5Jbml0KHtcclxuICAgICAgICB3aWR0aDogJzI1MHB4JyxcclxuICAgICAgICB1c2VJY29uOiBmYWxzZSxcclxuICAgICAgICBmb250U2l6ZTogJzE0cHgnLFxyXG4gICAgICAgIGZvbnRGYW1pbHk6IFwiSVJBTlNhbnNXZWJcIixcclxuICAgICAgICBwb3NpdGlvbjogXCJjZW50ZXItdG9wXCIsXHJcbiAgICAgICAgY2xvc2VCdXR0b246IHRydWUsXHJcbiAgICAgICAgcnRsOiB0cnVlLFxyXG4gICAgICAgIGNzc0FuaW1hdGlvblN0eWxlOiAnZnJvbS10b3AnXHJcbiAgICB9KTtcclxuICAgIE5vdGlmbGl4LkxvYWRpbmcuSW5pdCh7XHJcbiAgICAgICAgc3ZnQ29sb3I6IHByb2Nlc3MuZW52LmxvYWRpbmdEb3RzQ29sb3JcclxuICAgIH0pO1xyXG4gICAgbGV0IHVybCA9IHByb2Nlc3MuZW52LnVybDtcclxuICAgIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIHJvb1Nob3lpOiByb29TaG95aSxcclxuICAgICAgICB0b29TaG9veWk6IHRvb1Nob295aSxcclxuICAgICAgICByb29TaG95aVRvb1Nob295aTogcm9vU2hveWlUb29TaG9veWksXHJcbiAgICAgICAgbGFzdGlrV2F4OiBsYXN0aWtXYXgsXHJcbiAgICAgICAgZGFzaGJvYXJkV2F4OiBkYXNoYm9hcmRXYXhcclxuICAgIH0pXHJcbiAgICB2YXIgS0VZX0NPREUgPSB7XHJcbiAgICAgICAgYmFja3NwYWNlOiA4LFxyXG4gICAgICAgIGxlZnQ6IDM3LFxyXG4gICAgICAgIHVwOiAzOCxcclxuICAgICAgICByaWdodDogMzksXHJcbiAgICAgICAgZG93bjogNDBcclxuICAgIH07XHJcbiAgICBjb25zdCBudW1IYW5kbGVyID0gKGV2ZW50KSA9PiB7XHJcbiAgICAgICAgbGV0IGlkID0gcGFyc2VJbnQoZXZlbnQudGFyZ2V0LmlkKTtcclxuICAgICAgICAvKmlmKCgoZXZlbnQua2V5Q29kZTw0NyYmZXZlbnQua2V5Q29kZT41OCl8fChldmVudC5rZXlDb2RlPDk1JiZldmVudC5rZXlDb2RlPjEwNikpKVxyXG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGVsc2UqL1xyXG4gICAgICAgIGlmICghZXZlbnQudGFyZ2V0LnZhbGlkaXR5LnZhbGlkKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9IGVsc2UgaWYgKGV2ZW50LmtleUNvZGUgPT09IEtFWV9DT0RFLmJhY2tzcGFjZSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKGlkKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TnVtMChcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIHNldE51bTEoXCJcIilcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW0yKFwiXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TnVtMyhcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgICAgIHNldE51bTQoXCJcIilcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNTpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW01KFwiXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDY6XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TnVtNihcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OlxyXG4gICAgICAgICAgICAgICAgICAgIHNldE51bTcoXCJcIilcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKChpZCAtIDEpLnRvU3RyaW5nKCkpICE9IG51bGwpXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgoaWQgLSAxKS50b1N0cmluZygpKS5mb2N1cygpO1xyXG4gICAgICAgICAgICBlbHNlIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKChpZCkudG9TdHJpbmcoKSkuZm9jdXMoKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGV2ZW50LmtleUNvZGUgPT09IEtFWV9DT0RFLmxlZnQpIHtcclxuICAgICAgICAgICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKChpZCAtIDEpLnRvU3RyaW5nKCkpICE9IG51bGwpXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgoaWQgLSAxKS50b1N0cmluZygpKS5mb2N1cygpO1xyXG4gICAgICAgICAgICBlbHNlIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKChpZCkudG9TdHJpbmcoKSkuZm9jdXMoKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGV2ZW50LmtleUNvZGUgPT09IEtFWV9DT0RFLnJpZ2h0KSB7XHJcbiAgICAgICAgICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgoaWQgKyAxKS50b1N0cmluZygpKSAhPSBudWxsKVxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoKGlkICsgMSkudG9TdHJpbmcoKSkuZm9jdXMoKTtcclxuICAgICAgICAgICAgZWxzZSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgoaWQpLnRvU3RyaW5nKCkpLmZvY3VzKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChldmVudC5rZXlDb2RlID09PSBLRVlfQ09ERS51cCB8fCBldmVudC5rZXlDb2RlID09PSBLRVlfQ09ERS5kb3duKSB7XHJcbiAgICAgICAgICAgIC8vZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGV2ZW50LnRhcmdldC52YWx1ZSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoaWQpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW0wKGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW0xKGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW0yKGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW0zKGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNDpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW00KGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNTpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW01KGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNjpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW02KGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNzpcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW03KGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBzZXRDYXJUYWcobnVtMCArIG51bTEgKyBudW0yICsgbnVtMyArIG51bTQgKyBudW01ICsgbnVtNiArIGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9hbGVydChudW0wICsgbnVtMSArIG51bTIgKyBudW0zICsgbnVtNCArIG51bTUgKyBudW02ICsgZXZlbnQudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldE9yZGVyRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLm9yZGVyRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FyVGFnOiBudW0wICsgbnVtMSArIG51bTIgKyBudW0zICsgbnVtNCArIG51bTUgKyBudW02ICsgZXZlbnQudGFyZ2V0LnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy9uW2lkXT1ldmVudC50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKChpZCArIDEpLnRvU3RyaW5nKCkpICE9IG51bGwpXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgoaWQgKyAxKS50b1N0cmluZygpKS5mb2N1cygpO1xyXG4gICAgICAgICAgICBlbHNlIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKChpZCkudG9TdHJpbmcoKSkuZm9jdXMoKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgLypsZXQgZW5hYmxlZFJhbmdlID0ge1xyXG4gICAgICAgIG1pbjogbW9tZW50SmFsYWFsaSgpLmFkZCgtMSwgJ2RheXMnKSxcclxuICAgICAgICBtYXg6IG1vbWVudEphbGFhbGkoKS5hZGQoMTQsICdkYXlzJylcclxuICAgIH07Ki9cclxuICAgIGxldCB0aW1lc0hvbGRlciA9IFtcIjA2OjAwXCIsIFwiMDY6MzBcIiwgXCIwNzowMFwiLCBcIjA3OjMwXCIsIFwiMDg6MDBcIiwgXCIwODozMFwiLCBcIjA5OjAwXCIsIFwiMDk6MzBcIiwgXCIxMDowMFwiLCBcIjEwOjMwXCIsIFwiMTE6MDBcIiwgXCIxMTozMFwiLFxyXG4gICAgICAgIFwiMTI6MDBcIiwgXCIxMjozMFwiLCBcIjEzOjAwXCIsIFwiMTM6MzBcIiwgXCIxNDowMFwiLCBcIjE0OjMwXCIsIFwiMTU6MDBcIiwgXCIxNTozMFwiLFxyXG4gICAgICAgIFwiMTY6MDBcIiwgXCIxNjozMFwiLCBcIjE3OjAwXCIsIFwiMTc6MzBcIiwgXCIxODowMFwiLCBcIjE4OjMwXCIsIFwiMTk6MDBcIiwgXCIxOTozMFwiLFxyXG4gICAgICAgIFwiMjA6MDBcIiwgXCIyMDozMFwiLCBcIjIxOjAwXCIsIFwiMjE6MzBcIiwgXCIyMjowMFwiLCBcIjIyOjMwXCIsIFwiMjM6MDBcIiwgXCIyMzozMFwiLCBcIjI0OjAwXCJcclxuICAgIF07XHJcbiAgICBjb25zdCB0aW1lc0hhbmRsZXIgPSAobmV3RGF0ZSkgPT4ge1xyXG4gICAgICAgIGxldCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgbGV0IGN1cnJlbnRIID0gKHRvZGF5LmdldEhvdXJzKCkgKyAxKS50b1N0cmluZygpXHJcbiAgICAgICAgaWYgKGN1cnJlbnRILmxlbmd0aCA9PSAxKSBjdXJyZW50SCA9IFwiMFwiICsgY3VycmVudEhcclxuICAgICAgICBsZXQgY3VycmVudE0gPSB0b2RheS5nZXRNaW51dGVzKCkudG9TdHJpbmcoKVxyXG4gICAgICAgIGlmIChjdXJyZW50TS5sZW5ndGggPT0gMSkgY3VycmVudE0gPSBcIjBcIiArIGN1cnJlbnRNXHJcbiAgICAgICAgbGV0IGN1cnJlbnQgPSBjdXJyZW50SCArIFwiOlwiICsgY3VycmVudE07XHJcbiAgICAgICAgaWYgKG1vbWVudEphbGFhbGkodG9kYXkpLmpEYXRlKCkgPT0gbW9tZW50SmFsYWFsaShuZXdEYXRlKS5qRGF0ZSgpXHJcbiAgICAgICAgICAgICYmIG1vbWVudEphbGFhbGkodG9kYXkpLmpNb250aCgpID09IG1vbWVudEphbGFhbGkobmV3RGF0ZSkuak1vbnRoKClcclxuICAgICAgICAgICAgJiYgbW9tZW50SmFsYWFsaSh0b2RheSkualllYXIoKSA9PSBtb21lbnRKYWxhYWxpKG5ld0RhdGUpLmpZZWFyKCkpXHJcbiAgICAgICAgICAgIHNldFRpbWVzKHRpbWVzSG9sZGVyLm1hcCgodGltZSwgaW5kZXgpID0+XHJcbiAgICAgICAgICAgICAgICBjdXJyZW50IDwgdGltZSA/XHJcbiAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIGtleT17aW5kZXh9IHZhbHVlPXt0aW1lfT57dGltZX08L01lbnVJdGVtPiA6XHJcbiAgICAgICAgICAgICAgICAgICAgbnVsbFxyXG4gICAgICAgICAgICApKVxyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgc2V0VGltZXModGltZXNIb2xkZXIubWFwKCh0aW1lLCBpbmRleCkgPT5cclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSBrZXk9e2luZGV4fSB2YWx1ZT17dGltZX0+e3RpbWV9PC9NZW51SXRlbT5cclxuICAgICAgICAgICAgKSlcclxuICAgICAgICAvKmlmKHRvZGF5LmdldEhvdXJzKCk9PTIzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgc2V0RW5hYmxlZFJhbmdlKHsuLi5lbmFibGVkUmFuZ2UsbWluOm1vbWVudEphbGFhbGkoKS5hZGQoMSwgJ2RheXMnKX0pXHJcbiAgICAgICAgfSovXHJcbiAgICAgICAgc2V0VGltZShcIlwiKVxyXG4gICAgICAgIHNldFRpbWVFbmQoXCJcIilcclxuICAgIH1cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcblxyXG4gICAgICAgIGZldGNoQ2FyTW9kZWxzKFwiXCIpXHJcbiAgICAgICAgZmV0Y2hDYXJzKClcclxuICAgICAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcclxuICAgICAgICBjb25zdCBwcm9taXNlID0gd2luZG93XHJcbiAgICAgICAgICAgIC5mZXRjaCh1cmwgKyAnL2NhcnMvYnJhbmRzJywge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBY2NlcHQnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnZGF0YVR5cGUnOiAnanNvbnAnLCAgIC8veW91IG1heSB1c2UganNvbnAgZm9yIGNyb3NzIG9yaWdpbiByZXF1ZXN0XHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgICAgICAgICAgICAgbW9kZTogJ2NvcnMnLFxyXG4gICAgICAgICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC50aGVuKHJlcyA9PiByZXMuanNvbigpKVxyXG4gICAgICAgICAgICAudGhlbihyZXNwb25zZUpzb24gPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlSnNvbi5tZXNzYWdlID09IFwi2KjYsdmG2K/igIzZh9inINio2Kcg2YXZiNmB2YLbjNiqINiv2LHbjNin2YHYqiDYtNivLlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2FyQnJhbmRzKHJlc3BvbnNlSnNvbi5icmFuZHMpXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0VtcHR5KHByb3BzLm9yZGVyRGF0YSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BzLm9yZGVyRGF0YS5zZWxlY3RlZENhciA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENhckJyYW5kKDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDYXJNb2RlbCgwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FyQnJhbmRUaXRsZShcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FyTW9kZWxUaXRsZShcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3JkZXJEYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5vcmRlckRhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRDYXI6IHByb3BzLm9yZGVyRGF0YS5zZWxlY3RlZENhcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXJNb2RlbDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlbFRpdGxlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhckJyYW5kOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyYW5kVGl0bGU6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZENhcklzU2VsZWN0ZWQodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENhckJyYW5kVGl0bGUocHJvcHMub3JkZXJEYXRhLmJyYW5kVGl0bGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDYXJCcmFuZChwcm9wcy5vcmRlckRhdGEuY2FyQnJhbmQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRPcmRlckRhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLm9yZGVyRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXJCcmFuZDogcHJvcHMub3JkZXJEYXRhLmNhckJyYW5kLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyYW5kVGl0bGU6IHByb3BzLm9yZGVyRGF0YS5icmFuZFRpdGxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycilcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAvLyBDYW5jZWwgdGhlIHJlcXVlc3QgaWYgaXQgdGFrZXMgbW9yZSB0aGFuIGRlbGF5RmV0Y2ggc2Vjb25kc1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gYWJvcnRDb250cm9sbGVyLmFib3J0KCksIHByb2Nlc3MuZW52LmRlbGF5RmV0Y2gpXHJcblxyXG4gICAgICAgIGlmICghaXNFbXB0eShwcm9wcy5vcmRlckRhdGEpKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHByb3BzLm9yZGVyRGF0YSlcclxuICAgICAgICAgICAgc2V0T3JkZXJEYXRhKHByb3BzLm9yZGVyRGF0YSlcclxuICAgICAgICAgICAgaWYgKHByb3BzLm9yZGVyRGF0YS5zZXJ2aWNlcy5pbmNsdWRlcygxKSkge1xyXG4gICAgICAgICAgICAgICAgc2V0Um9vU2hveWkodHJ1ZSlcclxuICAgICAgICAgICAgICAgIHNldFJvb1Nob3lpQ2xhc3MoXCJ0cnVlXCIpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHByb3BzLm9yZGVyRGF0YS5zZXJ2aWNlcy5pbmNsdWRlcygyKSkge1xyXG4gICAgICAgICAgICAgICAgc2V0VG9vU2hvb3lpKHRydWUpXHJcbiAgICAgICAgICAgICAgICBzZXRUb29TaG9veWlDbGFzcyhcInRydWVcIilcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAocHJvcHMub3JkZXJEYXRhLnNlcnZpY2VzLmluY2x1ZGVzKDQpKSB7XHJcbiAgICAgICAgICAgICAgICBzZXRMYXN0aWtXYXgodHJ1ZSlcclxuICAgICAgICAgICAgICAgIHNldExhc3Rpa1dheENsYXNzKFwidHJ1ZVwiKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChwcm9wcy5vcmRlckRhdGEuc2VydmljZXMuaW5jbHVkZXMoNSkpIHtcclxuICAgICAgICAgICAgICAgIHNldERhc2hib2FyZFdheCh0cnVlKVxyXG4gICAgICAgICAgICAgICAgc2V0RGFzaGJvYXJkV2F4Q2xhc3MoXCJ0cnVlXCIpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc2V0U2VydmljZXNUaXRsZShwcm9wcy5vcmRlckRhdGEuc2VydmljZXNUaXRsZSlcclxuICAgICAgICAgICAgc2V0U2VydmljZXMocHJvcHMub3JkZXJEYXRhLnNlcnZpY2VzKTtcclxuICAgICAgICAgICAgc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICByb29TaG95aTogcHJvcHMub3JkZXJEYXRhLnNlcnZpY2VzLmluY2x1ZGVzKDEpID8gdHJ1ZSA6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgdG9vU2hvb3lpOiBwcm9wcy5vcmRlckRhdGEuc2VydmljZXMuaW5jbHVkZXMoMikgPyB0cnVlIDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBkYXNoYm9hcmRXYXg6IHByb3BzLm9yZGVyRGF0YS5zZXJ2aWNlcy5pbmNsdWRlcyg0KSA/IHRydWUgOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGxhc3Rpa1dheDogcHJvcHMub3JkZXJEYXRhLnNlcnZpY2VzLmluY2x1ZGVzKDUpID8gdHJ1ZSA6IGZhbHNlXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC8vY2FsY3VsYXRlUHJpY2UocHJvcHMub3JkZXJEYXRhLnNlcnZpY2VzLCBwcm9wcy5vcmRlckRhdGEuY2FyTW9kZWwpXHJcblxyXG4gICAgICAgICAgICBzZXREYXRlKG1vbWVudEphbGFhbGkocHJvcHMub3JkZXJEYXRhLmRhdGUpLCAnallZWVkvak0vakQnKVxyXG4gICAgICAgICAgICBzZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgZGF0ZTogcHJvcHMub3JkZXJEYXRhLmRhdGV9KTtcclxuICAgICAgICAgICAgc2V0VGltZXModGltZXNIb2xkZXIubWFwKCh0aW1lLCBpbmRleCkgPT5cclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSBrZXk9e2luZGV4fSB2YWx1ZT17dGltZX0+e3RpbWV9PC9NZW51SXRlbT5cclxuICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgdmFsaWRhdGUodHJ1ZSlcclxuICAgICAgICAgICAgc2V0VGltZShwcm9wcy5vcmRlckRhdGEudGltZSlcclxuICAgICAgICAgICAgc2V0VGltZUVuZChwcm9wcy5vcmRlckRhdGEuZW5kVGltZSlcclxuICAgICAgICAgICAgY2FsY3VsYXRlUHJpY2UocHJvcHMub3JkZXJEYXRhLnNlcnZpY2VzLCBwcm9wcy5vcmRlckRhdGEuY2FyTW9kZWwpXHJcbiAgICAgICAgICAgIHNldFByaWNlKHByb3BzLm9yZGVyRGF0YS5wcmljZSlcclxuICAgICAgICAgICAgc2V0VG9nZ2xlKHByb3BzLm9yZGVyRGF0YS5hYnNlbmNlKVxyXG4gICAgICAgICAgICBpZiAocHJvcHMub3JkZXJEYXRhLmNhclRhZyAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0YWcgPSBwcm9wcy5vcmRlckRhdGEuY2FyVGFnLnNwbGl0KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0Q2FyVGFnKHByb3BzLm9yZGVyRGF0YS5jYXJUYWcpXHJcbiAgICAgICAgICAgICAgICBzZXROdW0wKHRhZ1swXSlcclxuICAgICAgICAgICAgICAgIHNldE51bTEodGFnWzFdKVxyXG4gICAgICAgICAgICAgICAgc2V0TnVtMihwcm9wcy5vcmRlckRhdGEuY2FyVGFnWzJdKVxyXG4gICAgICAgICAgICAgICAgc2V0TnVtMyhwcm9wcy5vcmRlckRhdGEuY2FyVGFnWzNdKVxyXG4gICAgICAgICAgICAgICAgc2V0TnVtNChwcm9wcy5vcmRlckRhdGEuY2FyVGFnWzRdKVxyXG4gICAgICAgICAgICAgICAgc2V0TnVtNShwcm9wcy5vcmRlckRhdGEuY2FyVGFnWzVdKVxyXG4gICAgICAgICAgICAgICAgc2V0TnVtNihwcm9wcy5vcmRlckRhdGEuY2FyVGFnWzZdKVxyXG4gICAgICAgICAgICAgICAgc2V0TnVtNyhwcm9wcy5vcmRlckRhdGEuY2FyVGFnWzddKVxyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAocHJvcHMub3JkZXJEYXRhLmNhcmRJbWcgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBzZXRGaWxlKHByb3BzLm9yZGVyRGF0YS5jYXJkRmlsZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHByb3BzLm9yZGVyRGF0YS5hYnNlbmNlICYmIHByb3BzLm9yZGVyRGF0YS5jYXJUYWcgIT0gdW5kZWZpbmVkICYmIHByb3BzLm9yZGVyRGF0YS5jYXJkSW1nICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgc2V0U2hvd0Nhckl0ZW1zKHRydWUpXHJcbiAgICAgICAgICAgICAgICBzZXRUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBzZXRUb29TaG9veWlDbGFzcyhcImZhbHNlIGRpc2FibGVkXCIpXHJcbiAgICAgICAgICAgICAgICBzZXREYXNoYm9hcmRXYXgoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBzZXREYXNoYm9hcmRXYXhDbGFzcyhcImZhbHNlIGRpc2FibGVkXCIpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgdCA9IG1vbWVudEphbGFhbGkoKS5hZGQoMCwgJ2RheXMnKVxyXG4gICAgICAgICAgICBzZXREYXRlKHQsICdqWVlZWS9qTS9qRCcpXHJcbiAgICAgICAgICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiZGF0ZXBpY2tlci1pbnB1dFwiKVswXSAhPSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiZGF0ZXBpY2tlci1pbnB1dFwiKVswXS5zZXRBdHRyaWJ1dGUoXCJyZWFkb25seVwiLCBcInJlYWRvbmx5XCIpO1xyXG4gICAgICAgICAgICB0aW1lc0hhbmRsZXIodCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW10pXHJcblxyXG4gICAgZnVuY3Rpb24gaXNFbXB0eShvYmopIHtcclxuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5sZW5ndGggPT09IDA7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHRva2VuID0gbnVsbDtcclxuICAgIGxldCBvcmRlcnNDb3VudCA9IDBcclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICB0b2tlbiA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2FjY2Vzc1Rva2VuJykpO1xyXG4gICAgICAgIG9yZGVyc0NvdW50ID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnb3JkZXJzJykpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgZmV0Y2hDYXJzID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxyXG4gICAgICAgIGNvbnN0IHByb21pc2UgPSB3aW5kb3dcclxuICAgICAgICAgICAgLmZldGNoKHVybCArICcvdXNlcl9jYXInLCB7XHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2VwdCc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdkYXRhVHlwZSc6ICdqc29ucCcsICAgLy95b3UgbWF5IHVzZSBqc29ucCBmb3IgY3Jvc3Mgb3JpZ2luIHJlcXVlc3RcclxuICAgICAgICAgICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIgKyB0b2tlblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgICAgICAgICAgICBtb2RlOiAnY29ycycsXHJcbiAgICAgICAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpXHJcbiAgICAgICAgICAgIC50aGVuKHJlc3BvbnNlSnNvbiA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2VKc29uLm1lc3NhZ2UgPT0gXCLZhdin2LTbjNmG4oCM2YfYpyDYqNinINmF2YjZgdmC24zYqiDYr9ix24zYp9mB2Kog2LTYry5cIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldENhcnNIb2xkZXIocmVzcG9uc2VKc29uLnVzZXJfY2FycylcclxuICAgICAgICAgICAgICAgICAgICBsZXQgeCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlSnNvbi51c2VyX2NhcnMubWFwKChjYXIsIGluZGV4KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXIubmFtZSAhPSBcIlwiID8geC5wdXNoKHt0aXRsZTogY2FyLm1vZGVsLm5hbWUsIGlkOiBjYXIuaWR9KSA6IG51bGxcclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2Fycyh4KVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghaXNFbXB0eShwcm9wcy5vcmRlckRhdGEpKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJvcHMub3JkZXJEYXRhLnNlbGVjdGVkQ2FyID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXIocHJvcHMub3JkZXJEYXRhLnNlbGVjdGVkQ2FyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FyTW9kZWwocHJvcHMub3JkZXJEYXRhLnNlbGVjdGVkQ2FyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXNwb25zZUpzb24udXNlcl9jYXJzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZUpzb24udXNlcl9jYXJzW2ldLmlkID09IHByb3BzLm9yZGVyRGF0YS5zZWxlY3RlZENhcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZENhclRpdGxlKHJlc3BvbnNlSnNvbi51c2VyX2NhcnNbaV0ubW9kZWwubmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXJJc1NlbGVjdGVkKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9wcy5vcmRlckRhdGEuY2FyVGFnID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FyVGFnKHJlc3BvbnNlSnNvbi51c2VyX2NhcnNbaV0ucGxhcXVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TnVtMChyZXNwb25zZUpzb24udXNlcl9jYXJzW2ldLnBsYXF1ZVswXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE51bTEocmVzcG9uc2VKc29uLnVzZXJfY2Fyc1tpXS5wbGFxdWVbMV0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXROdW0yKHJlc3BvbnNlSnNvbi51c2VyX2NhcnNbaV0ucGxhcXVlWzJdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TnVtMyhyZXNwb25zZUpzb24udXNlcl9jYXJzW2ldLnBsYXF1ZVszXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE51bTQocmVzcG9uc2VKc29uLnVzZXJfY2Fyc1tpXS5wbGFxdWVbNF0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXROdW01KHJlc3BvbnNlSnNvbi51c2VyX2NhcnNbaV0ucGxhcXVlWzVdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TnVtNihyZXNwb25zZUpzb24udXNlcl9jYXJzW2ldLnBsYXF1ZVs2XSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE51bTcocmVzcG9uc2VKc29uLnVzZXJfY2Fyc1tpXS5wbGFxdWVbN10pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BzLm9yZGVyRGF0YS5jYXJkSW1nID09IHVuZGVmaW5lZCkgc2V0RmlsZShyZXNwb25zZUpzb24udXNlcl9jYXJzW2ldLmNhcmRfaW1hZ2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dDYXJJdGVtcyh0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDYXJCcmFuZFRpdGxlKHJlc3BvbnNlSnNvbi51c2VyX2NhcnNbaV0ubW9kZWwuYnJhbmQubmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENhck1vZGVsVGl0bGUocmVzcG9uc2VKc29uLnVzZXJfY2Fyc1tpXS5tb2RlbC5uYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXJCcmFuZFRpdGxlKHJlc3BvbnNlSnNvbi51c2VyX2NhcnNbaV0ubW9kZWwuYnJhbmQubmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXJNb2RlbFRpdGxlKHJlc3BvbnNlSnNvbi51c2VyX2NhcnNbaV0ubW9kZWwubmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGUodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgLy8gQ2FuY2VsIHRoZSByZXF1ZXN0IGlmIGl0IHRha2VzIG1vcmUgdGhhbiBkZWxheUZldGNoIHNlY29uZHNcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGFib3J0Q29udHJvbGxlci5hYm9ydCgpLCBwcm9jZXNzLmVudi5kZWxheUZldGNoKVxyXG4gICAgfTtcclxuICAgIGNvbnN0IHZhbGlkYXRlID0gKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgIGlmIChyZXN1bHQpIHtcclxuICAgICAgICAgICAgc2V0QnRuRGlzYWJsZWQoZmFsc2UpXHJcbiAgICAgICAgfSBlbHNlIHNldEJ0bkRpc2FibGVkKHRydWUpXHJcbiAgICB9XHJcbiAgICBjb25zdCBmZXRjaENhck1vZGVscyA9IChpZCkgPT4ge1xyXG4gICAgICAgIGxldCBxID0gXCJcIjtcclxuICAgICAgICBpZiAoaWQgPT0gXCJcIilcclxuICAgICAgICAgICAgcSA9IFwiXCJcclxuICAgICAgICBlbHNlIHEgPSAnP2JyYW5kX2lkPScgKyBpZFxyXG4gICAgICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxyXG4gICAgICAgIGNvbnN0IHByb21pc2UgPSB3aW5kb3dcclxuICAgICAgICAgICAgLmZldGNoKHVybCArICcvY2Fycy9tb2RlbHMnICsgcSwge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBY2NlcHQnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnZGF0YVR5cGUnOiAnanNvbnAnLCAgIC8veW91IG1heSB1c2UganNvbnAgZm9yIGNyb3NzIG9yaWdpbiByZXF1ZXN0XHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgICAgICAgICAgICAgbW9kZTogJ2NvcnMnLFxyXG4gICAgICAgICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC50aGVuKHJlcyA9PiByZXMuanNvbigpKVxyXG4gICAgICAgICAgICAudGhlbihyZXNwb25zZUpzb24gPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlSnNvbi5tZXNzYWdlID09IFwi2YXYr9mE4oCM2YfYpyDYqNinINmF2YjZgdmC24zYqiDYr9ix24zYp9mB2Kog2LTYry5cIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldENhck1vZGVscyhyZXNwb25zZUpzb24ubW9kZWxzKVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghaXNFbXB0eShwcm9wcy5vcmRlckRhdGEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9wcy5vcmRlckRhdGEuc2VsZWN0ZWRDYXIgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDYXJCcmFuZCgwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FyTW9kZWwocHJvcHMub3JkZXJEYXRhLnNlbGVjdGVkQ2FyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FyQnJhbmRUaXRsZShcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FyTW9kZWxUaXRsZShcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3JkZXJEYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5vcmRlckRhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRDYXI6IHByb3BzLm9yZGVyRGF0YS5zZWxlY3RlZENhcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXJNb2RlbDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlbFRpdGxlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhckJyYW5kOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyYW5kVGl0bGU6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZENhcklzU2VsZWN0ZWQodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENhck1vZGVsKHByb3BzLm9yZGVyRGF0YS5jYXJNb2RlbClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENhck1vZGVsVGl0bGUocHJvcHMub3JkZXJEYXRhLm1vZGVsVGl0bGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRPcmRlckRhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLm9yZGVyRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZENhcjogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXJNb2RlbDogcHJvcHMub3JkZXJEYXRhLmNhck1vZGVsLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGVsVGl0bGU6IHByb3BzLm9yZGVyRGF0YS5tb2RlbFRpdGxlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhckJyYW5kOiBwcm9wcy5vcmRlckRhdGEuY2FyQnJhbmQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJhbmRUaXRsZTogcHJvcHMub3JkZXJEYXRhLmJyYW5kVGl0bGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0ZSh0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgLy8gQ2FuY2VsIHRoZSByZXF1ZXN0IGlmIGl0IHRha2VzIG1vcmUgdGhhbiBkZWxheUZldGNoIHNlY29uZHNcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGFib3J0Q29udHJvbGxlci5hYm9ydCgpLCBwcm9jZXNzLmVudi5kZWxheUZldGNoKVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVzZXQgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0U2VydmljZXNUaXRsZShbXSlcclxuICAgICAgICBzZXRTZXJ2aWNlcyhbXSlcclxuICAgICAgICBzZXRQcmljZShcIi4uLlwiKVxyXG4gICAgICAgIHNldFNob3dDYXJJdGVtcyhmYWxzZSlcclxuICAgICAgICBzZXRGaWxlKFwiXCIpXHJcbiAgICAgICAgc2V0Q2FyVGFnKFwiXCIpXHJcbiAgICAgICAgc2V0U2hvd0Nhckl0ZW1zKGZhbHNlKVxyXG4gICAgICAgIHNldFRvZ2dsZShmYWxzZSlcclxuICAgICAgICBzZXRSb29TaG95aShmYWxzZSlcclxuICAgICAgICBzZXRSb29TaG95aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICBzZXRUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgc2V0VG9vU2hvb3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpKGZhbHNlKVxyXG4gICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgIHNldERhc2hib2FyZFdheChmYWxzZSlcclxuICAgICAgICBzZXREYXNoYm9hcmRXYXhDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgc2V0TGFzdGlrV2F4KGZhbHNlKVxyXG4gICAgICAgIHNldExhc3Rpa1dheENsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICBzZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgYWJzZW5jZTogMH0pXHJcbiAgICAgICAgc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgcm9vU2hveWk6IGZhbHNlLFxyXG4gICAgICAgICAgICB0b29TaG9veWk6IGZhbHNlLFxyXG4gICAgICAgICAgICByb29TaG95aVRvb1Nob295aTogZmFsc2UsXHJcbiAgICAgICAgICAgIGRhc2hib2FyZFdheDogZmFsc2UsXHJcbiAgICAgICAgICAgIGxhc3Rpa1dheDogZmFsc2VcclxuICAgICAgICB9KVxyXG4gICAgICAgIC8qcmVzZXRUb2dnbGVTdGF0ZSgpKi9cclxuICAgIH1cclxuICAgIGNvbnN0IGNhckJyYW5kSGFuZGxlciA9IChlLCB2YWx1ZSkgPT4ge1xyXG4gICAgICAgIGlmICh2YWx1ZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHNldEZpbGUoXCJcIilcclxuICAgICAgICAgICAgc2V0Q2FyVGFnKFwiXCIpXHJcbiAgICAgICAgICAgIHNldENhck1vZGVsKDApXHJcbiAgICAgICAgICAgIHNldENhck1vZGVsVGl0bGUoXCJcIilcclxuICAgICAgICAgICAgc2V0Q2FyQnJhbmQoMClcclxuICAgICAgICAgICAgc2V0Q2FyQnJhbmRUaXRsZShcIlwiKVxyXG4gICAgICAgICAgICBmZXRjaENhck1vZGVscyhcIlwiKVxyXG4gICAgICAgICAgICByZXNldCgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGxldCBjQnJhbmQgPSAwXHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2FyQnJhbmRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2FyQnJhbmRzW2ldLm5hbWUgPT0gdmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjQnJhbmQgPSBjYXJCcmFuZHNbaV0uaWRcclxuICAgICAgICAgICAgICAgICAgICBzZXRDYXJCcmFuZFRpdGxlKGNhckJyYW5kc1tpXS5uYW1lKVxyXG4gICAgICAgICAgICAgICAgICAgIGZldGNoQ2FyTW9kZWxzKGNCcmFuZClcclxuICAgICAgICAgICAgICAgICAgICBzZXRDYXJCcmFuZChjQnJhbmQpXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2FyTW9kZWxUaXRsZShcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldENhck1vZGVsKDApO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldE9yZGVyRGF0YSh7Li4ub3JkZXJEYXRhLCBjYXJCcmFuZDogY0JyYW5kLCBicmFuZFRpdGxlOiBjYXJCcmFuZHNbaV0ubmFtZX0pXHJcbiAgICAgICAgICAgICAgICAgICAgLyppZiAoc2VydmljZXMubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FsY3VsYXRlUHJpY2Uoc2VydmljZXMpKi9cclxuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzdWx0ID0gKChjQnJhbmQgIT0gMCAmJiBjYXJNb2RlbCAhPSAwKSB8fCBzZWxlY3RlZENhciAhPSAwKSAmJiBkYXRlICE9IFwiXCIgJiYgdGltZSAhPSBcIlwiICYmIHNlcnZpY2VzLmxlbmd0aCA+IDAgJiYgaXNUb29PclJvb1NlbGVjdGVkO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlKHJlc3VsdCk7XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIGNvbnN0IGNhck1vZGVsSGFuZGxlciA9IChlLCB2YWx1ZSkgPT4ge1xyXG4gICAgICAgIGxldCBjTW9kZWwgPSAwXHJcbiAgICAgICAgbGV0IGNUaXRsZSA9IFwiXCI7XHJcbiAgICAgICAgbGV0IGNCcmFuZCA9IDA7XHJcbiAgICAgICAgbGV0IGNCcmFuZFRpdGxlID0gXCJcIjtcclxuICAgICAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBzZXRGaWxlKFwiXCIpXHJcbiAgICAgICAgICAgIHNldENhclRhZyhcIlwiKVxyXG4gICAgICAgICAgICBzZXRDYXJNb2RlbCgwKVxyXG4gICAgICAgICAgICBzZXRDYXJNb2RlbFRpdGxlKFwiXCIpXHJcbiAgICAgICAgICAgIC8qc2V0Q2FyQnJhbmQoMClcclxuICAgICAgICAgICAgc2V0Q2FyQnJhbmRUaXRsZShcIlwiKSovXHJcbiAgICAgICAgICAgIHJlc2V0KCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjYXJNb2RlbHMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChjYXJNb2RlbHNbaV0ubmFtZSA9PSB2YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNNb2RlbCA9IGNhck1vZGVsc1tpXS5pZDtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDYXJNb2RlbFRpdGxlKGNhck1vZGVsc1tpXS5uYW1lKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldENhck1vZGVsKGNNb2RlbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY1RpdGxlID0gY2FyTW9kZWxzW2ldLm5hbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgY0JyYW5kID0gY2FyTW9kZWxzW2ldLmJyYW5kX2lkO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldENhckJyYW5kKGNhck1vZGVsc1tpXS5icmFuZF9pZClcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGNhckJyYW5kcy5sZW5ndGg7IGorKylcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNhck1vZGVsc1tpXS5icmFuZF9pZCA9PSBjYXJCcmFuZHNbal0uaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENhckJyYW5kVGl0bGUoY2FyQnJhbmRzW2pdLm5hbWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjQnJhbmRUaXRsZSA9IGNhckJyYW5kc1tqXS5uYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvL3NldE9yZGVyRGF0YSh7Li4ub3JkZXJEYXRhLCBjYXJNb2RlbDogY01vZGVsLCBtb2RlbFRpdGxlOiBjYXJNb2RlbHNbaV0ubmFtZX0pXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlcnZpY2VzLmxlbmd0aCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGN1bGF0ZVByaWNlKHNlcnZpY2VzLCBjTW9kZWwpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGNCcmFuZFRpdGxlID09IFwiXCIpXHJcbiAgICAgICAgICAgIHNldE9yZGVyRGF0YSh7Li4ub3JkZXJEYXRhLCBzZWxlY3RlZENhcjogMCwgY2FyTW9kZWw6IGNNb2RlbCwgbW9kZWxUaXRsZTogY1RpdGxlfSlcclxuICAgICAgICBlbHNlIHNldE9yZGVyRGF0YSh7XHJcbiAgICAgICAgICAgIC4uLm9yZGVyRGF0YSxcclxuICAgICAgICAgICAgc2VsZWN0ZWRDYXI6IDAsXHJcbiAgICAgICAgICAgIGNhck1vZGVsOiBjTW9kZWwsXHJcbiAgICAgICAgICAgIG1vZGVsVGl0bGU6IGNUaXRsZSxcclxuICAgICAgICAgICAgY2FyQnJhbmQ6IGNCcmFuZCxcclxuICAgICAgICAgICAgYnJhbmRUaXRsZTogY0JyYW5kVGl0bGVcclxuICAgICAgICB9KVxyXG4gICAgICAgIGxldCByZXN1bHQgPSAoKGNhckJyYW5kICE9IDAgJiYgY01vZGVsICE9IDApIHx8IHNlbGVjdGVkQ2FyICE9IDApICYmIGRhdGUgIT0gXCJcIiAmJiB0aW1lICE9IFwiXCIgJiYgc2VydmljZXMubGVuZ3RoID4gMCAmJiBpc1Rvb09yUm9vU2VsZWN0ZWQ7XHJcbiAgICAgICAgdmFsaWRhdGUocmVzdWx0KTtcclxuICAgIH1cclxuICAgIGNvbnN0IHNlbGVjdGVkQ2FySGFuZGxlciA9IChlLCB2YWx1ZSkgPT4ge1xyXG4gICAgICAgIGxldCBjU2VsZWN0ZWQgPSAwO1xyXG4gICAgICAgIGxldCBjU2VsZWN0ZWRUaXRsZSA9IFwiXCI7XHJcbiAgICAgICAgbGV0IGNQbGFxdWUgPSBcIlwiO1xyXG4gICAgICAgIGxldCBjRmlsZSA9IFwiXCI7XHJcbiAgICAgICAgbGV0IGNNb2RlbCA9IFwiXCJcclxuICAgICAgICBzZXRGaWxlKFwiXCIpXHJcbiAgICAgICAgc2V0Q2FyVGFnKFwiXCIpXHJcbiAgICAgICAgc2V0U2VsZWN0ZWRDYXIoMClcclxuICAgICAgICBzZXRTZWxlY3RlZENhclRpdGxlKFwiXCIpXHJcbiAgICAgICAgaWYgKHZhbHVlID09IG51bGwpIHtcclxuICAgICAgICAgICAgc2V0RmlsZShcIlwiKVxyXG4gICAgICAgICAgICBzZXRDYXJUYWcoXCJcIilcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXIoMClcclxuICAgICAgICAgICAgcmVzZXQoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNhcnNIb2xkZXIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZSAhPSBudWxsICYmIGNhcnNIb2xkZXJbaV0ubW9kZWwubmFtZSA9PSB2YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNTZWxlY3RlZCA9IGNhcnNIb2xkZXJbaV0uaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgY1BsYXF1ZSA9IGNhcnNIb2xkZXJbaV0ucGxhcXVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGNNb2RlbCA9IGNhcnNIb2xkZXJbaV0uY2FyX21vZGVsX2lkO1xyXG4gICAgICAgICAgICAgICAgICAgIGNGaWxlID0gY2Fyc0hvbGRlcltpXS5jYXJkX2ltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RmlsZShjYXJzSG9sZGVyW2ldLmNhcmRfaW1hZ2UpXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXJUaXRsZShjYXJzSG9sZGVyW2ldLm1vZGVsLm5hbWUpXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXJCcmFuZFRpdGxlKGNhcnNIb2xkZXJbaV0ubW9kZWxbXCJicmFuZFwiXS5uYW1lKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ2FyTW9kZWxUaXRsZShjYXJzSG9sZGVyW2ldLm1vZGVsLm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldENhclRhZyhjUGxhcXVlKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNQbGFxdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgaWYoY1BsYXF1ZSE9XCJcIilcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW0wKGNQbGFxdWVbMF0pXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TnVtMShjUGxhcXVlWzFdKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldE51bTIoY1BsYXF1ZVsyXSlcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW0zKGNQbGFxdWVbM10pXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TnVtNChjUGxhcXVlWzRdKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldE51bTUoY1BsYXF1ZVs1XSlcclxuICAgICAgICAgICAgICAgICAgICBzZXROdW02KGNQbGFxdWVbNl0pXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TnVtNyhjUGxhcXVlWzddKVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93Q2FySXRlbXModHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICBzZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgc2VsZWN0ZWRDYXI6IDAsIGNhck1vZGVsOiBjTW9kZWx9KVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChzZXJ2aWNlcy5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGVQcmljZShzZXJ2aWNlcywgY01vZGVsKVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoY1NlbGVjdGVkICE9IDApIHtcclxuICAgICAgICAgICAgc2V0Q2FyQnJhbmQoMClcclxuICAgICAgICAgICAgc2V0Q2FyTW9kZWwoMClcclxuICAgICAgICAgICAgc2V0Q2FyQnJhbmRUaXRsZShcIlwiKVxyXG4gICAgICAgICAgICBzZXRDYXJNb2RlbFRpdGxlKFwiXCIpXHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkQ2FySXNTZWxlY3RlZCh0cnVlKVxyXG4gICAgICAgIH0gZWxzZSBzZXRTZWxlY3RlZENhcklzU2VsZWN0ZWQoZmFsc2UpXHJcbiAgICAgICAgc2V0U2VsZWN0ZWRDYXIoY1NlbGVjdGVkKVxyXG4gICAgICAgIHNldENhck1vZGVsKGNNb2RlbClcclxuICAgICAgICBzZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgc2VsZWN0ZWRDYXI6IGNTZWxlY3RlZCwgY2FyTW9kZWw6IGNNb2RlbH0pXHJcbiAgICAgICAgbGV0IHJlc3VsdCA9ICgoY2FyQnJhbmQgIT0gMCAmJiBjYXJNb2RlbCAhPSAwKSB8fCBjU2VsZWN0ZWQgIT0gMCkgJiYgZGF0ZSAhPSBcIlwiICYmIHRpbWUgIT0gXCJcIiAmJiBzZXJ2aWNlcy5sZW5ndGggPiAwICYmIGlzVG9vT3JSb29TZWxlY3RlZDtcclxuICAgICAgICB2YWxpZGF0ZShyZXN1bHQpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgdG9nZ2xlU3RhdGUgPSAoZSkgPT4ge1xyXG4gICAgICAgIHNldFNlcnZpY2VzKFtdKVxyXG4gICAgICAgIHNldFNlcnZpY2VzVGl0bGUoW10pXHJcbiAgICAgICAgc2V0UHJpY2UoXCIuLi5cIilcclxuICAgICAgICBjb25zb2xlLmxvZyhlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICBpZiAoZS50YXJnZXQudmFsdWUgPT0gXCLYqNmE2YdcIikge1xyXG4gICAgICAgICAgICBzZXRUb2dnbGUodHJ1ZSlcclxuICAgICAgICAgICAgc2V0Um9vU2hveWkoZmFsc2UpXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICBzZXRUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgICAgIHNldFRvb1Nob295aUNsYXNzKFwiZmFsc2UgZGlzYWJsZWRcIilcclxuICAgICAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MoXCJmYWxzZSBkaXNhYmxlZFwiKVxyXG4gICAgICAgICAgICBzZXREYXNoYm9hcmRXYXgoZmFsc2UpXHJcbiAgICAgICAgICAgIHNldERhc2hib2FyZFdheENsYXNzKFwiZmFsc2UgZGlzYWJsZWRcIilcclxuICAgICAgICAgICAgc2V0TGFzdGlrV2F4KGZhbHNlKVxyXG4gICAgICAgICAgICBzZXRMYXN0aWtXYXhDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgICAgIHNldE9yZGVyRGF0YSh7Li4ub3JkZXJEYXRhLCBhYnNlbmNlOiAxfSlcclxuICAgICAgICAgICAgc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICByb29TaG95aTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICB0b29TaG9veWk6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgcm9vU2hveWlUb29TaG9veWk6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgZGFzaGJvYXJkV2F4OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGxhc3Rpa1dheDogZmFsc2VcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLy9pZihzZWxlY3RlZENhcj09MClcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpXHJcbiAgICAgICAgfSBlbHNlIGlmIChlLnRhcmdldC52YWx1ZSA9PSBcItiu24zYsVwiKSB7XHJcbiAgICAgICAgICAgIHNldFNob3dDYXJJdGVtcyhmYWxzZSlcclxuICAgICAgICAgICAgc2V0VG9nZ2xlKGZhbHNlKVxyXG4gICAgICAgICAgICBzZXRSb29TaG95aShmYWxzZSlcclxuICAgICAgICAgICAgc2V0Um9vU2hveWlDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgICAgIHNldFRvb1Nob295aShmYWxzZSlcclxuICAgICAgICAgICAgc2V0VG9vU2hvb3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICBzZXRSb29TaG95aVRvb1Nob295aShmYWxzZSlcclxuICAgICAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWlDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgICAgIHNldERhc2hib2FyZFdheChmYWxzZSlcclxuICAgICAgICAgICAgc2V0RGFzaGJvYXJkV2F4Q2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICBzZXRMYXN0aWtXYXgoZmFsc2UpXHJcbiAgICAgICAgICAgIHNldExhc3Rpa1dheENsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICAgICAgc2V0T3JkZXJEYXRhKHsuLi5vcmRlckRhdGEsIGFic2VuY2U6IDB9KVxyXG4gICAgICAgICAgICBzZXRTdGF0ZSh7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIHJvb1Nob3lpOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIHRvb1Nob295aTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICByb29TaG95aVRvb1Nob295aTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBkYXNoYm9hcmRXYXg6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgbGFzdGlrV2F4OiBmYWxzZVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGNvbnN0IHJlc2V0VG9nZ2xlU3RhdGUgPSAodmFsdWUpID0+IHtcclxuICAgICAgICBzZXRTZXJ2aWNlcyhbXSlcclxuICAgICAgICBzZXRTZXJ2aWNlc1RpdGxlKFtdKVxyXG4gICAgICAgIHNldFByaWNlKFwiLi4uXCIpXHJcblxyXG4gICAgICAgIHNldFNob3dDYXJJdGVtcyhmYWxzZSlcclxuICAgICAgICBzZXRUb2dnbGUoZmFsc2UpXHJcbiAgICAgICAgc2V0Um9vU2hveWkoZmFsc2UpXHJcbiAgICAgICAgc2V0Um9vU2hveWlDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgc2V0VG9vU2hvb3lpKGZhbHNlKVxyXG4gICAgICAgIHNldFRvb1Nob295aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICBzZXRSb29TaG95aVRvb1Nob295aShmYWxzZSlcclxuICAgICAgICBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICBzZXREYXNoYm9hcmRXYXgoZmFsc2UpXHJcbiAgICAgICAgc2V0RGFzaGJvYXJkV2F4Q2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgIHNldExhc3Rpa1dheChmYWxzZSlcclxuICAgICAgICBzZXRMYXN0aWtXYXhDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgc2V0T3JkZXJEYXRhKHsuLi5vcmRlckRhdGEsIGFic2VuY2U6IDB9KVxyXG4gICAgICAgIHNldFN0YXRlKHtcclxuICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgIHJvb1Nob3lpOiBmYWxzZSxcclxuICAgICAgICAgICAgdG9vU2hvb3lpOiBmYWxzZSxcclxuICAgICAgICAgICAgcm9vU2hveWlUb29TaG9veWk6IGZhbHNlLFxyXG4gICAgICAgICAgICBkYXNoYm9hcmRXYXg6IGZhbHNlLFxyXG4gICAgICAgICAgICBsYXN0aWtXYXg6IGZhbHNlXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcmVtb3ZlSXRlbU9uY2UoYXJyLCB2YWx1ZSkge1xyXG4gICAgICAgIHZhciBpbmRleCA9IGFyci5pbmRleE9mKHZhbHVlKTtcclxuICAgICAgICBpZiAoaW5kZXggPiAtMSkge1xyXG4gICAgICAgICAgICBhcnIuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGFycjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzZXJ2aWNlc0hhbmRsZXIgPSAoZXZlbnQpID0+IHtcclxuICAgICAgICBsZXQgX3NlcnZpY2VzID0gey4uLnN0YXRlLCBbZXZlbnQudGFyZ2V0Lm5hbWVdOiBldmVudC50YXJnZXQuY2hlY2tlZH1cclxuICAgICAgICBsZXQgX3NlbGVjdGVkU2VydmljZXMgPSBbXTtcclxuICAgICAgICBsZXQgX3NlbGVjdGVkU2VydmljZXNUaXRsZSA9IFtdXHJcbiAgICAgICAgbGV0IF9yb29TaG95aSwgX3Rvb1Nob295aSwgX3Jvb1Nob3lpVG9vU2hvb3lpLCBfbGFzdGlrV2F4LCBfZGFzaGJvYXJkV2F4O1xyXG4gICAgICAgIGlmIChfc2VydmljZXNbXCJyb29TaG95aVwiXSkge1xyXG4gICAgICAgICAgICBzZXRSb29TaG95aSh0cnVlKVxyXG4gICAgICAgICAgICBzZXRSb29TaG95aUNsYXNzKFwidHJ1ZVwiKVxyXG4gICAgICAgICAgICBfc2VsZWN0ZWRTZXJ2aWNlcy5wdXNoKDEpXHJcbiAgICAgICAgICAgIF9zZWxlY3RlZFNlcnZpY2VzVGl0bGUucHVzaChcItix2YjYtNmI24zbjFwiKVxyXG4gICAgICAgICAgICBfcm9vU2hveWkgPSB0cnVlXHJcbiAgICAgICAgICAgIF9yb29TaG95aVRvb1Nob295aSA9IGZhbHNlXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpKGZhbHNlKVxyXG4gICAgICAgICAgICBpZiAodG9nZ2xlKVxyXG4gICAgICAgICAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWlDbGFzcyhcImZhbHNlIGRpc2FibGVkXCIpXHJcbiAgICAgICAgICAgIGVsc2Ugc2V0Um9vU2hveWlUb29TaG9veWlDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVtb3ZlSXRlbU9uY2UoX3NlbGVjdGVkU2VydmljZXMsIDEpXHJcbiAgICAgICAgICAgIHJlbW92ZUl0ZW1PbmNlKF9zZWxlY3RlZFNlcnZpY2VzVGl0bGUsIFwi2LHZiNi02YjbjNuMXCIpXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpKGZhbHNlKVxyXG4gICAgICAgICAgICBzZXRSb29TaG95aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgICAgIGlmICh0b2dnbGUpXHJcbiAgICAgICAgICAgICAgICBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzKFwiZmFsc2UgZGlzYWJsZWRcIilcclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBfcm9vU2hveWkgPSBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NlcnZpY2VzW1widG9vU2hvb3lpXCJdKSB7XHJcbiAgICAgICAgICAgIHNldFRvb1Nob295aSh0cnVlKVxyXG4gICAgICAgICAgICBzZXRUb29TaG9veWlDbGFzcyhcInRydWVcIilcclxuICAgICAgICAgICAgX3NlbGVjdGVkU2VydmljZXMucHVzaCgyKVxyXG4gICAgICAgICAgICBfc2VsZWN0ZWRTZXJ2aWNlc1RpdGxlLnB1c2goXCLYqtmI2LTZiNuM24xcIilcclxuICAgICAgICAgICAgX3Rvb1Nob295aSA9IHRydWVcclxuICAgICAgICAgICAgX3Jvb1Nob3lpVG9vU2hvb3lpID0gZmFsc2VcclxuICAgICAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MoXCJmYWxzZSBkaXNhYmxlZFwiKVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlbW92ZUl0ZW1PbmNlKF9zZWxlY3RlZFNlcnZpY2VzLCAyKVxyXG4gICAgICAgICAgICByZW1vdmVJdGVtT25jZShfc2VsZWN0ZWRTZXJ2aWNlc1RpdGxlLCBcItiq2YjYtNmI24zbjFwiKVxyXG4gICAgICAgICAgICBpZiAoIXRvZ2dsZSkge1xyXG4gICAgICAgICAgICAgICAgc2V0VG9vU2hvb3lpKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgc2V0VG9vU2hvb3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBpZiAodG9nZ2xlKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MoXCJmYWxzZSBkaXNhYmxlZFwiKVxyXG4gICAgICAgICAgICAgICAgZWxzZSBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICAgICAgICAgIF90b29TaG9veWkgPSBmYWxzZVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgc2V0VG9vU2hvb3lpKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgc2V0VG9vU2hvb3lpQ2xhc3MoXCJmYWxzZSBkaXNhYmxlZFwiKVxyXG4gICAgICAgICAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBpZiAodG9nZ2xlKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MoXCJmYWxzZSBkaXNhYmxlZFwiKVxyXG4gICAgICAgICAgICAgICAgZWxzZSBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICAgICAgICAgIF90b29TaG9veWkgPSBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NlcnZpY2VzW1wicm9vU2hveWlUb29TaG9veWlcIl0pIHtcclxuICAgICAgICAgICAgX3NlbGVjdGVkU2VydmljZXMucHVzaCgzKVxyXG4gICAgICAgICAgICBfc2VsZWN0ZWRTZXJ2aWNlc1RpdGxlLnB1c2goXCLYsdmI2LTZiNuM24wt2KrZiNi02YjbjNuMXCIpXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpKHRydWUpXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MoXCJ0cnVlXCIpXHJcbiAgICAgICAgICAgIHNldFJvb1Nob3lpKGZhbHNlKVxyXG4gICAgICAgICAgICBzZXRSb29TaG95aUNsYXNzKFwiZmFsc2UgZGlzYWJsZWRcIilcclxuICAgICAgICAgICAgc2V0VG9vU2hvb3lpKGZhbHNlKVxyXG4gICAgICAgICAgICBzZXRUb29TaG9veWlDbGFzcyhcImZhbHNlIGRpc2FibGVkXCIpXHJcbiAgICAgICAgICAgIF9yb29TaG95aVRvb1Nob295aSA9IHRydWVcclxuICAgICAgICAgICAgX3Jvb1Nob3lpID0gZmFsc2VcclxuICAgICAgICAgICAgX3Rvb1Nob295aSA9IGZhbHNlXHJcbiAgICAgICAgICAgIHJlbW92ZUl0ZW1PbmNlKF9zZWxlY3RlZFNlcnZpY2VzLCAxKVxyXG4gICAgICAgICAgICByZW1vdmVJdGVtT25jZShfc2VsZWN0ZWRTZXJ2aWNlcywgMilcclxuICAgICAgICAgICAgcmVtb3ZlSXRlbU9uY2UoX3NlbGVjdGVkU2VydmljZXNUaXRsZSwgXCLYsdmI2LTZiNuM24xcIilcclxuICAgICAgICAgICAgcmVtb3ZlSXRlbU9uY2UoX3NlbGVjdGVkU2VydmljZXNUaXRsZSwgXCLYqtmI2LTZiNuM24xcIilcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXRSb29TaG95aVRvb1Nob295aShmYWxzZSlcclxuICAgICAgICAgICAgaWYgKF9zZXJ2aWNlc1tcInJvb1Nob3lpXCJdIHx8IF9zZXJ2aWNlc1tcInRvb1Nob295aVwiXSlcclxuICAgICAgICAgICAgICAgIHNldFJvb1Nob3lpVG9vU2hvb3lpQ2xhc3MoXCJmYWxzZSBkaXNhYmxlZFwiKVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0b2dnbGUpXHJcbiAgICAgICAgICAgICAgICBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzKFwiZmFsc2UgZGlzYWJsZWRcIilcclxuICAgICAgICAgICAgZWxzZSBzZXRSb29TaG95aVRvb1Nob295aUNsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICAgICAgaWYgKCFfc2VydmljZXNbXCJyb29TaG95aVwiXSkge1xyXG4gICAgICAgICAgICAgICAgc2V0Um9vU2hveWkoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBpZiAodG9nZ2xlKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldFJvb1Nob3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICAgICAgX3Jvb1Nob3lpID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHJlbW92ZUl0ZW1PbmNlKF9zZWxlY3RlZFNlcnZpY2VzLCAxKVxyXG4gICAgICAgICAgICAgICAgcmVtb3ZlSXRlbU9uY2UoX3NlbGVjdGVkU2VydmljZXNUaXRsZSwgXCLYsdmI2LTZiNuM24xcIilcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIV9zZXJ2aWNlc1tcInRvb1Nob295aVwiXSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRvZ2dsZSlcclxuICAgICAgICAgICAgICAgICAgICBzZXRUb29TaG9veWlDbGFzcyhcImZhbHNlIGRpc2FibGVkXCIpXHJcbiAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0VG9vU2hvb3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICAgICAgc2V0VG9vU2hvb3lpKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgX3Rvb1Nob295aSA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICByZW1vdmVJdGVtT25jZShfc2VsZWN0ZWRTZXJ2aWNlcywgMilcclxuICAgICAgICAgICAgICAgIHJlbW92ZUl0ZW1PbmNlKF9zZWxlY3RlZFNlcnZpY2VzVGl0bGUsIFwi2KrZiNi02YjbjNuMXCIpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVtb3ZlSXRlbU9uY2UoX3NlbGVjdGVkU2VydmljZXMsIDMpXHJcbiAgICAgICAgICAgIHJlbW92ZUl0ZW1PbmNlKF9zZWxlY3RlZFNlcnZpY2VzVGl0bGUsIFwi2LHZiNi02YjbjNuMLdiq2YjYtNmI24zbjFwiKVxyXG4gICAgICAgICAgICBfcm9vU2hveWlUb29TaG9veWkgPSBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NlcnZpY2VzW1wibGFzdGlrV2F4XCJdKSB7XHJcbiAgICAgICAgICAgIHNldExhc3Rpa1dheCh0cnVlKVxyXG4gICAgICAgICAgICBzZXRMYXN0aWtXYXhDbGFzcyhcInRydWVcIilcclxuICAgICAgICAgICAgX3NlbGVjdGVkU2VydmljZXMucHVzaCg0KVxyXG4gICAgICAgICAgICBfc2VsZWN0ZWRTZXJ2aWNlc1RpdGxlLnB1c2goXCLZiNin2qnYsyDZhNin2LPYqtuM2qlcIilcclxuICAgICAgICAgICAgX2xhc3Rpa1dheCA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVtb3ZlSXRlbU9uY2UoX3NlbGVjdGVkU2VydmljZXMsIDQpXHJcbiAgICAgICAgICAgIHJlbW92ZUl0ZW1PbmNlKF9zZWxlY3RlZFNlcnZpY2VzVGl0bGUsIFwi2YjYp9qp2LMg2YTYp9iz2KrbjNqpXCIpXHJcbiAgICAgICAgICAgIHNldExhc3Rpa1dheChmYWxzZSlcclxuICAgICAgICAgICAgc2V0TGFzdGlrV2F4Q2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICBfbGFzdGlrV2F4ID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zZXJ2aWNlc1tcImRhc2hib2FyZFdheFwiXSkge1xyXG4gICAgICAgICAgICBzZXREYXNoYm9hcmRXYXgodHJ1ZSlcclxuICAgICAgICAgICAgc2V0RGFzaGJvYXJkV2F4Q2xhc3MoXCJ0cnVlXCIpXHJcbiAgICAgICAgICAgIF9zZWxlY3RlZFNlcnZpY2VzLnB1c2goNSlcclxuICAgICAgICAgICAgX3NlbGVjdGVkU2VydmljZXNUaXRsZS5wdXNoKFwi2YjYp9qp2LMg2K/Yp9i02KjZiNix2K9cIilcclxuICAgICAgICAgICAgX2Rhc2hib2FyZFdheCA9IHRydWVcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZW1vdmVJdGVtT25jZShfc2VsZWN0ZWRTZXJ2aWNlcywgNSlcclxuICAgICAgICAgICAgcmVtb3ZlSXRlbU9uY2UoX3NlbGVjdGVkU2VydmljZXNUaXRsZSwgXCLZiNin2qnYsyDYr9in2LTYqNmI2LHYr1wiKVxyXG4gICAgICAgICAgICBzZXREYXNoYm9hcmRXYXgoZmFsc2UpXHJcbiAgICAgICAgICAgIGlmICh0b2dnbGUpXHJcbiAgICAgICAgICAgICAgICBzZXREYXNoYm9hcmRXYXhDbGFzcyhcImZhbHNlIGRpc2FibGVkXCIpXHJcbiAgICAgICAgICAgIGVsc2Ugc2V0RGFzaGJvYXJkV2F4Q2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICBfZGFzaGJvYXJkV2F4ID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0U2VydmljZXNUaXRsZShfc2VsZWN0ZWRTZXJ2aWNlc1RpdGxlKVxyXG4gICAgICAgIHNldFNlcnZpY2VzKF9zZWxlY3RlZFNlcnZpY2VzKTtcclxuICAgICAgICBzZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgc2VydmljZXM6IF9zZWxlY3RlZFNlcnZpY2VzLCBzZXJ2aWNlc1RpdGxlOiBfc2VsZWN0ZWRTZXJ2aWNlc1RpdGxlfSlcclxuICAgICAgICBzZXRTdGF0ZSh7XHJcbiAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICByb29TaG95aTogX3Jvb1Nob3lpLFxyXG4gICAgICAgICAgICB0b29TaG9veWk6IF90b29TaG9veWksXHJcbiAgICAgICAgICAgIHJvb1Nob3lpVG9vU2hvb3lpOiBfcm9vU2hveWlUb29TaG9veWksXHJcbiAgICAgICAgICAgIGRhc2hib2FyZFdheDogX2Rhc2hib2FyZFdheCxcclxuICAgICAgICAgICAgbGFzdGlrV2F4OiBfbGFzdGlrV2F4XHJcbiAgICAgICAgfSlcclxuICAgICAgICBjYWxjdWxhdGVQcmljZShfc2VsZWN0ZWRTZXJ2aWNlcywgY2FyTW9kZWwpXHJcbiAgICAgICAgc2V0SXNUb29PclJvb1NlbGVjdGVkKF9yb29TaG95aSB8fCBfdG9vU2hvb3lpKVxyXG4gICAgICAgIGxldCByZXN1bHQgPSAoKGNhckJyYW5kICE9IDAgJiYgY2FyTW9kZWwgIT0gMCkgfHwgc2VsZWN0ZWRDYXIgIT0gMCkgJiYgZGF0ZSAhPSBcIlwiICYmIHRpbWUgIT0gXCJcIiAmJiAoX3NlbGVjdGVkU2VydmljZXMubGVuZ3RoID4gMCAmJiAoX3Jvb1Nob3lpIHx8IF90b29TaG9veWkpKTtcclxuICAgICAgICB2YWxpZGF0ZShyZXN1bHQpO1xyXG4gICAgfTtcclxuICAgIGNvbnN0IHRpbWVIYW5kbGVyID0gKGV2ZW50KSA9PiB7XHJcbiAgICAgICAgc2V0VGltZShldmVudC50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgIGxldCBpbmRleCA9IHRpbWVzSG9sZGVyLmluZGV4T2YoZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICBzd2l0Y2ggKGV2ZW50LnRhcmdldC52YWx1ZSkge1xyXG4gICAgICAgICAgICBjYXNlIFwiMjI6MzBcIjpcclxuICAgICAgICAgICAgICAgIHNldFRpbWVFbmQoXCIwMDozMFwiKVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCIyMzowMFwiOlxyXG4gICAgICAgICAgICAgICAgc2V0VGltZUVuZChcIjAxOjAwXCIpXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcIjIzOjMwXCI6XHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lRW5kKFwiMDE6MzBcIilcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwiMjQ6MDBcIjpcclxuICAgICAgICAgICAgICAgIHNldFRpbWVFbmQoXCIwMjowMFwiKVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lRW5kKHRpbWVzSG9sZGVyW2luZGV4ICsgNF0pXHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBzZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgdGltZTogZXZlbnQudGFyZ2V0LnZhbHVlLCBlbmRUaW1lOiB0aW1lc0hvbGRlcltpbmRleCArIDFdLCBhYnNlbmNlOiB0b2dnbGUgPyAxIDogMH0pXHJcbiAgICAgICAgbGV0IHJlc3VsdCA9ICgoY2FyQnJhbmQgIT0gMCAmJiBjYXJNb2RlbCAhPSAwKSB8fCBzZWxlY3RlZENhciAhPSAwKSAmJiBkYXRlICE9IFwiXCIgJiYgZXZlbnQudGFyZ2V0LnZhbHVlICE9IFwiXCIgJiYgc2VydmljZXMubGVuZ3RoID4gMCAmJiBpc1Rvb09yUm9vU2VsZWN0ZWQ7XHJcbiAgICAgICAgdmFsaWRhdGUocmVzdWx0KTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBnZXRUaW1lU3RhbXAoaW5wdXQpIHtcclxuICAgICAgICB2YXIgcGFydHMgPSBpbnB1dC50cmltKCkuc3BsaXQoJyAnKTtcclxuICAgICAgICB2YXIgZGF0ZSA9IHBhcnRzWzBdLnNwbGl0KCctJyk7XHJcbiAgICAgICAgdmFyIHRpbWUgPSAocGFydHNbMV0gPyBwYXJ0c1sxXSA6ICcwMDowMDowMCcpLnNwbGl0KCc6Jyk7XHJcblxyXG4gICAgICAgIC8vIE5PVEU6OiBNb250aDogMCA9IEphbnVhcnkgLSAxMSA9IERlY2VtYmVyLlxyXG4gICAgICAgIHZhciBkID0gbmV3IERhdGUoZGF0ZVswXSwgZGF0ZVsxXSAtIDEsIGRhdGVbMl0sIHRpbWVbMF0sIHRpbWVbMV0sIHRpbWVbMl0pO1xyXG4gICAgICAgIHJldHVybiBkLmdldFRpbWUoKSAvIDEwMDA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZGF0ZUhhbmRsZXIgPSAodmFsdWUpID0+IHtcclxuICAgICAgICBsZXQgX2QgPSB2YWx1ZS5mb3JtYXQoJ1lZWVktTS1EIEhIOm1tOnNzJylcclxuICAgICAgICBsZXQgX3RpbWVzdGFtcCA9IGdldFRpbWVTdGFtcChfZClcclxuICAgICAgICAvL3ZhciBkYXRlID0gbmV3IERhdGUodGltZXN0YW1wKjEwMDApO1xyXG5cclxuICAgICAgICBzZXREYXRlKHZhbHVlKTtcclxuICAgICAgICBpZiAoaXNFbXB0eShwcm9wcy5vcmRlckRhdGEpKVxyXG4gICAgICAgICAgICB0aW1lc0hhbmRsZXIodmFsdWUpXHJcbiAgICAgICAgc2V0VGltZXN0YW1wKF90aW1lc3RhbXAgKiAxMDAwKVxyXG4gICAgICAgIHNldE9yZGVyRGF0YSh7Li4ub3JkZXJEYXRhLCBkYXRlOiBfdGltZXN0YW1wICogMTAwMH0pXHJcbiAgICAgICAgbGV0IHJlc3VsdCA9ICgoY2FyQnJhbmQgIT0gMCAmJiBjYXJNb2RlbCAhPSAwKSB8fCBzZWxlY3RlZENhciAhPSAwKSAmJiB2YWx1ZSAhPSBcIlwiICYmIHRpbWUgIT0gXCJcIiAmJiBzZXJ2aWNlcy5sZW5ndGggPiAwICYmIGlzVG9vT3JSb29TZWxlY3RlZDtcclxuICAgICAgICB2YWxpZGF0ZShyZXN1bHQpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY3JlYXRlT3JkZXIgPSAoKSA9PiB7XHJcbiAgICAgICAgbGV0IF9vcmRlckRhdGEgPSB7XHJcbiAgICAgICAgICAgIC4uLm9yZGVyRGF0YSxcclxuICAgICAgICAgICAgc2VydmljZXM6IHNlcnZpY2VzLFxyXG4gICAgICAgICAgICBzZXJ2aWNlc1RpdGxlOiBzZXJ2aWNlc1RpdGxlLFxyXG4gICAgICAgICAgICBhYnNlbmNlOiB0b2dnbGUgPyAxIDogMCxcclxuICAgICAgICAgICAgdGltZTogdGltZSxcclxuICAgICAgICAgICAgZW5kVGltZTogdGltZUVuZCxcclxuICAgICAgICAgICAgcHJpY2U6IHByaWNlLFxyXG4gICAgICAgICAgICBjYXJNb2RlbDogY2FyTW9kZWwsXHJcbiAgICAgICAgICAgIG1vZGVsVGl0bGU6IHNlbGVjdGVkQ2FyID4gMCA/IHNlbGVjdGVkQ2FyTW9kZWxUaXRsZSA6IGNhck1vZGVsVGl0bGUsXHJcbiAgICAgICAgICAgIGNhckJyYW5kOiBjYXJCcmFuZCxcclxuICAgICAgICAgICAgYnJhbmRUaXRsZTogc2VsZWN0ZWRDYXIgPiAwID8gc2VsZWN0ZWRDYXJCcmFuZFRpdGxlIDogY2FyQnJhbmRUaXRsZSxcclxuICAgICAgICAgICAgc2VsZWN0ZWRDYXI6IHNlbGVjdGVkQ2FyLFxyXG4gICAgICAgICAgICBkYXRlOiBpc0VtcHR5KHByb3BzLm9yZGVyRGF0YSkgPyB0aW1lc3RhbXAgOiBwcm9wcy5vcmRlckRhdGEuZGF0ZSA9PSB0aW1lc3RhbXAgPyBwcm9wcy5vcmRlckRhdGEuZGF0ZSA6IHRpbWVzdGFtcFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHJvcHMuY2FsbGJhY2soXCJvcmRlclwiLCBfb3JkZXJEYXRhKVxyXG4gICAgfVxyXG4gICAgY29uc3Qgc2hvd01vZGFsRWRpdCA9ICgpID0+IHtcclxuICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgc2V0U2hvd0Nhckl0ZW1zKGZhbHNlKVxyXG4gICAgICAgIHNldEVkaXRDYXIodHJ1ZSlcclxuICAgIH07XHJcbiAgICBjb25zdCBjbG9zZU1vZGFsID0gKCkgPT4ge1xyXG4gICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgc2V0VG9nZ2xlKGZhbHNlKVxyXG4gICAgICAgIHNldFJvb1Nob3lpKGZhbHNlKVxyXG4gICAgICAgIHNldFJvb1Nob3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgIHNldFRvb1Nob295aShmYWxzZSlcclxuICAgICAgICBzZXRUb29TaG9veWlDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWkoZmFsc2UpXHJcbiAgICAgICAgc2V0Um9vU2hveWlUb29TaG9veWlDbGFzcyhcImZhbHNlXCIpXHJcbiAgICAgICAgc2V0RGFzaGJvYXJkV2F4KGZhbHNlKVxyXG4gICAgICAgIHNldERhc2hib2FyZFdheENsYXNzKFwiZmFsc2VcIilcclxuICAgICAgICBzZXRMYXN0aWtXYXgoZmFsc2UpXHJcbiAgICAgICAgc2V0TGFzdGlrV2F4Q2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgIHNldE9yZGVyRGF0YSh7Li4ub3JkZXJEYXRhLCBhYnNlbmNlOiAwfSlcclxuICAgICAgICBzZXRTdGF0ZSh7XHJcbiAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICByb29TaG95aTogZmFsc2UsXHJcbiAgICAgICAgICAgIHRvb1Nob295aTogZmFsc2UsXHJcbiAgICAgICAgICAgIHJvb1Nob3lpVG9vU2hvb3lpOiBmYWxzZSxcclxuICAgICAgICAgICAgZGFzaGJvYXJkV2F4OiBmYWxzZSxcclxuICAgICAgICAgICAgbGFzdGlrV2F4OiBmYWxzZVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgc2V0U2hvd0Nhckl0ZW1zKGZhbHNlKVxyXG4gICAgfTtcclxuICAgIGNvbnN0IGNhclRhZ0hhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgICAgIHNldENhclRhZyhlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgLy9zZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgY2FyVGFnOiBlLnRhcmdldC52YWx1ZX0pXHJcbiAgICB9O1xyXG4gICAgY29uc3Qgc3Vic2NyaWJlTW9kYWwgPSAoKSA9PiB7XHJcbiAgICAgICAgLypzZXRSb29TaG95aShmYWxzZSlcclxuICAgICAgICBzZXRTZXJ2aWNlcyhbXSlcclxuICAgICAgICBzZXRTZXJ2aWNlc1RpdGxlKFtdKVxyXG4gICAgICAgIHNldFJvb1Nob3lpQ2xhc3MoXCJmYWxzZVwiKVxyXG4gICAgICAgIHNldFByaWNlKFwiLi4uXCIpXHJcbiAgICAgICAgc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgcm9vU2hveWk6IGZhbHNlLFxyXG4gICAgICAgICAgICB0b29TaG9veWk6IGZhbHNlLFxyXG4gICAgICAgICAgICByb29TaG95aVRvb1Nob295aTogZmFsc2UsXHJcbiAgICAgICAgICAgIGRhc2hib2FyZFdheDogZmFsc2UsXHJcbiAgICAgICAgICAgIGxhc3Rpa1dheDogZmFsc2VcclxuICAgICAgICB9KSovXHJcblxyXG4gICAgICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIk5vdGlmbGl4Tm90aWZ5V3JhcFwiKSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgdmFyIG15b2JqID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJOb3RpZmxpeE5vdGlmeVdyYXBcIik7XHJcbiAgICAgICAgICAgIG15b2JqLnJlbW92ZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZyhmaWxlKVxyXG4gICAgICAgIGNvbnNvbGUubG9nKGNhclRhZylcclxuICAgICAgICBpZiAoZmlsZSAhPSBcIlwiICYmIGNhclRhZyAhPSBcIlwiICYmIGZpbGUgIT0gbnVsbCAmJiBjYXJUYWcgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICBpZiAoIXNldEVkaXRDYXIpIHNldFRvZ2dsZSh0cnVlKVxyXG4gICAgICAgICAgICBzZXRTaG93Q2FySXRlbXModHJ1ZSlcclxuICAgICAgICAgICAgc2V0RWRpdENhcihmYWxzZSlcclxuICAgICAgICB9IGVsc2UgaWYgKGNhclRhZyA9PSBcIlwiIHx8IGNhclRhZyA9PSBudWxsKSBOb3RpZmxpeC5Ob3RpZnkuRmFpbHVyZSgn2YTYt9mB2Kcg2b7ZhNin2qkg2YXYp9i024zZhiDYrtmI2K8g2LHYpyDZiNin2LHYryDaqdmG24zYry4nKTtcclxuICAgICAgICBlbHNlIGlmIChmaWxlID09IFwiXCIgfHwgZmlsZSA9PSBudWxsKSBOb3RpZmxpeC5Ob3RpZnkuRmFpbHVyZSgn2YTYt9mB2Kcg2KrYtdmI24zYsSDaqdin2LHYqiDZhdin2LTbjNmGINiu2YjYryDYsdinINii2b7ZhNmI2K8g2qnZhtuM2K8uJyk7XHJcblxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBjYWxjdWxhdGVQcmljZSA9IChzZWxlY3RlZFNlcnZpY2VzLCBtb2RlbCkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHNlbGVjdGVkU2VydmljZXMpXHJcbiAgICAgICAgY29uc29sZS5sb2cobW9kZWwpXHJcbiAgICAgICAgaWYgKChtb2RlbCAhPSAwKSAmJiBzZWxlY3RlZFNlcnZpY2VzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZ1ByaWNlKHRydWUpXHJcbiAgICAgICAgICAgIGxldCBkYXRhID0gbmV3IEZvcm1EYXRhKClcclxuICAgICAgICAgICAgZGF0YS5hcHBlbmQoJ21vZGVsX2lkJywgbW9kZWwpXHJcbiAgICAgICAgICAgIGRhdGEuYXBwZW5kKCdzZXJ2aWNlcycsIEpTT04uc3RyaW5naWZ5KHNlbGVjdGVkU2VydmljZXMpKVxyXG5cclxuICAgICAgICAgICAgYXhpb3MucG9zdCh1cmwgKyAnL3ByaWNlcy9ndWVzcycsIGRhdGEsIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQWNjZXB0JzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdkYXRhVHlwZSc6ICdqc29uJywgICAvL3lvdSBtYXkgdXNlIGpzb25wIGZvciBjcm9zcyBvcmlnaW4gcmVxdWVzdFxyXG4gICAgICAgICAgICAgICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBcIkJlYXJlciBcIiArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAudGhlbigocmVzcG9uc2VKc29uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlSnNvbi5kYXRhLm1lc3NhZ2UgPT0gXCLZh9iy24zZhtmH4oCM2YfYpyDYqNinINmF2YjZgdmC24zYqiDYr9ix24zYp9mB2Kog2LTYry5cIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRQcmljZShyZXNwb25zZUpzb24uZGF0YS5wcmljZXMucHJpY2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldE9yZGVyRGF0YSh7Li4ub3JkZXJEYXRhLCBwcmljZTogcmVzcG9uc2VKc29uLmRhdGEucHJpY2VzLnByaWNlfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0TG9hZGluZ1ByaWNlKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgIH0gZWxzZSBzZXRQcmljZShcIi4uLlwiKVxyXG4gICAgfTtcclxuICAgIGNvbnN0IGltYWdlSGFuZGxlciA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgICAgIC8vZmlsZU9iajEucHVzaChldmVudC50YXJnZXQuZmlsZXMpXHJcbiAgICAgICAgbGV0IF9uYW1lID0gZXZlbnQudGFyZ2V0LmZpbGVzWzBdLm5hbWU7XHJcbiAgICAgICAgbGV0IF9sYXN0TW9kaWZpZWQgPSBldmVudC50YXJnZXQuZmlsZXNbMF0ubGFzdE1vZGlmaWVkO1xyXG4gICAgICAgIHNldEZpbGUoVVJMLmNyZWF0ZU9iamVjdFVSTChldmVudC50YXJnZXQuZmlsZXNbMF0pKTtcclxuICAgICAgICBsZXQgX2ZpbGUgPSBuZXcgRmlsZShbZXZlbnQudGFyZ2V0LmZpbGVzWzBdXSwgX25hbWUsIHt0eXBlOiBcImltYWdlL2pwZWdcIn0pO1xyXG4gICAgICAgIC8vc2V0RmlsZShfZmlsZSlcclxuICAgICAgICBzZXRPcmRlckRhdGEoey4uLm9yZGVyRGF0YSwgY2FyZEltZzogX2ZpbGUsIGNhcmRGaWxlOiBVUkwuY3JlYXRlT2JqZWN0VVJMKGV2ZW50LnRhcmdldC5maWxlc1swXSl9KVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPE11aVRoZW1lUHJvdmlkZXIgdGhlbWU9e3RoZW1lfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcmRlckZvcm1cIiBkaXI9XCJydGxcIj5cclxuICAgICAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdyBjbGFzc05hbWU9XCJvcmRlclJvdyBjYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4bD17Mn0gbGc9ezJ9IG1kPXsyfSBzbT17MTJ9IHhzPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybUxhYmVsXCI+2KfZhtiq2K7Yp9ioINiu2YjYr9ix2Yg8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4bD17M30gbGc9ezN9IG1kPXszfSBzbT17MTJ9IHhzPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUNvbnRyb2wgdmFyaWFudD1cImZpbGxlZFwiIGRpc2FibGVkPXtzZWxlY3RlZENhcklzU2VsZWN0ZWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBdXRvY29tcGxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0YWdzLWZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjYXJCcmFuZFRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2VsZWN0ZWRDYXJJc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtjYXJCcmFuZHMubWFwKChvcHRpb24pID0+IG9wdGlvbi5uYW1lKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9PcHRpb25zVGV4dD1cItmF2YjYsdiv24wg24zYp9mB2Kog2YbYtNivXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2NhckJyYW5kSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVySW5wdXQ9eyhwYXJhbXMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4ucGFyYW1zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwi2KjYsdmG2K8g2K7ZiNiv2LHZiCDYsdinINin2YbYqtiu2KfYqCDaqdmG24zYr1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLYqNix2KfbjCDYrNiz2KrYrNmIINiq2KfbjNm+INqp2YbbjNivLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUNvbnRyb2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhsPXszfSBsZz17M30gbWQ9ezN9IHNtPXsxMn0geHM9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtQ29udHJvbCB2YXJpYW50PVwiZmlsbGVkXCIgZGlzYWJsZWQ9e3NlbGVjdGVkQ2FySXNTZWxlY3RlZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEF1dG9jb21wbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInRhZ3MtZmlsbGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Nhck1vZGVsVGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZWxlY3RlZENhcklzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2Nhck1vZGVscy5tYXAoKG9wdGlvbikgPT4gb3B0aW9uLm5hbWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBub09wdGlvbnNUZXh0PVwi2YXZiNix2K/bjCDbjNin2YHYqiDZhti02K9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17Y2FyTW9kZWxIYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW5kZXJJbnB1dD17KHBhcmFtcykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5wYXJhbXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCLZhdiv2YQg2K7ZiNiv2LHZiCDYsdinINin2YbYqtiu2KfYqCDaqdmG24zYr1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLYqNix2KfbjCDYrNiz2KrYrNmIINiq2KfbjNm+INqp2YbbjNivLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUNvbnRyb2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhsPXszfSBsZz17M30gbWQ9ezN9IHNtPXsxMn0geHM9ezEyfSBjbGFzc05hbWU9XCJzZWxlY3RlZENhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhcnMubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Db250cm9sIHZhcmlhbnQ9XCJmaWxsZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXV0b2NvbXBsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGFncy1maWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDYXJUaXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17Y2Fycy5tYXAoKG9wdGlvbikgPT4gb3B0aW9uLnRpdGxlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9PcHRpb25zVGV4dD1cItmF2YjYsdiv24wg24zYp9mB2Kog2YbYtNivXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NlbGVjdGVkQ2FySGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVySW5wdXQ9eyhwYXJhbXMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4ucGFyYW1zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwi2K7ZiNiv2LHZiNmH2KfbjCDZhdmG2KrYrtioXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cItio2LHYp9uMINis2LPYqtis2Ygg2KrYp9uM2b4g2qnZhtuM2K8uLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKjxBdXRvY29tcGxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0YWdzLWZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZENhclRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtjYXJzLm1hcCgob3B0aW9uKSA9PiBvcHRpb24ubmFtZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vT3B0aW9uc1RleHQ9XCLZhdmI2LHYr9uMINuM2KfZgdiqINmG2LTYry5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW5kZXJPcHRpb249eyhvcHRpb24sIHtzZWxlY3RlZH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWFjdC5GcmFnbWVudD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9SZWFjdC5GcmFnbWVudD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9PcHRpb25zVGV4dD1cItmF2YjYsdiv24wg24zYp9mB2Kog2YbYtNivXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NlbGVjdGVkQ2FySGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVySW5wdXQ9eyhwYXJhbXMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4ucGFyYW1zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwi2K7ZiNix2YjZh9in24wg2YXZhtiq2K7YqFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLYqNix2KfbjCDYrNiz2KrYrNmIINiq2KfbjNm+INqp2YbbjNivLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz4qL31cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Db250cm9sPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeGw9ezF9IGxnPXsxfSBtZD17MX0gc209ezEyfSB4cz17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICA8Um93IGNsYXNzTmFtZT1cIm9yZGVyUm93XCIgc3R5bGU9e3tib3JkZXI6IFwibm9uZVwifX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeGw9ezJ9IGxnPXsyfSBtZD17Mn0gc209ezEyfSB4cz17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm1MYWJlbFwiPtin2YbYqtiu2KfYqCDYrtiv2YXYp9iqPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeGw9ezR9IGxnPXs0fSBtZD17MTB9IHNtPXsxMn0geHM9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcmRlcnNDb3VudCA+IDAgP1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzd2l0Y2gtZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN3aXRjaFRvZ2dsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9XCLYrtuM2LFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic3dpdGNoX3JpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dG9nZ2xlU3RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17IXRvZ2dsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInN3aXRjaF9yaWdodFwiIGNsYXNzTmFtZT1cInN3aXRjaF9yaWdodFwiPtiu24zYsTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzd2l0Y2hUb2dnbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwi2KjZhNmHXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInN3aXRjaF9sZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dG9nZ2xlU3RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dG9nZ2xlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic3dpdGNoX2xlZnRcIiBjbGFzc05hbWU9XCJzd2l0Y2hfbGVmdFwiPtio2YTZhzwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic3dpdGNoVGlsZVwiPtiv2LEg2LrbjNin2Kgg2YXYtNiq2LHbjDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBudWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93Q2FySXRlbXMgP1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeGw9ezZ9IGxnPXs2fSBtZD17MTB9IHNtPXsxMn0geHM9ezEyfSBjbGFzc05hbWU9XCJjYXJJdGVtc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17ZmlsZX0gY2xhc3NOYW1lPVwiY2FySW1nXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXJUYWcgIT0gXCJcIiAmJiBjYXJUYWcgIT0gbnVsbCA/IDxzcGFuPtm+2YTYp9qpINmF2KfYtNuM2YYgOiB7Y2FyVGFnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG51bGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3Nob3dNb2RhbEVkaXR9PtmI24zYsdin24zYtCDZhdiv2KfYsdqpINiu2YjYr9ix2Yg8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9nZ2xlICYmIHNlbGVjdGVkQ2FyICE9IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8fCB0b2dnbGUgJiYgY2FyTW9kZWwgIT0gMCA/XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17c2hvd01vZGFsRWRpdH0+2KLZvtmE2YjYryDZhdiv2KfYsdqpINiu2YjYr9ix2Yg8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBudWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdyBjbGFzc05hbWU9XCJvcmRlclJvd1wiIHN0eWxlPXt7cGFkZGluZ1RvcDogXCIwXCIsIG1hcmdpbjogXCIwIDIwcHhcIn19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhsPXs5fSBsZz17OX0gbWQ9ezEyfSBzbT17MTJ9IHhzPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUNvbnRyb2wgY2xhc3NOYW1lPVwiY2hlY2tTZXJ2aWNlc1wiIGNvbXBvbmVudD1cImZpZWxkc2V0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWNoZWNrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e3Jvb1Nob3lpQ2xhc3N9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIG5hbWU9XCJyb29TaG95aVwiIHZhbHVlPXtyb29TaG95aX0gY2hlY2tlZD17cm9vU2hveWl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Jvb1Nob3lpVG9vU2hvb3lpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXJ2aWNlc0hhbmRsZXJ9IGNsYXNzTmFtZT1cImZvcm0tY2hlY2staW5wdXRcIi8+2LHZiNi02YjbjNuMXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWNoZWNrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e3Rvb1Nob295aUNsYXNzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBuYW1lPVwidG9vU2hvb3lpXCIgdmFsdWU9e3Rvb1Nob295aX0gY2hlY2tlZD17dG9vU2hvb3lpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyb29TaG95aVRvb1Nob295aSB8fCB0b2dnbGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NlcnZpY2VzSGFuZGxlcn0gY2xhc3NOYW1lPVwiZm9ybS1jaGVjay1pbnB1dFwiLz7YqtmI2LTZiNuM24xcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyo8ZGl2IGNsYXNzTmFtZT1cImZvcm0tY2hlY2sgZm9ybS1jaGVjay0yNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPXtyb29TaG95aVRvb1Nob295aUNsYXNzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBuYW1lPVwicm9vU2hveWlUb29TaG9veWlcIiB2YWx1ZT17cm9vU2hveWlUb29TaG9veWl9IGNoZWNrZWQ9e3Jvb1Nob3lpVG9vU2hvb3lpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyb29TaG95aSB8fCB0b29TaG9veWkgfHwgdG9nZ2xlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXJ2aWNlc0hhbmRsZXJ9IGNsYXNzTmFtZT1cImZvcm0tY2hlY2staW5wdXRcIi8+2LHZiNi02YjbjNuMLdiq2YjYtNmI24zbjFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1jaGVjayBmb3JtLWNoZWNrLTI1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e2xhc3Rpa1dheENsYXNzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBuYW1lPVwibGFzdGlrV2F4XCIgdmFsdWU9e2xhc3Rpa1dheH0gY2hlY2tlZD17bGFzdGlrV2F4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXJ2aWNlc0hhbmRsZXJ9IGNsYXNzTmFtZT1cImZvcm0tY2hlY2staW5wdXRcIi8+2YjYp9qp2LNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgINmE2KfYs9iq24zaqVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1jaGVjayBmb3JtLWNoZWNrLTI1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e2Rhc2hib2FyZFdheENsYXNzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBuYW1lPVwiZGFzaGJvYXJkV2F4XCIgdmFsdWU9e2Rhc2hib2FyZFdheH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtkYXNoYm9hcmRXYXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3RvZ2dsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2VydmljZXNIYW5kbGVyfSBjbGFzc05hbWU9XCJmb3JtLWNoZWNrLWlucHV0XCIvPtmI2KfaqdizXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDYr9in2LTYqNmI2LHYr1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtQ29udHJvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeGw9ezN9IGxnPXszfSBtZD17MTJ9IHNtPXsxMn0geHM9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nUHJpY2UgP1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvYWRlclwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzZXJ2aWNlc1ByaWNlXCI+2YfYstuM2YbZhyDYrtiv2YXYp9iqIDoge2FkZENvbW1hcyhwcmljZSl9INiq2YjZhdin2YY8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdyBjbGFzc05hbWU9XCJvcmRlclJvdyB0aW1lU2VsZWN0XCIgc3R5bGU9e3tib3JkZXI6IFwibm9uZVwifX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeGw9ezJ9IGxnPXsyfSBtZD17Mn0gc209ezEyfSB4cz17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm1MYWJlbFwiPtin2YbYqtiu2KfYqCDYstmF2KfZhjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhsPXszfSBsZz17M30gbWQ9ezN9IHNtPXsxMn0geHM9ezEyfSBjbGFzc05hbWU9XCJmb3JtLWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2Rvd259IGNsYXNzTmFtZT1cImRvd25cIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCLYqtin2LHbjNiuINqp2KfYsdmI2KfYtFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi2KrYp9ix24zYriDaqdin2LHZiNin2LRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0dyZWdvcmlhbj17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVQaWNrZXI9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49e2VuYWJsZWRSYW5nZS5taW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17ZW5hYmxlZFJhbmdlLm1heH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dUb2RheUJ1dHRvbj17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0Rm9ybWF0PVwiWVlZWS1NLURcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZGF0ZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhsPXszfSBsZz17M30gbWQ9ezN9IHNtPXsxMn0geHM9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtQ29udHJvbCB2YXJpYW50PVwiZmlsbGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0TGFiZWwgaWQ9XCJkZW1vLXNpbXBsZS1zZWxlY3QtZmlsbGVkLWxhYmVsXCI+2LPYp9i52Kog2LTYsdmI2Lk8L0lucHV0TGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbElkPVwiZGVtby1zaW1wbGUtc2VsZWN0LWZpbGxlZC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZGVtby1zaW1wbGUtc2VsZWN0LWZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGltZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwi2LPYp9i52Kog2LTYsdmI2LlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpbWVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtQ29udHJvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeGw9ezR9IGxnPXsxMH0gbWQ9ezEyfSBzbT17MTJ9IHhzPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZSAhPSBcIlwiICYmIHRpbWVFbmQgIT0gXCJcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzZXJ2aWNlc1RpbWVcIj7YrtmI2K/YsdmIINi02YXYpyDYr9ixINio2KfYstmHINiy2YXYp9mG24wge3RpbWV9INiq2Kcge3RpbWVFbmR9INi02LPYqtmHINiu2YjYp9mH2K9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg2LTYry48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdyBjbGFzc05hbWU9XCJvcmRlckJ0blwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGNsYXNzTmFtZT1cIlwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBjb2xvcj1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY3JlYXRlT3JkZXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YnRuRGlzYWJsZWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg2YXYsdit2YTZhyDYqNi52K8gKNin2YbYqtiu2KfYqCDZhdit2YQg2LTYs9iqINmIINi02YgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7Lyo8TW9kYWxcclxuICAgICAgICAgICAgICAgIG9wZW49e3Nob3dNb2RhbH1cclxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9e2Nsb3NlTW9kYWx9XHJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsbGVkYnk9XCJzaW1wbGUtbW9kYWwtdGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT1cInNpbXBsZS1tb2RhbC1kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtib2R5fVxyXG4gICAgICAgICAgICA8L01vZGFsPiovfVxyXG4gICAgICAgICAgICA8RGlhbG9nIG9wZW49e3Nob3dNb2RhbH0gb25DbG9zZT17Y2xvc2VNb2RhbH0gYXJpYS1sYWJlbGxlZGJ5PVwiZm9ybS1kaWFsb2ctdGl0bGVcIiBjbGFzc05hbWU9XCJhYnNlbnNlRGlhbG9nXCI+XHJcbiAgICAgICAgICAgICAgICA8RGlhbG9nVGl0bGUgaWQ9XCJmb3JtLWRpYWxvZy10aXRsZVwiPtin2LHYs9in2YQg2YXYr9in2LHaqTwvRGlhbG9nVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8RGlhbG9nQ29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICA8RGlhbG9nQ29udGVudFRleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgINmE2LfZgdinINio2LHYp9uMINin2LPYqtmB2KfYr9mHINin2LIg2K7Yr9mF2KfYqiDYr9ix2LrbjNin2Kgg2YXYtNiq2LHbjCDYqNmHINmG2qnYp9iqINiy24zYsSDYqtmI2KzZhyDYr9in2LTYqtmHINio2KfYtNuM2K86XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxici8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0g2YXYrdmEINm+2KfYsdqpINqp2LHYr9mGINmF2KfYtNuM2YYg2KjYp9uM2K8g2KjZhyDar9mI2YbZhyDYp9uMINio2KfYtNivINqp2YdcclxuICAgICAgICAgICAgICAgICAgICAgICAg2K/Ys9iq2LHYs9uMINio2Ycg2YfZhdmHINmG2YLYp9i3INmF2KfYtNuM2YYg2KfZhdqp2KfZhiDZvtiw24zYsSDYqNin2LTYryAo2qnZhtin2LEg2K/bjNmI2KfYsSDbjNinINqG2LPYqNuM2K/ZhyDYqNmHINis2K/ZiNmEXHJcbiAgICAgICAgICAgICAgICAgICAgICAgINmIIC4uLiDZhtio2KfYtNiv2Iwg2YbZgtin2LfbjCDaqdmHINiv2LPYqiDaqdin2LHZiNin2LTZhdmGINmG2LHYs9ivINi02LPYqtmHINmG2K7ZiNin2YfYryDYtNivLilcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJyLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLSDZh9mFINqG2YbbjNmGINiv2KfYrtmEINi024zYtNmHINmH2Kcg2K/Ys9iq2YXYp9mEINqp2LTbjNiv2Ycg2YbYrtmI2KfZh9ivINi02K8uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxici8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgINio2LHYp9uMINit2YHYuCDYp9mF2YbbjNiqINiv2LEg2KfYs9iq2YHYp9iv2Ycg2KfYsiDYrtiv2YXYp9iqINqp2KfYsdmI2KfYtCDYr9ixINi624zYp9ioINmF2LTYqtix24wg2YTYt9mB2Kcg2b7ZhNin2qkg2K7ZiNiv2LHZiCDYrtmI2K8g2LHYpyDZiNin2LHYryDaqdix2K/ZhyDZiCDaqdin2LHYqlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDZhdin2LTbjNmGINix2KdcclxuICAgICAgICAgICAgICAgICAgICAgICAg2KLZvtmE2YjYryDZhtmF2KfbjNuM2K8uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9EaWFsb2dDb250ZW50VGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8TXVpVGhlbWVQcm92aWRlciB0aGVtZT17dGhlbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGRpcj1cInJ0bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJQbGF0ZSBvcmRlclBsYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGVsXCIgaW5wdXRNb2RlPVwibnVtYmVyXCIgbWF4TGVuZ3RoPXsxfSB2YWx1ZT17bnVtMH0gaWQ9XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW1IYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGF0dGVybj1cIlswLTldKlwiIG9uS2V5RG93bj17bnVtSGFuZGxlcn0vPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRlbFwiIGlucHV0TW9kZT1cIm51bWJlclwiIG1heExlbmd0aD17MX0gdmFsdWU9e251bTF9IGlkPVwiMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdHRlcm49XCJbMC05XSpcIiBvbktleURvd249e251bUhhbmRsZXJ9Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17bnVtMn0gaWQ9XCIyXCIgb25DaGFuZ2U9e251bUhhbmRsZXJ9IG9uS2V5RG93bj17bnVtSGFuZGxlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2KdcIj4g2KfZhNmBPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2KhcIj4g2Kg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLZvlwiPiDZvjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cItiqXCI+INiqPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2KtcIj4g2Ks8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLYrFwiPiDYrDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qPG9wdGlvbiB2YWx1ZT1cIu+/vVwiPiDvv708L29wdGlvbj4qL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLYrVwiPiDYrTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cItiuXCI+INiuPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2K9cIj4g2K88L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLYsFwiPiDYsDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cItixXCI+INixPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2LJcIj4g2LI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLYs1wiPiDYszwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIti0XCI+INi0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2LVcIj4g2LU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLYtlwiPiDYtjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIti3XCI+INi3PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2LhcIj4g2Lg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLYuVwiPiDYuTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIti6XCI+INi6PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2YFcIj4g2YE8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLZglwiPiDZgjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cItqpXCI+INqpPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2q9cIj4g2q88L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLZhFwiPiDZhDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cItmFXCI+INmFPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi2YZcIj4g2YY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLZiFwiPiDZiDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cItmH2YBcIj4g2YfZgDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cItuMXCI+INuMPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRFwiPiBEPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU1wiPiBTPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRlbFwiIGlucHV0TW9kZT1cIm51bWJlclwiIG1heExlbmd0aD17MX0gdmFsdWU9e251bTN9IGlkPVwiM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdHRlcm49XCJbMC05XSpcIiBvbktleURvd249e251bUhhbmRsZXJ9Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZWxcIiBpbnB1dE1vZGU9XCJudW1iZXJcIiBtYXhMZW5ndGg9ezF9IHZhbHVlPXtudW00fSBpZD1cIjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bUhhbmRsZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuPVwiWzAtOV0qXCIgb25LZXlEb3duPXtudW1IYW5kbGVyfS8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGVsXCIgaW5wdXRNb2RlPVwibnVtYmVyXCIgbWF4TGVuZ3RoPXsxfSB2YWx1ZT17bnVtNX0gaWQ9XCI1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW1IYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGF0dGVybj1cIlswLTldKlwiIG9uS2V5RG93bj17bnVtSGFuZGxlcn0vPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRlbFwiIGlucHV0TW9kZT1cIm51bWJlclwiIG1heExlbmd0aD17MX0gdmFsdWU9e251bTZ9IGlkPVwiNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdHRlcm49XCJbMC05XSpcIiBvbktleURvd249e251bUhhbmRsZXJ9Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZWxcIiBpbnB1dE1vZGU9XCJudW1iZXJcIiBtYXhMZW5ndGg9ezF9IHZhbHVlPXtudW03fSBpZD1cIjdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bUhhbmRsZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuPVwiWzAtOV0qXCIgb25LZXlEb3duPXtudW1IYW5kbGVyfS8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyo8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luPVwiZGVuc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCLZvtmE2KfaqSDYrtmI2K/YsdmIXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhclRhZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17Y2FyVGFnSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZmlsbGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+Ki99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVwbG9hZElucHV0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dGZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dEdyb3VwRmlsZTAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9XCJpbnB1dEdyb3VwRmlsZUFkZG9uMDFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUudGFyZ2V0LnZhbHVlID0gJyd9Ly/YqNmHINiu2KfYt9ixINmF2LTaqdmEINii2b7ZhNmI2K8g2K/YsSDaqdix2YjZhVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2ltYWdlSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5wdXRGaWxlTGFiZWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2Nsb3VkQ29tcHV0aW5nfS8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZmlsZVwiPtii2b7ZhNmI2K8g2KrYtdmI24zYsSDaqdin2LHYqiDZhdin2LTbjNmGXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17ZmlsZX0gY2xhc3NOYW1lPVwiY2FySW1nXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L011aVRoZW1lUHJvdmlkZXI+XHJcbiAgICAgICAgICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICA8RGlhbG9nQWN0aW9ucz5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e2Nsb3NlTW9kYWx9IGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJmaWxsXCIgY2xhc3NOYW1lPVwiZGlhbG9nQnRuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgINmE2LrZiFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17c3Vic2NyaWJlTW9kYWx9IGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJmaWxsXCIgY2xhc3NOYW1lPVwiZGlhbG9nQnRuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgINiq2KfbjNuM2K9cclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvRGlhbG9nQWN0aW9ucz5cclxuICAgICAgICAgICAgPC9EaWFsb2c+XHJcbiAgICAgICAgPC9NdWlUaGVtZVByb3ZpZGVyPlxyXG4gICAgKTtcclxufVxyXG5leHBvcnQgZGVmYXVsdCBPcmRlciJdLCJzb3VyY2VSb290IjoiIn0=